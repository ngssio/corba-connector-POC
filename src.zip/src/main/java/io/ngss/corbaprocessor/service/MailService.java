package io.ngss.corbaprocessor.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * Created by ngsscsalur on 8/5/2019.
 */
@Service
public class MailService {

    private JavaMailSender javaMailSender;

    private final Logger logger = LoggerFactory.getLogger(MailService.class);

    @Autowired
    public MailService(JavaMailSender javaMailSender){
        this.javaMailSender = javaMailSender;
    }

    @Async
    public void sendMail(SimpleMailMessage simpleMailMessage){
        try {
            javaMailSender.send(simpleMailMessage);
            logger.info("Email sent");

        } catch (Exception e){
            logger.error("Email couldn't send");
            e.printStackTrace();
        }
    }
}
