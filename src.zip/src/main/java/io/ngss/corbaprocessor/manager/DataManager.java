package io.ngss.corbaprocessor.manager;

import HW_vpnManager.FlowDomainFragment_T;
import HW_vpnManager.MatrixFlowDomainFragment_T;
import HW_vpnManager.TrafficTrunk_T;
import globaldefs.NameAndStringValue_T;
import globaldefs.ProcessingFailureException;
import io.ngss.corbaprocessor.InternalDatabase;
import io.ngss.corbaprocessor.corba.connection.CorbaConnection;
import io.ngss.corbaprocessor.corba.manager.InventoryManager;
import io.ngss.corbaprocessor.neo4j.entity.node.*;
import io.ngss.corbaprocessor.neo4j.entity.role.*;
import io.ngss.corbaprocessor.neo4j.repository.FlowDomainFragmentRepository;
import io.ngss.corbaprocessor.neo4j.repository.ManagedElementRepository;
import io.ngss.corbaprocessor.neo4j.repository.TerminationPointRepository;
import io.ngss.corbaprocessor.neo4j.repository.TrafficTrunkRepository;
import managedElement.ManagedElement_T;
import multiLayerSubnetwork.MultiLayerSubnetwork_T;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import subnetworkConnection.TPData_T;
import terminationPoint.TerminationPoint_T;
import topologicalLink.TopologicalLink_T;

import java.util.*;

/**
 * Created by ngsscsalur on 8/23/2019.
 */

@Component
public class DataManager {

    private InventoryManager inventoryManager;
    private ManagedElementRepository meRepository;
    private TerminationPointRepository tpRepository;
    private FlowDomainFragmentRepository fdfrRepository;
    private TrafficTrunkRepository trafficTrunkRepository;

    public DataManager(
            @Autowired ManagedElementRepository meRepository,
            @Autowired TerminationPointRepository tpRepository,
            @Autowired FlowDomainFragmentRepository fdfrRepository,
            @Autowired TrafficTrunkRepository trafficTrunkRepository) {
        this.meRepository = meRepository;
        this.tpRepository = tpRepository;
        this.fdfrRepository = fdfrRepository;
        this.trafficTrunkRepository = trafficTrunkRepository;
    }

    public void processRTN() {
        inventoryManager = new InventoryManager(CorbaConnection.getOrb(), CorbaConnection.getEmsSession());
        try {
            inventoryManager.managedElementManager.getAllManagedElements();
            System.out.println("managed elements taken");

            NameAndStringValue_T[][] topLevelSubnetworkNames = inventoryManager.emsManager.getAllTopLevelSubnetworkNames();
            MultiLayerSubnetwork_T subnetwork = inventoryManager.mlsnManager.getMultiLayerSubnetwork(topLevelSubnetworkNames[0]);
            TopologicalLink_T[] topologicalLinks = inventoryManager.mlsnManager.getAllTopologicalLinksNew(subnetwork.name);
            System.out.println("topological links taken");

            ManagedElement_T me_rtn = null, me_rtn2 = null, me_rtn3 = null;
            for (ManagedElement_T managedElement_t : InternalDatabase.allManagedElements) {
                if (managedElement_t.nativeEMSName.contains("892-RTN2121010_MECIDIYEKOY_ANTIKACILAR")) {
                    me_rtn = managedElement_t;
                    System.out.println("892-RTN2121010 found");
                    break;
                }
            }
            for (ManagedElement_T managedElement_t : InternalDatabase.allManagedElements) {
                if (managedElement_t.nativeEMSName.contains("917-RTN2121018_DR.CEMIL_BENGU")) {
                    me_rtn2 = managedElement_t;
                    System.out.println("917-RTN2121018 found");
                    break;
                }
            }
            for (ManagedElement_T managedElement_t : InternalDatabase.allManagedElements) {
                if (managedElement_t.nativeEMSName.contains("260-RTN2122694_ORTABAYIR_JP_FTTS_Project")) {
                    me_rtn3 = managedElement_t;
                    System.out.println("260-RTN2122694 found");
                    break;
                }
            }

            MatrixFlowDomainFragment_T[] mfdfrs_rtn1 = inventoryManager.vpnManager.getAllMFDFrs(me_rtn.name);
            MatrixFlowDomainFragment_T[] mfdfrs_rtn2 = inventoryManager.vpnManager.getAllMFDFrs(me_rtn2.name);
            MatrixFlowDomainFragment_T[] mfdfrs_rtn3 = inventoryManager.vpnManager.getAllMFDFrs(me_rtn3.name);
            TerminationPoint_T[] ptps_rtn1 = inventoryManager.managedElementManager.getAllPTPs(me_rtn.name);
            TerminationPoint_T[] ptps_rtn2 = inventoryManager.managedElementManager.getAllPTPs(me_rtn2.name);
            TerminationPoint_T[] ptps_rtn3 = inventoryManager.managedElementManager.getAllPTPs(me_rtn3.name);





            System.out.println("done");
            close();
        } catch (Exception e){
            System.out.println("got error");
            close();
            e.printStackTrace();
        }
    }


    public TerminationPoint findOrCreateTP(TerminationPoint_T tp){
        Long meId = Long.parseLong(tp.name[1].value);
        String raw = tp.name[2].value;
        TerminationPoint tpNode = null;//tpRepository.findByMeIdAndRaw(meId, raw);
        if(tpNode==null){
            //yeni olusturucaz
            tpNode = new TerminationPoint();
        }

        return tpNode;
    }


    public void process() {

        inventoryManager = new InventoryManager(CorbaConnection.getOrb(), CorbaConnection.getEmsSession());
//        meRepository.clearDatabase();

        try {
            inventoryManager.managedElementManager.getAllManagedElements();
//            for (int i = 0; i < InternalDatabase.allManagedElements.size(); i++) {
//                ManagedElement_T me = InternalDatabase.allManagedElements.get(i);
//                createMENode(me);
//                //createTPNode(meNode, me.name);
//            }

            ManagedElement_T me_atn = null, me_ptn1 = null, me_ptn2 = null;
            for (ManagedElement_T managedElement_t : InternalDatabase.allManagedElements) {
                //260-ATN2120462_ORTABAYIR
                //A117(2)-PTN2128184_ECE_PLAZA
                if (managedElement_t.nativeEMSName.contains("260-ATN2120462_ORTABAYIR")) {
                    me_atn = managedElement_t;
                    System.out.println("me_atn found");
                    break;
                }
            }
            for (ManagedElement_T managedElement_t : InternalDatabase.allManagedElements) {
                if (managedElement_t.nativeEMSName.contains("A117(2)-PTN2128184_ECE_PLAZA")) {
                    me_ptn1 = managedElement_t;
                    System.out.println("me_ptn1 found");
                    break;
                }
            }
            for (ManagedElement_T managedElement_t : InternalDatabase.allManagedElements) {
                if (managedElement_t.nativeEMSName.contains("A117(1)-PTN2128179_ECE_PLAZA")) {
                    me_ptn2 = managedElement_t;
                    System.out.println("me_ptn2 found");
                    break;
                }
            }

//            createTPNode(me_atn.name);
//            createTPNode(me_ptn1.name);
//            createTPNode(me_ptn2.name);

//            TerminationPoint_T[] tp_atn = inventoryManager.managedElementManager.getAllPTPs(me_atn.name);
//            TerminationPoint_T[] tp_ptn1 = inventoryManager.managedElementManager.getAllPTPs(me_ptn1.name);
//            TerminationPoint_T[] tp_ptn2 = inventoryManager.managedElementManager.getAllPTPs(me_ptn2.name);
//            MatrixFlowDomainFragment_T[] mfdfrs = inventoryManager.vpnManager.getAllMFDFrs(me_atn.name);
//            MatrixFlowDomainFragment_T[] mfdfrsptn1 = inventoryManager.vpnManager.getAllMFDFrs(me_ptn1.name);
//            MatrixFlowDomainFragment_T[] mfdfrsptn2 = inventoryManager.vpnManager.getAllMFDFrs(me_ptn2.name);

//            MatrixFlowDomainFragment_T mfdfr = findPort(mfdfrs, "1054");
//            TPDataModel tp1 = TPDataModel.matchTransmissionParams(mfdfr.zEnd[0]);
//            TPDataModel tp2 = TPDataModel.matchTransmissionParams(mfdfr.zEnd[1]);

//            FlowDomain_T[] allFlowDomains = inventoryManager.flowDomainManager.getAllFlowDomains();
//            List<FlowDomainFragment_T> allFDFrs = inventoryManager.vpnManager.getAllFDFrs(allFlowDomains[0].name, (short) 96);
//
//            for (FlowDomainFragment_T fdfr: allFDFrs){
//                createCircuitNode(fdfr);
//
//            }
//
//            //todo burada tum fdfrlardan IVID=1054'e gore arama yapılacak
            FlowDomainFragment_T fdfr = getFDFr();
            //this.createFDFrNode(fdfr);

            List<String> bindingObjects = new ArrayList<>();
            for (NameAndStringValue_T ns: fdfr.transmissionParams.transmissionParams) {
                if(ns.name.contains("BindingObject"))
                    bindingObjects.add(ns.value);
            }

            for (String boRaw:bindingObjects) {
                System.out.println("value:" + getLastValue(boRaw));
                NameAndStringValue_T[] ttName = {
                        new NameAndStringValue_T("EMS","Huawei/T2000"),
                        new NameAndStringValue_T("Flowdomain","1"),
                        new NameAndStringValue_T("TrafficTrunk",getLastValue(boRaw))
                };
                TrafficTrunk_T bo = inventoryManager.vpnManager.getTrafficTrunk(ttName);
                //createTrafficTrunkNode(bo, fdfr.nativeEMSName);

                for(NameAndStringValue_T ns : bo.transmissionParams.transmissionParams){
                    if(ns.name.equals("BindingObject")){
                        String[] bos = ns.value.split(";");
                        NameAndStringValue_T[] bo1 = {
                                new NameAndStringValue_T("EMS","Huawei/T2000"),
                                new NameAndStringValue_T("Flowdomain","1"),
                                new NameAndStringValue_T("TrafficTrunk",getLastValue(bos[0]))
                        };
                        TrafficTrunk_T bott1 = inventoryManager.vpnManager.getTrafficTrunk(bo1);
                        //createTTNode(bott1, bo.nativeEMSName);

                        NameAndStringValue_T[] bo2 = {
                                new NameAndStringValue_T("EMS","Huawei/T2000"),
                                new NameAndStringValue_T("Flowdomain","1"),
                                new NameAndStringValue_T("TrafficTrunk",getLastValue(bos[1]))
                        };
                        TrafficTrunk_T bott2 = inventoryManager.vpnManager.getTrafficTrunk(bo2);
                        //createTTNode(bott2, bo.nativeEMSName);
                        break;
                    }
                }

            }








            System.out.println("debug");

            close();
        } catch (ProcessingFailureException e) {
            System.out.println("got error");
            close();
            e.printStackTrace();
        }

    }

    private String getLastValue(String raw){
        String[] splitted = raw.split("value=");
        return splitted[splitted.length-1];
    }

    private FlowDomainFragment_T getFDFr() throws ProcessingFailureException {
        NameAndStringValue_T[] fdfrName = {
                new NameAndStringValue_T("EMS","Huawei/T2000"),
                new NameAndStringValue_T("Flowdomain","1"),
                new NameAndStringValue_T("FlowdomainFragment","PWE3TRAIL=470830")
        };
        return inventoryManager.vpnManager.getFDFr(fdfrName);
    }


    public MatrixFlowDomainFragment_T findPort(MatrixFlowDomainFragment_T[] mfdfrs, String port){
        for (MatrixFlowDomainFragment_T mfdfr: mfdfrs) {
            if(mfdfr.aEnd[0].transmissionParams[0].transmissionParams[0].value.equals(port)){
                return mfdfr;
            }
        }
        return null;
    }

    public static HashMap<String, String> getNameAsHashMap(NameAndStringValue_T[] name){
        HashMap<String, String> hm = new HashMap<>();
        for (NameAndStringValue_T ns: name) {
            hm.put(ns.name, ns.value);
        }
        return hm;
    }

    public void createMfdfrTpNode(MatrixFlowDomainFragment_T mfdfr){

    }




    public void createTPNode(NameAndStringValue_T[] meName) throws ProcessingFailureException {
        TerminationPoint_T[] terminationPoints = inventoryManager.managedElementManager.getAllPTPs(meName);
        ManagedElement meNode = meRepository.findByCorbaId("");//(Long.parseLong(meName[1].value));

        for (TerminationPoint_T tp : terminationPoints) {
            TerminationPoint tpNode = new TerminationPoint();
            tpNode.setNativeEMSName(tp.nativeEMSName);
//            tpNode.setRaw(tp.name[2].value);
//            tpNode.setMeId(Long.parseLong(tp.name[1].value));
            HashMap<String, String> name = new HashMap<>();
            for (NameAndStringValue_T ns: tp.name) {
                name.put(ns.name, ns.value);
            }
            tpNode.setName(name);

            tpRepository.save(tpNode);

            HasPort port = new HasPort();
            port.setManagedElement(meNode);
            port.setTp(tpNode);

            List<HasPort> ports = new ArrayList<>();
            ports.add(port);
            tpNode.setPorts(ports);
            tpRepository.save(tpNode);
        }
    }


    public void close() {
        CorbaConnection corbaConnection = CorbaConnection.getInstance();
        if (corbaConnection.isConnected()) {
            corbaConnection.disconnect();
        }
        System.exit(0);
    }


}
