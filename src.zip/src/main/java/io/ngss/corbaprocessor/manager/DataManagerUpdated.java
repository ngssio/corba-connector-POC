package io.ngss.corbaprocessor.manager;

import HW_vpnManager.FlowDomainFragment_T;
import HW_vpnManager.MatrixFlowDomainFragment_T;
import HW_vpnManager.TrafficTrunk_T;
import flowDomain.FlowDomain_T;
import globaldefs.NameAndStringValue_T;
import globaldefs.ProcessingFailureException;
import io.ngss.corbaprocessor.InternalDatabase;
import io.ngss.corbaprocessor.corba.connection.CorbaConnection;
import io.ngss.corbaprocessor.corba.manager.InventoryManager;
import io.ngss.corbaprocessor.corba.util.XMLNode;
import io.ngss.corbaprocessor.corba.util.XMLParser;
import io.ngss.corbaprocessor.neo4j.entity.node.*;
import io.ngss.corbaprocessor.neo4j.entity.role.*;
import io.ngss.corbaprocessor.neo4j.entity.role.RoutedOn.*;
import io.ngss.corbaprocessor.neo4j.repository.*;
import managedElement.ManagedElement_T;
import multiLayerSubnetwork.MultiLayerSubnetwork_T;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import subnetworkConnection.TPData_T;
import topologicalLink.TopologicalLink_T;

import java.util.*;

/**
 * Created by ngsscsalur on 8/27/2019.
 */

@Component
public class DataManagerUpdated {

    private InventoryManager inventoryManager;

    private ManagedElementRepository meRepository;
    private TerminationPointRepository tpRepository;
    private FlowDomainFragmentRepository fdfrRepository;
    private TrafficTrunkRepository trafficTrunkRepository;
    private MatrixFlowDomainFragmentRepository mfdfrRepository;
    private TopologicalLinkRepository topoRepository;
    private CircuitRepository circuitRepository;
    private NodeBRepository nodeBRepository;
    private ServiceRepository serviceRepository;

    private static Logger logger = LogManager.getLogger(DataManagerUpdated.class);

    public DataManagerUpdated(
            @Autowired ManagedElementRepository meRepository,
            @Autowired TerminationPointRepository tpRepository,
            @Autowired FlowDomainFragmentRepository fdfrRepository,
            @Autowired TrafficTrunkRepository trafficTrunkRepository,
            @Autowired MatrixFlowDomainFragmentRepository mfdfrRepository,
            @Autowired TopologicalLinkRepository topoRepository,
            @Autowired CircuitRepository circuitRepository,
            @Autowired NodeBRepository nodeBRepository,
            @Autowired ServiceRepository serviceRepository) {
        this.meRepository = meRepository;
        this.tpRepository = tpRepository;
        this.fdfrRepository = fdfrRepository;
        this.trafficTrunkRepository = trafficTrunkRepository;
        this.mfdfrRepository = mfdfrRepository;
        this.topoRepository = topoRepository;
        this.circuitRepository = circuitRepository;
        this.nodeBRepository = nodeBRepository;
        this.serviceRepository = serviceRepository;
    }

    public void fillInternalDatabase(){
        inventoryManager = new InventoryManager(CorbaConnection.getOrb(), CorbaConnection.getEmsSession());

        try{
            logger.info("Starting to take all Managed Elements..");
            inventoryManager.managedElementManager.getAllManagedElements();
            logger.info("All managed elements have taken");

            logger.info("Starting to take all Topological Link..");
            NameAndStringValue_T[][] topLevelSubnetworkNames = inventoryManager.emsManager.getAllTopLevelSubnetworkNames();
            MultiLayerSubnetwork_T subnetwork = inventoryManager.mlsnManager.getMultiLayerSubnetwork(topLevelSubnetworkNames[0]);
            TopologicalLink_T[] topologicalLinks = inventoryManager.mlsnManager.getAllTopologicalLinksNew(subnetwork.name);
            InternalDatabase.allTopologicalLinks = Arrays.asList(topologicalLinks);
            logger.info("Topological Links finished");

//            logger.info("Starting to take all Flow Domain Fragments..");
//            FlowDomain_T[] allFlowDomains = inventoryManager.flowDomainManager.getAllFlowDomains();
//            InternalDatabase.allFlowDomainFragments = inventoryManager.vpnManager.getAllFDFrs(allFlowDomains[0].name, (short) 96);
//            logger.info("Flow Domain Fragments finished");

        } catch (Exception e){
            e.printStackTrace();
            close();
        }
    }

    private void processManagedElements(){
        logger.info("Managed Element Nodes creating..");
        for (ManagedElement_T me: InternalDatabase.allManagedElements) {
            ManagedElement meNode = ManagedElement.createNode(me);
            meRepository.save(meNode);
        }
        logger.info("Managed Element Nodes successfully created");
    }

    private void processTopologicalLinks(){
        logger.info("Topological Link Nodes creating..");
        for (TopologicalLink_T topo : InternalDatabase.allTopologicalLinks) {
            TopologicalLink topoNode = TopologicalLink.createTopoNode(topo);
            topoRepository.save(topoNode);

            TerminationPoint aEndTpNode = findOrCreateTP(topo.aEndTP, null);
            HasLink outgoingLink = new HasLink();
            outgoingLink.setTopologicalLink(topoNode);
            outgoingLink.setTerminationPoint(aEndTpNode);
            aEndTpNode.getOutgoingLinks().add(outgoingLink);
            tpRepository.save(aEndTpNode);

            TerminationPoint zEndTpNode = findOrCreateTP(topo.zEndTP, null);
            HasLink incomingLink = new HasLink();
            incomingLink.setTopologicalLink(topoNode);
            incomingLink.setTerminationPoint(zEndTpNode);
            zEndTpNode.getIncomingLinks().add(incomingLink);
            tpRepository.save(zEndTpNode);

        }
        logger.info("Topological Link Nodes succesfully created");

    }

    private String makeItFive(String rtncode){
        String rtnCodeUpdated = rtncode;
        int lengt = rtnCodeUpdated.length();
        while(lengt<5){
            rtnCodeUpdated = "0"+rtnCodeUpdated;
            lengt=rtnCodeUpdated.length();
        }
        return rtnCodeUpdated;
    }

    private void findRTN(String rtnCode) throws ProcessingFailureException {
        List<XMLNode> xmlNodes = null;
        ManagedElement_T managedElement = null;
        String rtnCodeUpdated = makeItFive(rtnCode);

        List<String> xmlfiles = XMLParser.listXmlFiles("exports");
        for (String xmlName: xmlfiles) {
            if(xmlName.contains("_" + rtnCodeUpdated + "_")){
                xmlNodes = XMLParser.parseFile(xmlName);
                System.out.println("xml nodes found");
                break;
            }
        }

        for (ManagedElement_T me :InternalDatabase.allManagedElements) {
            if(me.nativeEMSName.startsWith(rtnCode+"-RTN")){
                if(rtnCode.equals("110")){
                    if(me.nativeEMSName.contains("212646")){
                        managedElement = me;
                        System.out.println("managed element found");
                        break;
                    }
                } else {
                    managedElement = me;
                    System.out.println("managed element found");
                    break;
                }
            }


        }

        if(xmlNodes != null && managedElement != null){
            for (XMLNode node: xmlNodes) {
                System.out.println();
                RTN2ATN(managedElement.name[1].value, node.getVlan(), node.getNodeBName(), node.getSlot());
            }
        }

    }

    public void test(){
        Service service = new Service();
        service.setName("test");
        serviceRepository.save(service);

        Circuit circuit = new Circuit();
        circuit.setName("testc");
        circuitRepository.save(circuit);

        NodeB nodeb = new NodeB();
        nodeb.setName("testb");
        nodeBRepository.save(nodeb);

        RoutedOnCircuit routedOn = new RoutedOnCircuit();
        routedOn.setStartingNode(circuit);
        routedOn.setService(service);
        service.getCircuits().add(routedOn);
        serviceRepository.save(service);

        RoutedOnNodeb rt = new RoutedOnNodeb();
        rt.setStartingNode(nodeb);
        rt.setService(service);
        service.getNodebs().add(rt);
        serviceRepository.save(service);

        close();
    }


    public void process() {
        try {
            this.fillInternalDatabase();

            //bunlar her seyi silip dbyi bastan kuruyor
//            this.clearDatabase();
//            this.processManagedElements();
//            this.processTopologicalLinks();


//            this.findRTN("A858");
//            this.findRTN("B786");
//            this.findRTN("B963");
//            this.findRTN("241");
//            this.findRTN("892");
//            this.findRTN("917");
//            this.findRTN("K4406");
//            this.findRTN("E632");
//            this.findRTN("110");
//            this.findRTN("588");
//            this.findRTN("K4141");


//            //2g icin elle koydum
//            this.findRTN("760");
//            RTN2ATN("3177076", "2419", "GL34_00760_TALATPASA_II", "7");
//
//            this.findRTN("A741");
//            RTN2ATN("3184111", "2029", "GL34_0A741_YBS_FATIH3", "7");




        } catch (Exception e){
            e.printStackTrace();
        }

    }


    public void clearDatabase() {
        logger.info("Database clearing..");
        meRepository.clearDatabase();
        logger.info("Database cleared");
    }

    private void close() {
        CorbaConnection corbaConnection = CorbaConnection.getInstance();
        if (corbaConnection.isConnected()) {
            corbaConnection.disconnect();
        }
        System.exit(0);
    }

    public static String getCorbaId(NameAndStringValue_T[] nss) {
        StringBuilder corbaId = new StringBuilder();
        for (NameAndStringValue_T ns : nss) {
            corbaId.append(ns.name);
            corbaId.append(";");
            corbaId.append(ns.value);
            corbaId.append(";");
        }
        return corbaId.toString();
    }

    public static HashMap<String, String> getNameAsHashMap(NameAndStringValue_T[] name) {
        HashMap<String, String> hm = new HashMap<>();
        for (NameAndStringValue_T ns : name) {
            hm.put(ns.name, ns.value);
        }
        return hm;
    }

    //--------------
    public void RTN2ATN(String meId, String vlan, String nodeBName, String slot) {
        try {
            NameAndStringValue_T[] meName = {
                    new NameAndStringValue_T("EMS", "Huawei/T2000"),
                    new NameAndStringValue_T("ManagedElement", meId)
            };
//            ManagedElement_T me = inventoryManager.managedElementManager.getManagedElement(meName);
            MatrixFlowDomainFragment_T startingMfdfr = null;

            Service service = new Service();
            service.setName(nodeBName);
            service.setVlan(vlan);
            serviceRepository.save(service);

            logger.info("Getting me: " + meId);
            ManagedElement_T me = InternalDatabase.managedElementMap.get(Long.parseLong(meId));
            ManagedElement meNode = findOrCreateManagedElement(me, service);

            MatrixFlowDomainFragment_T[] mfdfrs = inventoryManager.vpnManager.getAllMFDFrs(me.name);

            for (MatrixFlowDomainFragment_T mfdfr : mfdfrs) {
                List<String> services = Arrays.asList(mfdfr.aEnd[0].transmissionParams[0].transmissionParams[0].value.split(","));
                if (services.contains(vlan)) {
                    startingMfdfr = mfdfr;
                    logger.info("Starting mfdfr found for: " + vlan);
                    break;
                }
            }

            ///////////////////
            if(startingMfdfr != null) {
                NameAndStringValue_T[] tp = null;
                if(startingMfdfr.aEnd[0].tpName[2].value.contains("slot=" + slot)){
                    tp = startingMfdfr.aEnd[0].tpName;
                }
                else if (startingMfdfr.zEnd[0].tpName[2].value.contains("slot=" + slot)){
                    tp = startingMfdfr.zEnd[0].tpName;
                } else {
                    tp = startingMfdfr.aEnd[0].tpName;
                }

                if(tp!=null){
                    NodeB nodeB = nodeBRepository.findByName(nodeBName);
                    if(nodeB == null ){
                        nodeB = new NodeB();
                        nodeB.setName(nodeBName);
                        nodeBRepository.save(nodeB);
                    }
                    RoutedOnNodeb rt = new RoutedOnNodeb();
                    rt.setStartingNode(nodeB);
                    rt.setService(service);
                    service.getNodebs().add(rt);
                    serviceRepository.save(service);

                    TerminationPoint tpNode = findOrCreateTP(tp, service);
                    Connected connected = new Connected();
                    connected.setNodeB(nodeB);
                    connected.setTp(tpNode);
                    connected.setVlan(vlan);
                    tpNode.getNodeBConnections().add(connected);
                    tpRepository.save(tpNode);
                }



            }

            /////////////////////
            if (startingMfdfr != null) {

                MatrixFlowDomainFragment mfdfrNode = findOrCreateMfdfr(startingMfdfr, service);


                boolean isLastMfdfr = false;
                NameAndStringValue_T[] lastTopo = null;
                NameAndStringValue_T[] currentTP = startingMfdfr.aEnd[0].tpName;

                NameAndStringValue_T[] nextTP_mfdfr = findNextTPWithMfdfr(currentTP, service);
                NameAndStringValue_T[] nextTP_topo = findNextTPWithTopoLinks(currentTP, service);

                while (nextTP_topo != null || nextTP_mfdfr != null) {
                    //herhangi bir yol bulamayana kadar
                    if (nextTP_topo != null) {
                        logger.info(InternalDatabase.getNameAndStringValueAsString(currentTP) + " to "
                                + InternalDatabase.getNameAndStringValueAsString(nextTP_topo) + " by topo.");
                        lastTopo = nextTP_topo;
                        currentTP = nextTP_topo;
                        isLastMfdfr = false;
                    } else if (nextTP_mfdfr != null && !isLastMfdfr) {
                        logger.info(InternalDatabase.getNameAndStringValueAsString(currentTP) + " to "
                                + InternalDatabase.getNameAndStringValueAsString(nextTP_mfdfr) + " by mfdfr.");
                        currentTP = nextTP_mfdfr;
                        isLastMfdfr = true;
                    } else if (nextTP_mfdfr != null && isLastMfdfr) {
                        break;
                    }

                    nextTP_mfdfr = findNextTPWithMfdfr(currentTP, service);
                    nextTP_topo = findNextTPWithTopoLinks(currentTP, service);
                }

                logger.info("matching finished");
                NameAndStringValue_T[] endingME = {
                        new NameAndStringValue_T("EMS", "Huawei/T2000"),
                        new NameAndStringValue_T("ManagedElement", currentTP[1].value)
                };
                MatrixFlowDomainFragment_T endingMfdfr = null;
                MatrixFlowDomainFragment_T[] endingMfdfrs = inventoryManager.vpnManager.getAllMFDFrs(endingME);
                for (MatrixFlowDomainFragment_T mfdfr : endingMfdfrs) {
                    List<String> services = Arrays.asList(mfdfr.aEnd[0].transmissionParams[0].transmissionParams[0].value.split(","));
                    if (services.contains(vlan)) {
                        endingMfdfr = mfdfr;
                        logger.info("Ending mfdfr found for: " + vlan);
                        logger.info(endingMfdfr.aEnd[0].tpName[2].value + " to " + endingMfdfr.zEnd[0].tpName[2].value);

                        if(endingMfdfr.aEnd[0].tpName[2].value.equals(lastTopo[2].value))
                            lastTopo = endingMfdfr.zEnd[0].tpName;
                        else if (endingMfdfr.zEnd[0].tpName[2].value.equals(lastTopo[2].value))
                            lastTopo = endingMfdfr.aEnd[0].tpName;
                        break;
                    }
                }

                logger.info("Last Topo: " + lastTopo[2].value);

                ManagedElement_T starting_ME = InternalDatabase.managedElementMap.get(Long.parseLong(meId));
                ManagedElement_T ending_ME = InternalDatabase.managedElementMap.get(Long.parseLong(lastTopo[1].value));

                String sme = starting_ME.nativeEMSName.split("-")[0];
                String eme = ending_ME.nativeEMSName.split("-")[0];

                logger.info("sme: " + sme + ", eme: " + eme);

                ATN2PTN(sme, eme, lastTopo, vlan, service);

            }


        } catch (Exception e) {
            System.out.println("got error");
        } finally {
            //close();
        }

    }

    private NameAndStringValue_T[] findNextTPWithMfdfr(NameAndStringValue_T[] tpName, Service service) throws ProcessingFailureException {

        MatrixFlowDomainFragment_T[] mfdfrs = inventoryManager.vpnManager.getAllMFDFrs(new NameAndStringValue_T[]{tpName[0], tpName[1]});
        for (MatrixFlowDomainFragment_T mfdfr : mfdfrs) {
            if (mfdfr.zEnd.length > 1 || mfdfr.aEnd.length > 1) {
                System.out.println("iki tane varmis buraya bir bak");
            }
            if (mfdfr.aEnd[0].tpName[2].value.equals(tpName[2].value)) {
                logger.info("next mfdfr found");
                logger.info("transmission params: " + mfdfr.zEnd[0].transmissionParams[0].transmissionParams[0].value);

                findOrCreateMfdfr(mfdfr, service);

                return mfdfr.zEnd[0].tpName;
            } else if (mfdfr.zEnd[0].tpName[2].value.equals(tpName[2].value)) {
                logger.info("next mfdfr found");
                logger.info("transmission params: " + mfdfr.zEnd[0].transmissionParams[0].transmissionParams[0].value);

                findOrCreateMfdfr(mfdfr, service);

                return mfdfr.aEnd[0].tpName;
            }
        }
        return null;
    }

    private NameAndStringValue_T[] findNextTPWithTopoLinks(NameAndStringValue_T[] tpName, Service service) {
        for (TopologicalLink_T topo : InternalDatabase.allTopologicalLinks) {
            if (topo.aEndTP[1].value.equals(tpName[1].value) && topo.aEndTP[2].value.equals(tpName[2].value)) {
                logger.info("next topological link found");

                findOrCreateTopologicalLink(topo, service);

                return topo.zEndTP;
            }
        }
        return null;
    }


    private void ATN2PTN(String startingMEName,String endingMEName, NameAndStringValue_T[] endingTP, String vlan, Service service) {
        //elimizde fdfr olacak
        //FlowDomainFragment_T fdfr = inventoryManager.vpnManager.getFDFr(startingFdfr); calismadi

        //fdfr'da aEnd ve zEnd real portlar var
        //FlowDomainFragment_T fdfr = findFdfrByName(fdfrName);

        try {
            FlowDomainFragment_T fdfr = findFdfrBySiteNameAndVlan(endingMEName, startingMEName, vlan);
//            FlowDomainFragment_T fdfr = findFdfrByMEandVlan(endingTP[1].value, vlan);
            if (fdfr == null) {
                logger.error("FDFr could not found");
                return;
            }
            logger.info("FDFr found: " + fdfr.name[2].value);
            FlowDomainFragment fdfrNode = findOrCreateFdfr(fdfr, service);


            // rtn - atn connection
            Circuit circuit = findOrCreateCircuit(fdfr.nativeEMSName, service);

            TerminationPoint aEndTP = findOrCreateTP(endingTP, service);
            HasCircuit hasCircuit = new HasCircuit();
            hasCircuit.setCircuit(circuit);
            hasCircuit.setTerminationPoint(aEndTP);
            aEndTP.getCircuits().add(hasCircuit);
            tpRepository.save(aEndTP);

            TerminationPoint zEndTP = findOrCreateTP(fdfr.aEnd[0].tpName, service);
            HasCircuit hasCircuit2 = new HasCircuit();
            hasCircuit2.setCircuit(circuit);
            hasCircuit2.setTerminationPoint(zEndTP);
            zEndTP.getCircuits().add(hasCircuit2);
            tpRepository.save(zEndTP);

            logger.info("RTN and ATN connected");



            for (TPData_T a : fdfr.aEnd) {
                for (TPData_T z : fdfr.zEnd) {
                    logger.info(a.tpName[1].value + "-" + a.tpName[2].value + " to " + z.tpName[1].value + "-" + z.tpName[2].value);
                }
            }

            MatrixFlowDomainFragment_T[] fdfrRoutes = inventoryManager.vpnManager.getFDFrRoute(fdfr.name);
            logger.info("MFDFr routes found.");

            for (MatrixFlowDomainFragment_T mfdfr : fdfrRoutes) {
                //create TP Node
                //aEndTP to zEndTPs mfdfr
                StringBuilder sb = new StringBuilder();
                sb.append("Route(").append(mfdfr.aEnd[0].tpName[1].value).append("): ");
                for (TPData_T t : mfdfr.aEnd) {
                    sb.append(t.tpName[2].value).append(", ");
                }
                sb.append(" to ");
                for (TPData_T t : mfdfr.zEnd) {
                    sb.append(t.tpName[2].value).append(", ");
                }
                logger.info(sb.toString());

                findOrCreateMfdfr(mfdfr, service);
            }

            List<String> bindingObjects = new ArrayList<>();
            for (NameAndStringValue_T ns : fdfr.transmissionParams.transmissionParams) {
                if (ns.name.contains("BindingObject"))
                    bindingObjects.add(ns.value);
            }
            logger.info("Fdfr binding objects listed");
            //todo aEnd ve zEnd icin hasService eklicez

            //fdfr ile isimiz bitti bindingObjects trafficTrunklara bakalim
            for (String boRaw : bindingObjects) {
                logger.info(boRaw + " has selected!");
                TrafficTrunk_T bo = getTrafficTrunkFromRaw(boRaw);
                //sanal portlar arasindaki baglanti var, ayrica working type da buradan cikiyor
                //a[0] ve z[0] alinsa yeter sanirim

                //a[0]-sanal -> z[0]-sanal (workingType)
                String workingMode = findTransmissionParam(bo.aEnd[0].transmissionParams[0].transmissionParams, "WorkingMode");
                String aEndPeerIP = findTransmissionParam(bo.aEnd[0].transmissionParams[0].transmissionParams, "PeerIP");
                String zEndPeerIP = findTransmissionParam(bo.zEnd[0].transmissionParams[0].transmissionParams, "PeerIP");

                logger.info("Native EMS Name: " + bo.nativeEMSName);
                logger.info("User Label: " + bo.userLabel);
                logger.info("Working Mode: " + workingMode);
                logger.info("A End Peer IP: " + aEndPeerIP);
                logger.info("Z End Peer IP: " + zEndPeerIP);
                logger.info(bo.aEnd[0].tpName[1].value + "-" + bo.aEnd[0].tpName[2].value + " to " + bo.zEnd[0].tpName[1].value + "-" + bo.zEnd[0].tpName[2].value);

                TrafficTrunk bindingNode = findOrCreateTrafficTrunkFdfr(bo, service);
                bindingNode.setWorkingMode(workingMode);

                Binded binded = new Binded();
                binded.setFdfr(fdfrNode);
                binded.setEndingTrunk(bindingNode);
                bindingNode.getFdfrBindings().add(binded);
                TrafficTrunk boNode = trafficTrunkRepository.save(bindingNode);


                for (NameAndStringValue_T ns : bo.transmissionParams.transmissionParams) {
                    if (ns.name.equals("BindingObject")) {
                        logger.info("TT binding object found");
                        String[] bos = ns.value.split(";");

                        for (String ttRaw : bos) {
                            //bott1.aEnd[0] -> bott1.zEnd[0]
                            logger.info(ttRaw + " selected.");
                            TrafficTrunk_T boTT = getTrafficTrunkFromRaw(ttRaw);

                            String ttId = findTransmissionParam(boTT.transmissionParams.transmissionParams, "TrafficTrunkID");

                            logger.info("Native EMS Name: " + boTT.nativeEMSName);
                            logger.info("User Label: " + boTT.userLabel);
                            logger.info("Traffic Trunk Id: " + ttId);

                            logger.info(boTT.aEnd[0].tpName[1].value + " to " + boTT.zEnd[0].tpName[1].value);

                            TrafficTrunk boTTNode = findOrCreateTrafficTrunkBO(boTT, service);
                            BindedTrunk bindedTrunk = new BindedTrunk();
                            bindedTrunk.setStartingTrunk(boNode);
                            bindedTrunk.setEndingTrunk(boTTNode);
                            boTTNode.getTtBindings().add(bindedTrunk);
                            trafficTrunkRepository.save(boTTNode);
                        }
                        System.out.println();
                        break;
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("error at ATN2PTN");
            e.printStackTrace();
        }


    }

    private String getLastValue(String raw) {
        String[] splitted = raw.split("value=");
        return splitted[splitted.length - 1];
    }

    private TrafficTrunk_T getTrafficTrunkFromRaw(String raw) throws ProcessingFailureException {
        NameAndStringValue_T[] ttName = {
                new NameAndStringValue_T("EMS", "Huawei/T2000"),
                new NameAndStringValue_T("Flowdomain", "1"),
                new NameAndStringValue_T("TrafficTrunk", getLastValue(raw))
        };
        TrafficTrunk_T tt = inventoryManager.vpnManager.getTrafficTrunk(ttName);
        return tt;
    }

    private String findTransmissionParam(NameAndStringValue_T[] transmissionParams, String key) {
        for (NameAndStringValue_T ns : transmissionParams) {
            if (ns.name.equals(key))
                return ns.value;
        }
        return null;
    }

    private FlowDomainFragment_T findFdfrByName(String name) {
        for (FlowDomainFragment_T fdfr : InternalDatabase.allFlowDomainFragments) {
            if (fdfr.name[2].value.equals(name)) {
                return fdfr;
            }
        }
        return null;
    }

    private FlowDomainFragment_T findFdfrBySiteNameAndVlan(String endingRtnName, String startingRtnName, String vlan) {
        for (FlowDomainFragment_T fdfr : InternalDatabase.allFlowDomainFragments) {
            if ( (fdfr.nativeEMSName.startsWith("ETH-" + endingRtnName) || fdfr.nativeEMSName.startsWith("ETH-FTTS-" + endingRtnName))
                    && fdfr.nativeEMSName.contains(startingRtnName)
                    && fdfr.aEnd[0].transmissionParams[0].transmissionParams[0].value.equals(vlan)) {
                return fdfr;
            }
        }
        return null;
    }

    private FlowDomainFragment_T findFdfrByMEandVlan(String meId, String vlan) {
        for (FlowDomainFragment_T fdfr : InternalDatabase.allFlowDomainFragments) {
            if(fdfr.aEnd.length>0 && fdfr.aEnd[0].tpName.length>1){
                if (fdfr.aEnd[0].tpName[1].value.equals(meId)
                        && fdfr.aEnd[0].transmissionParams[0].transmissionParams[0].value.equals(vlan)){
                    return fdfr;
                }
            }
        }
        return null;
    }

    private TerminationPoint findOrCreateTP(NameAndStringValue_T[] tpName, Service service) {
        String corbaId = TerminationPoint.createCorbaId(tpName);
        Long meId = TerminationPoint.createMeId(tpName);
        TerminationPoint tpNode = tpRepository.findByMeIdAndCorbaId(meId,corbaId);

        if (tpNode == null) {
            tpNode = new TerminationPoint();
            tpNode.setCorbaId(corbaId);
            tpNode.setMeId(meId);
//            tpNode.setNativeEMSName(tp.nativeEMSName);
//            tpNode.setName(getNameAsHashMap(tp));
            tpRepository.save(tpNode);

            ManagedElement meNode = findOrCreateManagedElement(InternalDatabase.managedElementMap.get(Long.parseLong(tpName[1].value)),service);

            HasPort port = new HasPort();
            port.setManagedElement(meNode);
            port.setTp(tpNode);
            tpNode.getPorts().add(port);
            tpRepository.save(tpNode);
        }

        if(service!=null){
            ManagedElement meNode = findOrCreateManagedElement(InternalDatabase.managedElementMap.get(Long.parseLong(tpName[1].value)),service);
            RoutedOnTP routedOn = new RoutedOnTP();
            routedOn.setStartingNode(tpNode);
            routedOn.setService(service);
            service.getTps().add(routedOn);
            serviceRepository.save(service);
        }
        return tpNode;
    }

    private ManagedElement findOrCreateManagedElement(ManagedElement_T me, Service service) {
        ManagedElement meNode = meRepository.findByCorbaId(me.name[1].value);
        if (meNode == null) {
            meNode = ManagedElement.createNode(me);
            meRepository.save(meNode);
            logger.info("Managed Element created: " + me.name[1].value);
        }
        if(service != null){
            RoutedOnME routedOn = new RoutedOnME();
            routedOn.setStartingNode(meNode);
            routedOn.setService(service);
            service.getManagedElements().add(routedOn);
            serviceRepository.save(service);
        }
        return meNode;
    }

    private MatrixFlowDomainFragment findOrCreateMfdfr(MatrixFlowDomainFragment_T mfdfr, Service service){
        MatrixFlowDomainFragment mfdfrNode = mfdfrRepository.findByCorbaId(MatrixFlowDomainFragment.createCorbaId(mfdfr.name));

        if(mfdfrNode == null){
            mfdfrNode = MatrixFlowDomainFragment.createNode(mfdfr);
            mfdfrRepository.save(mfdfrNode);
            logger.info("Mfdfr created: " + mfdfrNode.getCorbaId());



            TerminationPoint aEndTpNode = findOrCreateTP(mfdfr.aEnd[0].tpName, service);
            HasMatrix outgoingMatrix = new HasMatrix();
            outgoingMatrix.setMfdfr(mfdfrNode);
            outgoingMatrix.setTp(aEndTpNode);
            aEndTpNode.getOutgoingMatrices().add(outgoingMatrix);
            tpRepository.save(aEndTpNode);

            for (TPData_T zEnd:mfdfr.zEnd) {
                TerminationPoint zEndTpNode = findOrCreateTP(zEnd.tpName, service);
                HasMatrix incomingMatrix = new HasMatrix();
                incomingMatrix.setMfdfr(mfdfrNode);
                incomingMatrix.setTp(zEndTpNode);
                zEndTpNode.getIncomingMatrices().add(incomingMatrix);
                tpRepository.save(zEndTpNode);
            }

        }

        if(service!=null){
            RoutedOnMFDFR routedOn = new RoutedOnMFDFR();
            routedOn.setStartingNode(mfdfrNode);
            routedOn.setService(service);
            service.getMfdfrs().add(routedOn);
            serviceRepository.save(service);

            findOrCreateTP(mfdfr.aEnd[0].tpName, service);
            for (TPData_T zEnds:mfdfr.zEnd) {
                findOrCreateTP(zEnds.tpName, service);
            }
        }
        return mfdfrNode;
    }

    private TopologicalLink findOrCreateTopologicalLink(TopologicalLink_T topoLink, Service service) {
        TopologicalLink topoNode = topoRepository.findByCorbaId(topoLink.name[1].value);

        if(topoNode == null){
            topoNode = TopologicalLink.createTopoNode(topoLink);
            topoRepository.save(topoNode);

            logger.info("Topological Link created: " + topoNode.getCorbaId());

            TerminationPoint aEndTpNode = findOrCreateTP(topoLink.aEndTP, service);
            HasLink outgoingLink = new HasLink();
            outgoingLink.setTopologicalLink(topoNode);
            outgoingLink.setTerminationPoint(aEndTpNode);
            aEndTpNode.getOutgoingLinks().add(outgoingLink);
            tpRepository.save(aEndTpNode);

            TerminationPoint zEndTpNode = findOrCreateTP(topoLink.zEndTP, service);
            HasLink incomingLink = new HasLink();
            incomingLink.setTopologicalLink(topoNode);
            incomingLink.setTerminationPoint(zEndTpNode);
            zEndTpNode.getIncomingLinks().add(incomingLink);
            tpRepository.save(zEndTpNode);
        }

        if(service!=null){
            RoutedOnTopo routedOn = new RoutedOnTopo();
            routedOn.setStartingNode(topoNode);
            routedOn.setService(service);
            service.getTopos().add(routedOn);
            serviceRepository.save(service);
            findOrCreateTP(topoLink.aEndTP, service);
            findOrCreateTP(topoLink.zEndTP, service);
        }
        return topoNode;
    }

    private FlowDomainFragment findOrCreateFdfr(FlowDomainFragment_T fdfr, Service service) {

        FlowDomainFragment fdfrNode = fdfrRepository.findByCorbaId(fdfr.name[2].value);

        if ( fdfrNode == null){
            fdfrNode = FlowDomainFragment.createNode(fdfr);
            fdfrRepository.save(fdfrNode);

            logger.info("Fdfr Node created: " + fdfrNode.getCorbaId());

            TerminationPoint aEndTpNode = findOrCreateTP(fdfr.aEnd[0].tpName, service);
            HasConnection outgoingConnection = new HasConnection();
            outgoingConnection.setFdfr(fdfrNode);
            outgoingConnection.setTp(aEndTpNode);
            aEndTpNode.getOutgoingConnections().add(outgoingConnection);
            tpRepository.save(aEndTpNode);

            for (TPData_T zEnds:fdfr.zEnd) {
                TerminationPoint zEndTpNode = findOrCreateTP(zEnds.tpName, service);
                HasConnection incomingConnection = new HasConnection();
                incomingConnection.setFdfr(fdfrNode);
                incomingConnection.setTp(zEndTpNode);
                zEndTpNode.getIncomingConnections().add(incomingConnection);
                tpRepository.save(zEndTpNode);
            }
        }

        if(service!=null){
            RoutedOnFDFR routedOn = new RoutedOnFDFR();
            routedOn.setStartingNode(fdfrNode);
            routedOn.setService(service);
            service.getFdfrs().add(routedOn);
            serviceRepository.save(service);
            findOrCreateTP(fdfr.aEnd[0].tpName, service);
            for (TPData_T zEnds:fdfr.zEnd) {
                findOrCreateTP(zEnds.tpName, service);
            }
        }
        return fdfrNode;
    }

    private TrafficTrunk findOrCreateTrafficTrunkFdfr(TrafficTrunk_T trunk, Service service) {
        TrafficTrunk ttNode = trafficTrunkRepository.findByCorbaId(trunk.name[2].value);

        if (ttNode == null){
            ttNode = TrafficTrunk.createNode(trunk);
            trafficTrunkRepository.save(ttNode);

            logger.info("Traffic Trunk Node(FDFR) created: " + ttNode.getCorbaId());

            TerminationPoint aEndTpNode = findOrCreateTP(trunk.aEnd[0].tpName, service);
            HasTrunk outgoingTrunk = new HasTrunk();
            outgoingTrunk.setTrafficTrunk(ttNode);
            outgoingTrunk.setTerminationPoint(aEndTpNode);
            aEndTpNode.getOutgoingTrunks().add(outgoingTrunk);
            tpRepository.save(aEndTpNode);

            TerminationPoint zEndTpNode = findOrCreateTP(trunk.zEnd[0].tpName, service);
            HasTrunk incomingTrunk = new HasTrunk();
            incomingTrunk.setTrafficTrunk(ttNode);
            incomingTrunk.setTerminationPoint(zEndTpNode);
            zEndTpNode.getIncomingTrunks().add(incomingTrunk);
            tpRepository.save(zEndTpNode);

        }

        if(service!=null){
            RoutedOnTT routedOn = new RoutedOnTT();
            routedOn.setStartingNode(ttNode);
            routedOn.setService(service);
            service.getTts().add(routedOn);
            serviceRepository.save(service);
            findOrCreateTP(trunk.aEnd[0].tpName, service);
            findOrCreateTP(trunk.zEnd[0].tpName, service);
        }

        return ttNode;
    }

    private TrafficTrunk findOrCreateTrafficTrunkBO(TrafficTrunk_T trunk, Service service){
        TrafficTrunk ttNode = trafficTrunkRepository.findByCorbaId(trunk.name[2].value);

        if(ttNode == null) {
            ttNode = TrafficTrunk.createNode(trunk);
            trafficTrunkRepository.save(ttNode);

            logger.info("Traffic Trunk Node(BO) created: " + ttNode.getCorbaId());


            ManagedElement aEndME = findOrCreateManagedElement(InternalDatabase.managedElementMap.get(Long.parseLong(trunk.aEnd[0].tpName[1].value)), service);
            HasTunnel outgoingTunnel = new HasTunnel();
            outgoingTunnel.setManagedElement(aEndME);
            outgoingTunnel.setTrafficTrunk(ttNode);
            aEndME.getTunnelsOutgoing().add(outgoingTunnel);
            meRepository.save(aEndME);

            ManagedElement zEndME = findOrCreateManagedElement(InternalDatabase.managedElementMap.get(Long.parseLong(trunk.zEnd[0].tpName[1].value)), service);
            HasTunnel incomingTunnel = new HasTunnel();
            incomingTunnel.setManagedElement(zEndME);
            incomingTunnel.setTrafficTrunk(ttNode);
            zEndME.getTunnelsIncoming().add(incomingTunnel);
            meRepository.save(zEndME);
        }

        if(service!=null){
            RoutedOnTT routedOn = new RoutedOnTT();
            routedOn.setStartingNode(ttNode);
            routedOn.setService(service);
            service.getTts().add(routedOn);
            serviceRepository.save(service);
            findOrCreateManagedElement(InternalDatabase.managedElementMap.get(Long.parseLong(trunk.aEnd[0].tpName[1].value)), service);
            findOrCreateManagedElement(InternalDatabase.managedElementMap.get(Long.parseLong(trunk.zEnd[0].tpName[1].value)), service);
        }

        return ttNode;
    }

    private Circuit findOrCreateCircuit(String name, Service service){
        Circuit circuit = circuitRepository.findByName(name);

        if(circuit == null) {
            circuit = new Circuit();
            circuit.setName(name);
            circuitRepository.save(circuit);
            logger.info("Circuit node created.");

        }
        if(service!=null){
            RoutedOnCircuit routedOn = new RoutedOnCircuit();
            routedOn.setStartingNode(circuit);
            routedOn.setService(service);
            service.getCircuits().add(routedOn);
            serviceRepository.save(service);
        }
        return circuit;
    }


    public void updateManagedElement(String corbaId){
        ManagedElement meNode = meRepository.findByCorbaId(corbaId);
        if (meNode != null) {
            try {
                NameAndStringValue_T[] meName = {
                        new NameAndStringValue_T("EMS", "Huawei/T2000"),
                        new NameAndStringValue_T("ManagedElement", corbaId)
                };
            ManagedElement_T me = inventoryManager.managedElementManager.getManagedElement(meName);
            meNode.setNativeEMSName(me.nativeEMSName);
            meRepository.save(meNode);
            logger.info("Managed Element updated: " + corbaId);

            } catch (Exception e){
                logger.error("Couldn't update managed element info");
                e.printStackTrace();
            }
        }
    }

    public Collection<NodeB> getConnectedNodebs(String managedElementCorbaId){
        return nodeBRepository.findConnectedNodebs(managedElementCorbaId);
    }

}
