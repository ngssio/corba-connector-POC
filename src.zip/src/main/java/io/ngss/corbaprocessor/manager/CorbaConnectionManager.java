package io.ngss.corbaprocessor.manager;

import io.ngss.corbaprocessor.corba.connection.CorbaConnection;
import io.ngss.corbaprocessor.corba.ems.U2000;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Created by ngsscsalur on 8/5/2019.
 */

@Component
public class CorbaConnectionManager {

//    private String prodEnvIpI = "172.28.120.80";
//    private String prodEnvIpII = "10.175.50.10";
//    private String defaultCorbaPort = "12001";
//    private String corbaUsername = "ngssobis";
//    private String corbaPassword = "Temp789!";

    private String prodEnvIpI = "10.122.249.116";
    private String prodEnvIpII = "10.122.249.145";
    private String defaultCorbaPort = "12001";
    private String corbaUsername = "hterzioglu";
    private String corbaPassword = "Vodafone2467!!";

//    private String prodEnvIpI = "10.176.233.50";
//    private String prodEnvIpII = "10.122.249.116";
//    private String defaultCorbaPort = "12001";
//    private String corbaUsername = "nbitest";
//    private String corbaPassword = "Qwerty1234!";

    private final Logger logger = LoggerFactory.getLogger(CorbaConnectionManager.class);

    public CorbaConnectionManager(){
        //createConnection();
    }



    public void createConnection(){
        //new U2000(prodEnvIpI, defaultCorbaPort, corbaUsername, corbaPassword)
        int status = connect(new U2000(prodEnvIpI, defaultCorbaPort, corbaUsername, corbaPassword));
        if(status != 0 ){
            logger.error("failed to connect to corba on ip: " + prodEnvIpI);
            try {
                Thread.sleep(15000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            //todo status = connect(new U2000(prodEnvIpII, defaultCorbaPort, corbaUsername, corbaPassword));
        }
        if(status != 0){
            CorbaConnection corbaConnection = CorbaConnection.getInstance();
            logger.error("failed to connect to corba on ip: " + prodEnvIpII);
            if (corbaConnection.isConnected()) {
                logger.error("Corba connection was not null, disconnecting..");
                corbaConnection.disconnect();}
            //todo send mail
        }

    }

    public int connect(U2000 properties){
        int status = -1;
        CorbaConnection corbaConnection = CorbaConnection.getInstance();

        try {
            if (corbaConnection.isConnected()) {
                logger.error("Corba connection was not null, disconnecting..");
                corbaConnection.disconnect();
            }
            status = corbaConnection.connect(properties);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("failed to connect to Corba!");
            corbaConnection.disconnect();
        }
        return status;
    }


}
