package io.ngss.corbaprocessor.manager;

import HW_vpnManager.MatrixFlowDomainFragment_T;
import globaldefs.NameAndStringValue_T;
import io.ngss.corbaprocessor.InternalDatabase;
import io.ngss.corbaprocessor.corba.connection.CorbaConnection;
import io.ngss.corbaprocessor.corba.interfaces.CSVCompatible;
import io.ngss.corbaprocessor.corba.manager.InventoryManager;
import io.ngss.corbaprocessor.corba.metadata.ManagedElement;
import io.ngss.corbaprocessor.corba.metadata.TerminationPoint;
import io.ngss.corbaprocessor.corba.metadata.TopologicalLink;
import io.ngss.corbaprocessor.corba.util.CSVWriter;
import managedElement.ManagedElement_T;
import org.springframework.stereotype.Component;
import subnetworkConnection.SubnetworkConnection_T;
import terminationPoint.TerminationPoint_T;
import topologicalLink.TopologicalLink_T;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by ngsscsalur on 8/5/2019.
 */
@Component
public class WDMLinkManager {

    //private CorbaConnectionManager corbaConnectionManager;

//    public WDMLinkManager(@Autowired CorbaConnectionManager corbaConnectionManager){
//        this.corbaConnectionManager = corbaConnectionManager;
//        this.findAllLinks();
//    }


    public void findAllLinks() {
        //this.corbaConnectionManager.createConnection();
        InventoryManager inventoryManager = new InventoryManager(CorbaConnection.getOrb(), CorbaConnection.getEmsSession());

        try {

            //managed element manager ile aynisini verdi
            Collection<ManagedElement> MLSNManagedElements = new ArrayList<>(inventoryManager.getAllMLSNManagedElements());
            Collection<ManagedElement> managedElements = new ArrayList<>(inventoryManager.getAllManagedElements());

            inventoryManager.emsManager.getAllTopLevelSubnetworkNames();
            inventoryManager.mlsnManager.getAllSubnetworkConnections(InternalDatabase.allTopLevelSubnetworkNames.get(0));




            inventoryManager.mlsnManager.getRouteAndTopologicalLinksBySNCs(
                    new NameAndStringValue_T[][]{InternalDatabase.allSubnetworkConnections.get(0).name, InternalDatabase.allSubnetworkConnections.get(1).name});

            InternalDatabase.test();


            ManagedElement_T me = null, me2 = null;

            for (ManagedElement_T managedElement_t : InternalDatabase.allManagedElements) {
                //260-ATN2120462_ORTABAYIR
                //A117(2)-PTN2128184_ECE_PLAZA
                if (managedElement_t.nativeEMSName.contains("260-ATN2120462_ORTABAYIR")) {
                    me2 = managedElement_t;
                    System.out.println("atn buldu");
                    break;
                }
            }

//            for (int i = 0; i < InternalDatabase.allManagedElements.size(); i++) {
//                if (i % 500 == 0) {
//                    System.out.println("i: " + i);
//                }
//                me = InternalDatabase.allManagedElements.get(i);
//                if (me.nativeEMSName.equals("892-RTN2121010_MECIDIYEKOY_ANTIKACILAR")) {
//                    System.out.println("RTN found, index: " + i);
//                    break;
//                }
//            }


            inventoryManager.flowDomainManager.getAllFlowDomains();
            //testAllLayerRateList(inventoryManager);
            //inventoryManager.flowDomainManager.getAllFDFrs(InternalDatabase.allFlowDomains.get(0).name);
            //InternalDatabase.test();

//
//            inventoryManager.vpnManager.getAllMFDFrs(me.name);
//            inventoryManager.vpnManager.getAllTrafficTrunksWithME(me.name);
//            inventoryManager.vpnManager.getAllTrafficTrunks(InternalDatabase.allFlowDomains.get(0).name);
//            InternalDatabase.test();


            //inventoryManager.getAllPTPs(me2.name);
            //inventoryManager.getAllCrossConnection(me2.name);
//                    inventoryManager.mlsnManager.getAllSubnetworkConnectionsWithTP(InternalDatabase.allPTPs.get(20).name);
//                    inventoryManager.mlsnManager.getAllSubnetworkConnectionsWithTP(aEnTp.name);
//            inventoryManager.mstpServiceManager.getAllEthService(me2.name);
//            inventoryManager.mstpServiceManager.getAllATMService(me2.name);

//            inventoryManager.mstpInventoryManager.getAllMstpEndPoints(me2.name);
//            inventoryManager.mstpInventoryManager.getAllVBs(me2.name);
//            inventoryManager.mstpInventoryManager.getAllFlows(me2.name);
            inventoryManager.vpnManager.getAllMFDFrs(me2.name);
            //inventoryManager.vpnManager.getAllTrafficTrunksWithME(me2.name);
            //testAllLayerRateList(inventoryManager,me2.name);
            for (HW_vpnManager.MatrixFlowDomainFragment_T value : InternalDatabase.allMFDFrs) {
                System.out.println(value.name[2].value);
                //PWE3=2||GigabitEthernet0/2/3.1054
                //PWE3=2||Eth-Trunk1.1054
                if ("PWE3=2||GigabitEthernet0/2/3.1054".equals(value.name[2].value)) {
                    MatrixFlowDomainFragment_T test = value;
                    System.out.println("buldu");
                    inventoryManager.vpnManager.getFDFrRoute(value.name);
                }
            }


            InternalDatabase.test();

            inventoryManager.managedElementManager.getContainedInUseTPs(InternalDatabase.allPTPs.get(0).name);

            //inventoryManager.mlsnManager.getAllTopologicalLinksNew();
            TopologicalLink_T topo;

            for (int i = 0; i < InternalDatabase.allTopologicalLinks.size(); i++) {
                if (i % 500 == 0) {
                    System.out.println("topological link searching, i: " + i);
                }
                topo = InternalDatabase.allTopologicalLinks.get(i);
                ManagedElement_T aEndME = InternalDatabase.managedElementMap.get(Integer.parseInt(topo.aEndTP[1].value));
                ManagedElement_T zEndME = InternalDatabase.managedElementMap.get(Integer.parseInt(topo.zEndTP[1].value));


                if (aEndME.nativeEMSName.equals("260-RTN2122694_ORTABAYIR_JP_FTTS_Project") /*|| zEndME.nativeEMSName.equals("260-RTN2122694_ORTABAYIR_JP_FTTS_Project")*/) {

                    TerminationPoint_T aEnTp = inventoryManager.managedElementManager.getTP(topo.aEndTP);
                    //TerminationPoint_T zEnTp = inventoryManager.managedElementManager.getTP(topo.zEndTP);

                    System.out.println("topological link found");

                    //inventoryManager.getAllPTPs(aEndME.name);
                    inventoryManager.managedElementManager.getAllPTPNames(aEndME.name);
                    SubnetworkConnection_T snc2 = null;


                    for (TerminationPoint_T tp : InternalDatabase.allPTPs) {
                        if (tp.nativeEMSName.equals("ATN_0-2-3")) {
                            inventoryManager.mlsnManager.getAllSubnetworkConnectionsWithTP(tp.name);

//                            for (SubnetworkConnection_T snc : InternalDatabase.allSubnetworkConnections){
//                                if(snc.aEnd[0].tpName[1].value.equals(tp.name[1].value) || snc.zEnd[0].tpName[1].value.equals(tp.name[1].value)){
//                                    snc2 = snc;
//                                    System.out.println("snc ile eslesti");
//                                }
//                            }
//                            System.out.println("snc bulamadi");

                            InternalDatabase.test();
                            break;
                        }
                    }


                    inventoryManager.getAllCrossConnection(aEndME.name);
//                    inventoryManager.mlsnManager.getAllSubnetworkConnectionsWithTP(InternalDatabase.allPTPs.get(20).name);
//                    inventoryManager.mlsnManager.getAllSubnetworkConnectionsWithTP(aEnTp.name);
                    inventoryManager.mstpServiceManager.getAllEthService(aEndME.name);
                    inventoryManager.mstpInventoryManager.getAllMstpEndPoints(aEndME.name);
                    inventoryManager.mstpInventoryManager.getAllVBs(aEndME.name);
                    inventoryManager.mstpInventoryManager.getAllFlows(aEndME.name);

                    ///rack=1/shelf=1/slot=13/domain=ptn/type=physical/port=1

                    InternalDatabase.test();

                    //break;
                }
            }


            InternalDatabase.test();


            Collection<TopologicalLink> topologicalLinks = new ArrayList<>(inventoryManager.getAllTopologicalLinks());
            Collection<TerminationPoint> terminationPoints = new ArrayList<>(inventoryManager.getAllTerminationPoints());

            Collection<CSVCompatible> MLSNManagedElementsCSV = new ArrayList<>();
            Collection<CSVCompatible> managedElementsCSV = new ArrayList<>();
            Collection<CSVCompatible> topologicalLinksCSV = new ArrayList<>();
            Collection<CSVCompatible> terminationPointsCSV = new ArrayList<>();

            MLSNManagedElementsCSV.addAll(MLSNManagedElements);
            managedElementsCSV.addAll(managedElements);
            topologicalLinksCSV.addAll(topologicalLinks);
            terminationPointsCSV.addAll(terminationPoints);

            CSVWriter.writeToCSV(MLSNManagedElementsCSV, "./logs/MLSNManagedElements.csv");
            CSVWriter.writeToCSV(managedElementsCSV, "./logs/ManagedElements.csv");
            CSVWriter.writeToCSV(topologicalLinksCSV, "./logs/TopologicalLinks.csv");
            CSVWriter.writeToCSV(terminationPointsCSV, "./logs/TerminationPoints.csv");
        } catch (Exception e) {
            e.printStackTrace();
            CorbaConnection corbaConnection = CorbaConnection.getInstance();
            if (corbaConnection.isConnected()) {
                corbaConnection.disconnect();
            }
            System.exit(0);
        }

    }

    public void testAllLayerRateList(InventoryManager inventoryManager, NameAndStringValue_T[] meName) {

        for (short layerRate : InternalDatabase.layerRateList) {
            try {
                //inventoryManager.flowDomainManager.getAllFDFrs(InternalDatabase.allFlowDomains.get(0).name, layerRate);
                inventoryManager.vpnManager.getAllTrafficTrunksWithME(meName, layerRate);

                System.out.println("Calisti: " + layerRate);
                //System.out.println("FDFr length: " + InternalDatabase.allFlowDomainFragments.size());
                System.out.println("Traffic Trunk length: " + InternalDatabase.allTrafficTrunksWithME.size());
            } catch (Exception e) {
                System.out.println("hata verdi: " + layerRate);
            }
        }


    }
}
