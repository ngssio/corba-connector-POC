package io.ngss.corbaprocessor.manager;

import HW_mstpInventory.HW_Flow_T;
import HW_mstpInventory.HW_MSTPEndPoint_T;
import HW_mstpInventory.HW_VirtualBridge_T;
import HW_mstpService.HW_EthService_T;
import HW_vpnManager.*;
import equipment.EquipmentOrHolder_T;
import equipment.PhysicalLocationInfo_T;
import flowDomain.FlowDomain_T;
import globaldefs.NameAndStringValue_T;
import io.ngss.corbaprocessor.InternalDatabase;
import io.ngss.corbaprocessor.controller.PushNotification;
import io.ngss.corbaprocessor.corba.connection.CorbaConnection;
import io.ngss.corbaprocessor.corba.manager.InventoryManager;
import io.ngss.corbaprocessor.corba.metadata.TopologicalLink;
import managedElement.ManagedElement_T;
import multiLayerSubnetwork.HW_ConjunctionSNC_T;
import multiLayerSubnetwork.MultiLayerSubnetwork_T;
import multiLayerSubnetwork.RouteAndTopologicalLink_T;
import org.springframework.stereotype.Component;
import subnetworkConnection.CrossConnect_T;
import subnetworkConnection.SubnetworkConnection_T;
import subnetworkConnection.TPData_T;
import terminationPoint.TerminationPoint_T;
import topologicalLink.TopologicalLink_T;

import java.io.File;
import java.io.FileWriter;
import java.util.List;

/**
 * Created by ngsscsalur on 8/19/2019.
 */

@Component
public class TestManager {


    public void test() {
        InventoryManager inventoryManager = new InventoryManager(CorbaConnection.getOrb(), CorbaConnection.getEmsSession());

        try {

            //NameAndStringValue_T[] capabilities = inventoryManager.commonManager.getCapabilities();

            //all managed elements aldık
            inventoryManager.getAllManagedElements();


            NameAndStringValue_T[] ftpName = {
                    new NameAndStringValue_T("EMS", "Huawei/T2000"),
                    new NameAndStringValue_T("ManagedElement", "3200180"),
                    new NameAndStringValue_T("FTP", "PW=12782|5||||")
            };


            //managed elementleri bulduk
            ManagedElement_T me_atn = null, me_ptn = null, me_rtn = null;
            for (ManagedElement_T managedElement_t : InternalDatabase.allManagedElements) {
                //260-ATN2120462_ORTABAYIR
                //A117(2)-PTN2128184_ECE_PLAZA
                if (managedElement_t.nativeEMSName.contains("260-ATN2120462_ORTABAYIR")) {
                    me_atn = managedElement_t;
                    System.out.println("me_atn found");
                    break;
                }
            }
            for (ManagedElement_T managedElement_t : InternalDatabase.allManagedElements) {
                if (managedElement_t.nativeEMSName.contains("A117(2)-PTN2128184_ECE_PLAZA")) {
                    me_ptn = managedElement_t;
                    System.out.println("me_ptn found");
                    break;
                }
            }
            for (ManagedElement_T managedElement_t : InternalDatabase.allManagedElements) {
                if (managedElement_t.nativeEMSName.contains("892-RTN2121010_MECIDIYEKOY_ANTIKACILAR")) {
                    me_rtn = managedElement_t;
                    System.out.println("me_rtn found");
                    break;
                }
            }



//            File file = new File("me.txt");
//            if(file.exists()==false) file.createNewFile();
//            FileWriter fr = new FileWriter(file,true);
//
//            for(ManagedElement_T me:InternalDatabase.allManagedElements) {
//                fr.write(InternalDatabase.getManagedElementAsString(me));
//            }
//            fr.close();


//            for (short layerRate: InternalDatabase.layerRateList) {
//                try {
//                    HW_vpnManager.FlowDomainFragment_T[] allFDFrs = inventoryManager.vpnManager.getAllFDFrs(allFlowDomains[0].name, layerRate);
//                    System.out.println("calisti: " + layerRate + ", length: " + allFDFrs.length);
//                    if(allFDFrs.length>0){
//                        System.out.println();
//                    }
//                } catch (Exception e) {
//                    System.out.println("atn error: ");
//                }
//            }
            FlowDomain_T[] allFlowDomains = inventoryManager.flowDomainManager.getAllFlowDomains();
            //HW_vpnManager.FlowDomainFragment_T[] allFDFrs = inventoryManager.vpnManager.getAllFDFrs(allFlowDomains[0].name, (short) 96);

            NameAndStringValue_T[] meName = {
                    new NameAndStringValue_T("EMS","Huawei/T2000"),
                    new NameAndStringValue_T("ManagedElement","3190850")
            };
//            MatrixFlowDomainFragment_T[] mfdfrs = inventoryManager.vpnManager.getAllMFDFrs(meName);
//            File file = new File("mfdfr2.txt");
//            if (!file.exists()) file.createNewFile();
//            FileWriter fr = new FileWriter(file,true);
//            for (MatrixFlowDomainFragment_T mfdfr : mfdfrs) {
//                fr.write(InternalDatabase.getMFDFRAsString(mfdfr));
//            }
//            fr.close();





            NameAndStringValue_T[] fdfrName = {
                    new NameAndStringValue_T("EMS","Huawei/T2000"),
                    new NameAndStringValue_T("Flowdomain","1"),
                    new NameAndStringValue_T("FlowdomainFragment","PWE3TRAIL=470830")
            };

            NameAndStringValue_T[] ttName1 = {
                    new NameAndStringValue_T("EMS","Huawei/T2000"),
                    new NameAndStringValue_T("Flowdomain","1"),
                    new NameAndStringValue_T("TrafficTrunk","PWTRAIL=448197")
            };
            NameAndStringValue_T[] ttName2 = {
                    new NameAndStringValue_T("EMS","Huawei/T2000"),
                    new NameAndStringValue_T("Flowdomain","1"),
                    new NameAndStringValue_T("TrafficTrunk","PWTRAIL=448198")
            };
            NameAndStringValue_T[] ttName = {
                    new NameAndStringValue_T("EMS","Huawei/T2000"),
                    new NameAndStringValue_T("Flowdomain","1"),
                    new NameAndStringValue_T("TrafficTrunk","PWTRAIL=448196")
            };

            //|FDRNAME|EMS;Huawei/T2000;Flowdomain;1;FlowdomainFragment;PWE3TRAIL=470830
            //BindingObject;\name=EMS\value=Huawei/T2000\name=Flowdomain\value=1\name=TrafficTrunk\value=PWTRAIL=448196;
            //BindingObject_1;\name=EMS\value=Huawei/T2000\name=Flowdomain\value=1\name=TrafficTrunk\value=PWTRAIL=448197;
            //BindingObject_2;\name=EMS\value=Huawei/T2000\name=Flowdomain\value=1\name=TrafficTrunk\value=PWTRAIL=448198;

            //|TRAFFICTRUNKNAME|EMS;Huawei/T2000;Flowdomain;1;TrafficTrunk;TUNNELTRAIL=181339
            //|TRAFFICTRUNKNAME|EMS;Huawei/T2000;Flowdomain;1;TrafficTrunk;TUNNELTRAIL=181340

            NameAndStringValue_T[] trunk1 = {
                    new NameAndStringValue_T("EMS","Huawei/T2000"),
                    new NameAndStringValue_T("Flowdomain","1"),
                    new NameAndStringValue_T("TrafficTrunk","PWTRAIL=181339")
            };
            NameAndStringValue_T[] trunk2 = {
                    new NameAndStringValue_T("EMS","Huawei/T2000"),
                    new NameAndStringValue_T("Flowdomain","1"),
                    new NameAndStringValue_T("TrafficTrunk","PWTRAIL=181340")
            };

            try {
                MatrixFlowDomainFragment_T[] route1 = inventoryManager.vpnManager.getFDFrRoute(trunk1);
                MatrixFlowDomainFragment_T[] route2 = inventoryManager.vpnManager.getFDFrRoute(trunk2);
                System.out.println();
            } catch (Exception e) {
                System.out.println("erroe");
            }

            try {
                NameAndStringValue_T[][] serverTrails = inventoryManager.flowDomainManager.getFDFrServerTrail(trunk1);
                System.out.println("calisti, length: " + serverTrails.length);
            } catch (Exception e){
                System.out.println("error");
            }
            try {
                NameAndStringValue_T[][] serverTrails = inventoryManager.vpnManager.getFDFrServerTrail(trunk2);
                System.out.println("calisti, length: " + serverTrails.length);
            } catch (Exception e){
                System.out.println("error");
            }


//            try {
//                TrafficTrunk_T tt = inventoryManager.vpnManager.getTrafficTrunk(ttName);
//                TrafficTrunk_T tt1 = inventoryManager.vpnManager.getTrafficTrunk(ttName1);
//                TrafficTrunk_T tt2 = inventoryManager.vpnManager.getTrafficTrunk(ttName2);
//                File file = new File("bindingobjects_tt.txt");
//                if (!file.exists()) file.createNewFile();
//                FileWriter fr = new FileWriter(file, true);
//                fr.write(InternalDatabase.getTrafficTrunkAsString(tt));
//                fr.write(InternalDatabase.getTrafficTrunkAsString(tt1));
//                fr.write(InternalDatabase.getTrafficTrunkAsString(tt2));
//                fr.close();
//                System.out.println();
//            } catch (Exception e){
//
//            }


            //inventoryManager.vpnManager.getIPRoutesByTrafficTrunks(new NameAndStringValue_T[][]{fdfrName});



//            MatrixFlowDomainFragment_T[] fdfrRoute = inventoryManager.vpnManager.getFDFrRoute(fdfrName);

//            for (short layerRate:InternalDatabase.layerRateList) {
//                try {
//                    NameAndStringValue_T[][] ipCCs_atn = inventoryManager.vpnManager.getAllIPCrossconnectionNames(me_atn.name, layerRate);
//                    System.out.println("atn calisti: " + layerRate + ", length: " + ipCCs_atn.length);
//                } catch (Exception e) {
//                    System.out.println("atn error: ");
//                }
//                try {
//                    NameAndStringValue_T[][] ipCCs_ptn = inventoryManager.vpnManager.getAllIPCrossconnectionNames(me_ptn.name, layerRate);
//                    System.out.println("ptn calisti: " + layerRate + ", length: " + ipCCs_ptn.length);
//                } catch (Exception e) {
//                    System.out.println("ptn error: ");
//                }
//                try {
//                    NameAndStringValue_T[][] ipCCs_rtn = inventoryManager.vpnManager.getAllIPCrossconnectionNames(me_rtn.name, layerRate);
//                    System.out.println("rtn calisti: " + layerRate + ", length: " + ipCCs_rtn.length);
//                } catch (Exception e) {
//                    System.out.println("rtn error: ");
//                }
//            }



//            for (short layerRate : InternalDatabase.layerRateList) {
//
//            }








            this.close();




            /*
             * ÇALIŞANLAR
             */

            NameAndStringValue_T[][] topLevelSubnetworkNames = inventoryManager.emsManager.getAllTopLevelSubnetworkNames(); // bir tane geliyor

            NameAndStringValue_T[][] neStaticInfo_rtn = inventoryManager.managedElementManager.getNEStaticInfo(me_rtn.name); // atn ve ptn icin bos geldi
            TerminationPoint_T[] atn_ptps = inventoryManager.managedElementManager.getAllPTPs(me_atn.name);
            TerminationPoint_T[] ptn_ptps = inventoryManager.managedElementManager.getAllPTPs(me_ptn.name);
            TerminationPoint_T[] rtn_ptps = inventoryManager.managedElementManager.getAllPTPs(me_rtn.name);
            TerminationPoint_T terminationPoint = inventoryManager.managedElementManager.getTP(atn_ptps[0].name);

            EquipmentOrHolder_T[] equipmentOrHolders_atn = inventoryManager.equipmentInventoryManager.getAllEquipment(me_atn.name);
            EquipmentOrHolder_T[] equipmentOrHolders_ptn = inventoryManager.equipmentInventoryManager.getAllEquipment(me_ptn.name);
            EquipmentOrHolder_T[] equipmentOrHolders_rtn = inventoryManager.equipmentInventoryManager.getAllEquipment(me_rtn.name);
            PhysicalLocationInfo_T[] locationInfos = inventoryManager.equipmentInventoryManager.getPhysicalLocationInfo();
            EquipmentOrHolder_T[] supportingEquipments_rtn = inventoryManager.equipmentInventoryManager.getAllSupportingEquipment(rtn_ptps[0].name);


            MultiLayerSubnetwork_T subnetwork = inventoryManager.mlsnManager.getMultiLayerSubnetwork(topLevelSubnetworkNames[0]);
            SubnetworkConnection_T[] allSubnetworkConnections = inventoryManager.mlsnManager.getAllSubnetworkConnections(subnetwork.name);
            TopologicalLink_T[] topologicalLinks = inventoryManager.mlsnManager.getAllTopologicalLinksNew(subnetwork.name);
            CrossConnect_T[] routes = inventoryManager.mlsnManager.getRoute(allSubnetworkConnections[0].name);
            RouteAndTopologicalLink_T[] routeAndTopologicalLinks = inventoryManager.mlsnManager.getRouteAndTopologicalLinksBySNCs(new NameAndStringValue_T[][]{allSubnetworkConnections[0].name});
            TerminationPoint_T[] allEdgePoints = inventoryManager.mlsnManager.getAllEdgePoints(topLevelSubnetworkNames[0]); // bayağı uzun sürüyor 185 civarı geliyor



            MatrixFlowDomainFragment_T[] allMFDFrs_atn = inventoryManager.vpnManager.getAllMFDFrs(me_atn.name);
            MatrixFlowDomainFragment_T[] allMFDFrs_ptn = inventoryManager.vpnManager.getAllMFDFrs(me_ptn.name);
            MatrixFlowDomainFragment_T[] allMFDFrs_rtn = inventoryManager.vpnManager.getAllMFDFrs(me_rtn.name);
            TrafficTrunk_T[] allTrafficTrunks = inventoryManager.vpnManager.getAllTrafficTrunks(allFlowDomains[0].name, (short) 8011);



            /*
             * HATALILAR
             */

            EquipmentOrHolder_T[] supportingEquipments_atn = inventoryManager.equipmentInventoryManager.getAllSupportingEquipment(atn_ptps[0].name);
            EquipmentOrHolder_T[] supportingEquipments_ptn = inventoryManager.equipmentInventoryManager.getAllSupportingEquipment(ptn_ptps[0].name);

            TPData_T[] ftpMembers = inventoryManager.managedElementManager.getFTPMembers(ftpName); // ftpname'den dolayı da çalışmamış olabilir

            HW_Flow_T[] allFlows_atn = inventoryManager.mstpInventoryManager.getAllFlows(me_atn.name);
            HW_Flow_T[] allFlows_ptn = inventoryManager.mstpInventoryManager.getAllFlows(me_ptn.name);
            HW_MSTPEndPoint_T[] mstpEndPoints_atn = inventoryManager.mstpInventoryManager.getAllMstpEndPoints(me_atn.name);
            HW_MSTPEndPoint_T[] mstpEndPoints_ptn = inventoryManager.mstpInventoryManager.getAllMstpEndPoints(me_ptn.name);
            HW_VirtualBridge_T[] allVBs_atn = inventoryManager.mstpInventoryManager.getAllVBs(me_atn.name);
            HW_VirtualBridge_T[] allVBs_ptn = inventoryManager.mstpInventoryManager.getAllVBs(me_ptn.name);

            HW_EthService_T[] allEthServices_atn = inventoryManager.mstpServiceManager.getAllEthService(me_atn.name);
            HW_EthService_T[] allEthServices_ptn = inventoryManager.mstpServiceManager.getAllEthService(me_ptn.name);


            /*
             * BOS GELENLER
             */
            TerminationPoint_T[] supportedTerminationPoints_atn = inventoryManager.equipmentInventoryManager.getAllSupportedPTPs(equipmentOrHolders_atn[8].equip().name);
            TerminationPoint_T[] supportedTerminationPoints_pnt = inventoryManager.equipmentInventoryManager.getAllSupportedPTPs(equipmentOrHolders_ptn[70].equip().name);
            TerminationPoint_T[] supportedTerminationPoints_rtn = inventoryManager.equipmentInventoryManager.getAllSupportedPTPs(equipmentOrHolders_rtn[20].equip().name);

            flowDomainFragment.FlowDomainFragment_T[] allFRFrs = inventoryManager.flowDomainManager.getAllFDFrs(allFlowDomains[0].name, (short) 96); // diğer layer rateler için  patladı

            NameAndStringValue_T[][] neStaticInfo_atn = inventoryManager.managedElementManager.getNEStaticInfo(me_rtn.name);
            NameAndStringValue_T[][] neStaticInfo_ptn = inventoryManager.managedElementManager.getNEStaticInfo(me_rtn.name);
            CrossConnect_T[] allCCs_atn = inventoryManager.managedElementManager.getAllCrossConnection(me_atn.name);
            CrossConnect_T[] allCCs_ptn = inventoryManager.managedElementManager.getAllCrossConnection(me_ptn.name);
            CrossConnect_T[] allCCs_rtn = inventoryManager.managedElementManager.getAllCrossConnection(me_rtn.name);

            HW_ConjunctionSNC_T[] conjunctionSNCs = inventoryManager.mlsnManager.getAllConjuctionSNCs();
            TopologicalLink_T[] internalTopologicalLinks_atn = inventoryManager.mlsnManager.getAllInternalTopologicalLinks(me_atn.name);
            TopologicalLink_T[] internalTopologicalLinks_ptn = inventoryManager.mlsnManager.getAllInternalTopologicalLinks(me_ptn.name);
            TopologicalLink_T[] internalTopologicalLinks_rtn = inventoryManager.mlsnManager.getAllInternalTopologicalLinks(me_rtn.name);

            HW_Flow_T[] allFlows_rtn = inventoryManager.mstpInventoryManager.getAllFlows(me_rtn.name);
            HW_MSTPEndPoint_T[] mstpEndPoints_rtn = inventoryManager.mstpInventoryManager.getAllMstpEndPoints(me_rtn.name);
            HW_VirtualBridge_T[] allVBs_rtn = inventoryManager.mstpInventoryManager.getAllVBs(me_rtn.name);

            HW_EthService_T[] allEthServices_rtn = inventoryManager.mstpServiceManager.getAllEthService(me_rtn.name);


//            TopologicalLink_T[] internalTopologicalLinks;
//            for (ManagedElement_T me:InternalDatabase.allManagedElements) {
//                internalTopologicalLinks = inventoryManager.mlsnManager.getAllInternalTopologicalLinks(managedElement.name);
//                if(internalTopologicalLinks.length>0){
//                    break;
//                }
//            }


            for (SubnetworkConnection_T snc : InternalDatabase.allSubnetworkConnections) {
                System.out.println("\nSNCName: " + snc.nativeEMSName);
//                try {
//                    inventoryManager.mlsnManager.getRoute(snc.name);
//                    System.out.println("getRoute: calisti, length: "+InternalDatabase.allRoutes.size());
//                } catch (Exception e){
//                    System.out.println("getRoute: error");
//                }
//                try {
//                    NameAndStringValue_T[][] names = {snc.name};
//                    inventoryManager.mlsnManager.getRouteAndTopologicalLinksBySNCs(names);
//                    System.out.println("getRouteAndTopologicalLinks: calisti, length: "+InternalDatabase.allRouteAndTopologicalLinks.size());
//                } catch (Exception e){
//                    System.out.println("getRouteAndTopologicalLinks: error");
//                }
                if ("NE(11-1010)-892.RTN-1018.DRCEMAL BENGU-Link Server Trail-001241296".equals(snc.nativeEMSName)) {
                    NameAndStringValue_T[][] names = {snc.name};
                    inventoryManager.mlsnManager.getRouteAndTopologicalLinksBySNCs(names);
                    List<RouteAndTopologicalLink_T> routeAndTopologicalLinks2 = InternalDatabase.allRouteAndTopologicalLinks;

                    for (RouteAndTopologicalLink_T rtp : routeAndTopologicalLinks2) {
                        if (rtp.route != null) {
                            for (CrossConnect_T cc : rtp.route) {
                                if (cc.aEndNameList[0][1].value.equals(me_ptn.name[1].value)) {

                                }
                            }
                        }
                        if (rtp.topologicalLinkList != null) {
                            for (TopologicalLink_T t : rtp.topologicalLinkList) {
                                if (t.aEndTP[1].value.equals(me_ptn.name[1].value) || t.zEndTP[1].value.equals(me_ptn.name[1].value)) {
                                    System.out.println();
                                }
                            }
                        }
                    }
                    System.out.println();
                }
                System.out.println("----------------");
            }

            System.out.println();

            this.close();

        } catch (Exception e) {
            e.printStackTrace();
            this.close();
        }
    }


    public void close() {
        CorbaConnection corbaConnection = CorbaConnection.getInstance();
        if (corbaConnection.isConnected()) {
            corbaConnection.disconnect();
        }
        System.exit(0);
    }
}
