package io.ngss.corbaprocessor.controller;

import io.ngss.corbaprocessor.corba.connection.CorbaConnection;
import io.ngss.corbaprocessor.manager.DataManagerUpdated;
import io.ngss.corbaprocessor.neo4j.entity.node.NodeB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;

/**
 * Created by ngssrgunaydin on 8/6/2019.
 */
@RestController
public class SystemController {

    @Autowired
    DataManagerUpdated dataManagerUpdated;

    @GetMapping(value = "/closeProgram")
    public void closeProgram(){
        CorbaConnection corbaConnection = CorbaConnection.getInstance();
        if(corbaConnection.isConnected()){
            corbaConnection.disconnect();
        }
        System.exit(0);
    }

    @GetMapping(value = "/drawPath")
    public String drawPath(String rtnId, String vlan){
        //dataManagerUpdated.RTN2ATN(rtnId,vlan);
        return "OK";
    }

    @GetMapping(value = "/clearDatabase")
    public String clearDatabase(){
        //dataManagerUpdated.clearDatabase();
        return "OK";
    }

    @GetMapping(value = "/test")
    public String test(){
        return "test calisti.";
    }

    @GetMapping(value = "/updateManagedElement")
    public String updateManagedElement(String corbaId) {
        dataManagerUpdated.updateManagedElement(corbaId);
        return "OK!";
    }

    @GetMapping(value = "/getConnectedNodebs")
    public Collection<NodeB> getConnectedNodebs(String meCorbaId) {
        return dataManagerUpdated.getConnectedNodebs(meCorbaId);
    }

    @GetMapping(value = "/getPath")
    public String getPath(){
        return "sdf";
    }
}
