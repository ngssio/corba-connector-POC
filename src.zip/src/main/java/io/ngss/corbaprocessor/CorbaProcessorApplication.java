package io.ngss.corbaprocessor;

import io.ngss.corbaprocessor.neo4j.repository.ManagedElementRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.neo4j.repository.config.EnableNeo4jRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@EnableNeo4jRepositories
@SpringBootApplication
public class CorbaProcessorApplication {

	public static void main(String[] args) {
		SpringApplication.run(CorbaProcessorApplication.class, args);
	}

	@Bean
	CommandLineRunner demo(ManagedElementRepository meRepository){
		return args -> {

		};
	}

}
