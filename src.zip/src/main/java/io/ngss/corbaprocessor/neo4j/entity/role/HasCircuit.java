package io.ngss.corbaprocessor.neo4j.entity.role;

import io.ngss.corbaprocessor.neo4j.entity.node.Circuit;
import io.ngss.corbaprocessor.neo4j.entity.node.FlowDomainFragment;
import io.ngss.corbaprocessor.neo4j.entity.node.TerminationPoint;
import io.ngss.corbaprocessor.neo4j.entity.node.TrafficTrunk;
import lombok.*;
import org.neo4j.ogm.annotation.*;

/**
 * Created by ngsscsalur on 9/2/2019.
 */

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@RelationshipEntity(type = "HAS_CIRCUIT")
public class HasCircuit {

    @Id
    @GeneratedValue
    private Long id;

    @StartNode
    private Circuit circuit;

    @EndNode
    private TerminationPoint terminationPoint;
}
