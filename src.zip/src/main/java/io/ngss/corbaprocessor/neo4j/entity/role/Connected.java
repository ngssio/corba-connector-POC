package io.ngss.corbaprocessor.neo4j.entity.role;

import io.ngss.corbaprocessor.neo4j.entity.node.FlowDomainFragment;
import io.ngss.corbaprocessor.neo4j.entity.node.NodeB;
import io.ngss.corbaprocessor.neo4j.entity.node.TerminationPoint;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.neo4j.ogm.annotation.*;

/**
 * Created by ngsscsalur on 9/4/2019.
 */

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@RelationshipEntity(type = "CONNECTED")
public class Connected {

    @Id
    @GeneratedValue
    private Long id;
    private String vlan;

    @StartNode
    private NodeB nodeB;

    @EndNode
    private TerminationPoint tp;
}
