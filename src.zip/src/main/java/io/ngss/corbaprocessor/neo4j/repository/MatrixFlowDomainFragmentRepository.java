package io.ngss.corbaprocessor.neo4j.repository;

import io.ngss.corbaprocessor.neo4j.entity.node.ManagedElement;
import io.ngss.corbaprocessor.neo4j.entity.node.MatrixFlowDomainFragment;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.repository.query.Param;

/**
 * Created by ngsscsalur on 8/28/2019.
 */
public interface MatrixFlowDomainFragmentRepository extends Neo4jRepository<MatrixFlowDomainFragment, Long> {

    MatrixFlowDomainFragment findByCorbaId(@Param("corbaId") String corbaId);
}
