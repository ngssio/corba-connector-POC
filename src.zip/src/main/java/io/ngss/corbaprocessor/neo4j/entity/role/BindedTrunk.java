package io.ngss.corbaprocessor.neo4j.entity.role;

import io.ngss.corbaprocessor.neo4j.entity.node.FlowDomainFragment;
import io.ngss.corbaprocessor.neo4j.entity.node.TrafficTrunk;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.neo4j.ogm.annotation.*;

/**
 * Created by ngsscsalur on 9/2/2019.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@RelationshipEntity(type = "BINDED_TRUNK")
public class BindedTrunk {

    @Id
    @GeneratedValue
    private Long id;

    @StartNode
    private TrafficTrunk startingTrunk;

    @EndNode
    private TrafficTrunk endingTrunk;
}
