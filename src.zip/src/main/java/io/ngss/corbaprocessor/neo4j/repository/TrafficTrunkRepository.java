package io.ngss.corbaprocessor.neo4j.repository;

import io.ngss.corbaprocessor.neo4j.entity.node.TrafficTrunk;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.repository.query.Param;

/**
 * Created by ngsscsalur on 8/27/2019.
 */
public interface TrafficTrunkRepository extends Neo4jRepository<TrafficTrunk, Long> {

    TrafficTrunk findByNativeEMSName(@Param("nativeEMSName") String nativeEMSName);

    TrafficTrunk findByCorbaId(@Param("corbaId") String corbaId);
}
