package io.ngss.corbaprocessor.neo4j.entity.role;

import io.ngss.corbaprocessor.neo4j.entity.node.ManagedElement;
import io.ngss.corbaprocessor.neo4j.entity.node.MatrixFlowDomainFragment;
import io.ngss.corbaprocessor.neo4j.entity.node.TerminationPoint;
import io.ngss.corbaprocessor.neo4j.entity.node.TrafficTrunk;
import lombok.*;
import org.neo4j.ogm.annotation.*;

/**
 * Created by ngsscsalur on 8/28/2019.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@RelationshipEntity(type = "HAS_MATRIX")
public class HasMatrix {

    @Id
    @GeneratedValue
    private Long id;

    @StartNode
    private MatrixFlowDomainFragment mfdfr;

    @EndNode
    private TerminationPoint tp;
}
