package io.ngss.corbaprocessor.neo4j.repository;

import io.ngss.corbaprocessor.neo4j.entity.node.TerminationPoint;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.repository.query.Param;

/**
 * Created by ngsscsalur on 8/23/2019.
 */
public interface TerminationPointRepository extends Neo4jRepository<TerminationPoint, Long>{

//    @Query("match (n:/rack=1/shelf=1/slot=0/sub_slot=2/type=eth/port=3/cli_name=GigabitEthernet0/2/3")
//    TerminationPoint findByMeIdAndRaw(@Param("meId") Long meId, @Param("raw") String raw);
//
//    @Query("match (n:TerminationPoint) where n.meId = {meId} and n.`name.FTP` = {ftpValue}  return n")
//    TerminationPoint findByMeIdAndFTP(@Param("meId") Long meId, @Param("ftpValue") String ftpValue );
//
//    @Query("match (n:TerminationPoint) where n.meId = {meId} and n.`name.PTP` = {ptpValue}  return n")
//    TerminationPoint findByMeIdAndPTP(@Param("meId") Long meId, @Param("ptpValue") String ptpValue );

    //@Query("match (n:TermnationPoint) where n.corbaId = {corbaId} return n")
    TerminationPoint findByCorbaId(@Param("corbaId") String corbaId);

    TerminationPoint findByMeIdAndCorbaId(@Param("meId") Long meId, @Param("corbaId") String corbaId);
}
