package io.ngss.corbaprocessor.neo4j.repository;

import io.ngss.corbaprocessor.neo4j.entity.node.Circuit;
import io.ngss.corbaprocessor.neo4j.entity.node.NodeB;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;

/**
 * Created by ngsscsalur on 9/4/2019.
 */
public interface NodeBRepository extends Neo4jRepository<NodeB, Long> {

    NodeB findByName(@Param("name") String name);

    @Query("match(n:ManagedElement)-[:ROUTED_ON]-(m:Service)-[]-(r:NodeB) where n.corbaId = {meId} return r")
    Collection<NodeB> findConnectedNodebs(@Param("meId") String meId);
}
