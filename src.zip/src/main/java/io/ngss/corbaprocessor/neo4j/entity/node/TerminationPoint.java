package io.ngss.corbaprocessor.neo4j.entity.node;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import globaldefs.NameAndStringValue_T;
import io.ngss.corbaprocessor.neo4j.entity.role.*;
import lombok.*;
import org.neo4j.ogm.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by ngsscsalur on 8/23/2019.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@NodeEntity
@JsonIdentityInfo(
        generator = ObjectIdGenerators.PropertyGenerator.class,
        property = "id"
)
public class TerminationPoint {

    @Id
    @GeneratedValue
    private Long id;
    private Long meId;
    private String corbaId;
    private String nativeEMSName;


    @Properties
    private Map<String, String> name;

   /* private String raw;
    private Long meId;*/

    @JsonIgnoreProperties("terminationPoint")
    @Relationship(type = "HAS_PORT", direction = Relationship.INCOMING)
    private List<HasPort> ports = new ArrayList<>();


    // fdfr
    @JsonIgnoreProperties("terminationPoint")
    @Relationship(type = "HAS_CONNECTION", direction = Relationship.INCOMING)
    private List<HasConnection> incomingConnections = new ArrayList<>();

    @JsonIgnoreProperties("terminationPoint")
    @Relationship(type = "HAS_CONNECTION", direction = Relationship.OUTGOING)
    private List<HasConnection> outgoingConnections = new ArrayList<>();

    // mfdfr
    @JsonIgnoreProperties("terminationPoint")
    @Relationship(type = "HAS_MATRIX", direction = Relationship.INCOMING)
    private List<HasMatrix> incomingMatrices = new ArrayList<>();

    @JsonIgnoreProperties("terminationPoint")
    @Relationship(type = "HAS_MATRIX", direction = Relationship.OUTGOING)
    private List<HasMatrix> outgoingMatrices = new ArrayList<>();

    // topological link
    @JsonIgnoreProperties("terminationPoint")
    @Relationship(type = "HAS_LINK", direction = Relationship.INCOMING)
    private List<HasLink> incomingLinks = new ArrayList<>();

    @JsonIgnoreProperties("terminationPoint")
    @Relationship(type = "HAS_LINK", direction = Relationship.OUTGOING)
    private List<HasLink> outgoingLinks = new ArrayList<>();

    // binding objects traffic trunk
    @JsonIgnoreProperties("terminationPoint")
    @Relationship(type = "HAS_TRUNK", direction = Relationship.INCOMING)
    private List<HasTrunk> incomingTrunks = new ArrayList<>();

    @JsonIgnoreProperties("terminationPoint")
    @Relationship(type = "HAS_TRUNK", direction = Relationship.OUTGOING)
    private List<HasTrunk> outgoingTrunks = new ArrayList<>();


    @JsonIgnoreProperties("terminationPoint")
    @Relationship(type = "HAS_CIRCUIT", direction = Relationship.UNDIRECTED)
    private List<HasCircuit> circuits = new ArrayList<>();

    @JsonIgnoreProperties("terminationPoint")
    @Relationship(type = "CONNECTED", direction = Relationship.UNDIRECTED)
    private List<Connected> nodeBConnections = new ArrayList<>();


    public static String createCorbaId(NameAndStringValue_T[] tpName) {
        return tpName[1].value+";"+tpName[2].value;
    }

    public static Long createMeId(NameAndStringValue_T[] tpName) {
        return Long.parseLong(tpName[1].value);
    }


}
