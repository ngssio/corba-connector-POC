package io.ngss.corbaprocessor.neo4j.entity.node;

import lombok.*;
import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ngsscsalur on 9/2/2019.
 */

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@NodeEntity
public class Circuit {

    @Id
    @GeneratedValue
    private Long id;

    private String name;

    @Relationship(type = "HAS_CIRCUIT")
    private List<TerminationPoint> terminationPoints = new ArrayList<>();
}
