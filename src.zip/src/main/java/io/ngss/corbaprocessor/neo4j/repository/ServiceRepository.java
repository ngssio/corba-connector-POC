package io.ngss.corbaprocessor.neo4j.repository;

import io.ngss.corbaprocessor.neo4j.entity.node.Service;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.repository.query.Param;

/**
 * Created by ngsscsalur on 9/5/2019.
 */
public interface ServiceRepository extends Neo4jRepository<Service, Long> {

    Service findByName(@Param("name") String name);
}
