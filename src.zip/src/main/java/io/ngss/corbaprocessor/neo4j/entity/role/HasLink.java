package io.ngss.corbaprocessor.neo4j.entity.role;

import io.ngss.corbaprocessor.neo4j.entity.node.TerminationPoint;
import io.ngss.corbaprocessor.neo4j.entity.node.TopologicalLink;
import io.ngss.corbaprocessor.neo4j.entity.node.TrafficTrunk;
import lombok.*;
import org.neo4j.ogm.annotation.*;

/**
 * Created by ngsscsalur on 8/28/2019.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@RelationshipEntity(type = "HAS_LINK")
public class HasLink {

    @Id
    @GeneratedValue
    private Long id;

    @StartNode
    private TopologicalLink topologicalLink;

    @EndNode
    private TerminationPoint terminationPoint;
}
