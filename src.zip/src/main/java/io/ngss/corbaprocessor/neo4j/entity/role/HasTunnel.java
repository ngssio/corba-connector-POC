package io.ngss.corbaprocessor.neo4j.entity.role;

import io.ngss.corbaprocessor.neo4j.entity.node.FlowDomainFragment;
import io.ngss.corbaprocessor.neo4j.entity.node.ManagedElement;
import io.ngss.corbaprocessor.neo4j.entity.node.TerminationPoint;
import io.ngss.corbaprocessor.neo4j.entity.node.TrafficTrunk;
import lombok.*;
import org.neo4j.ogm.annotation.*;

import java.util.Map;

/**
 * Created by ngsscsalur on 8/27/2019.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@RelationshipEntity(type = "HAS_TUNNEL")
public class HasTunnel {

    @Id
    @GeneratedValue
    private Long id;

    @StartNode
    private TrafficTrunk trafficTrunk;

    @EndNode
    private ManagedElement managedElement;
}
