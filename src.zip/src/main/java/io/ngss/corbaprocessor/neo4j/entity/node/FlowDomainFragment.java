package io.ngss.corbaprocessor.neo4j.entity.node;

import HW_vpnManager.FlowDomainFragment_T;
import io.ngss.corbaprocessor.manager.DataManagerUpdated;
import lombok.*;
import org.neo4j.ogm.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by ngsscsalur on 8/26/2019.
 */

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@NodeEntity
public class FlowDomainFragment {
    @Id
    @GeneratedValue
    private Long id;

    private String corbaId;
    private String nativeEMSName;

    @Properties
    private Map<String, String> name;

    @Properties
    private Map<String, String> transmissionParams;


    @Relationship(type = "BINDED")
    private List<TrafficTrunk> bindingTTs = new ArrayList<>();

    @Relationship(type = "HAS_CONNECTION")
    private List<TerminationPoint> terminationPoints = new ArrayList<>();

    public static FlowDomainFragment createNode(FlowDomainFragment_T fdfr) {
        FlowDomainFragment fdfrNode = new FlowDomainFragment();
        fdfrNode.setCorbaId(fdfr.name[2].value);
        fdfrNode.setNativeEMSName(fdfr.nativeEMSName);
        fdfrNode.setName(DataManagerUpdated.getNameAsHashMap(fdfr.name));
        fdfrNode.setTransmissionParams(DataManagerUpdated.getNameAsHashMap(fdfr.aEnd[0].transmissionParams[0].transmissionParams));
        return fdfrNode;
    }



}
