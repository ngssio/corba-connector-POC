package io.ngss.corbaprocessor.neo4j.entity.node;

import HW_vpnManager.MatrixFlowDomainFragment_T;
import globaldefs.NameAndStringValue_T;
import io.ngss.corbaprocessor.manager.DataManagerUpdated;
import lombok.*;
import org.neo4j.ogm.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by ngsscsalur on 8/28/2019.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@NodeEntity
public class MatrixFlowDomainFragment {

    @Id
    @GeneratedValue
    private Long id;
    private String corbaId;
    private String nativeEMSName;
    private String userLabel;

    @Properties
    private Map<String, String> name;

    @Properties
    private Map<String, String> transmissionParams;

    @Relationship(type = "HAS_MATRIX")
    private List<TerminationPoint> terminationPoints = new ArrayList<>();

    public static MatrixFlowDomainFragment createNode(MatrixFlowDomainFragment_T mfdfr) {
        MatrixFlowDomainFragment mfdfrNode = new MatrixFlowDomainFragment();

        mfdfrNode.setCorbaId(createCorbaId(mfdfr.name));
        mfdfrNode.setNativeEMSName(mfdfr.nativeEMSName);
        mfdfrNode.setUserLabel(mfdfr.userLabel);
        mfdfrNode.setName(DataManagerUpdated.getNameAsHashMap(mfdfr.name));
        mfdfrNode.setTransmissionParams(DataManagerUpdated.getNameAsHashMap(mfdfr.aEnd[0].transmissionParams[0].transmissionParams));

        return mfdfrNode;
    }

    public static String createCorbaId(NameAndStringValue_T[] mfdfrName) {
        return mfdfrName[1].value+";"+mfdfrName[2].value;
    }
}
