package io.ngss.corbaprocessor.neo4j.repository;

import io.ngss.corbaprocessor.neo4j.entity.node.Circuit;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.repository.query.Param;

/**
 * Created by ngsscsalur on 9/2/2019.
 */
public interface CircuitRepository extends Neo4jRepository<Circuit, Long>{

    Circuit findByName(@Param("name") String name);

}
