package io.ngss.corbaprocessor.neo4j.repository;

import io.ngss.corbaprocessor.neo4j.entity.node.ManagedElement;
import org.springframework.data.neo4j.annotation.Query;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * Created by ngsscsalur on 8/23/2019.
 */
public interface ManagedElementRepository extends Neo4jRepository<ManagedElement, Long> {

    ManagedElement findByCorbaId(@Param("corbaId") String corbaId);

    @Query("MATCH (n) detach delete n")
    void clearDatabase();

    @Query("match (n:Service {vlan: ''}-[:ROUTED_ON]-(m) return m")
    Object getPath(@Param("v") String corbaId);
}
