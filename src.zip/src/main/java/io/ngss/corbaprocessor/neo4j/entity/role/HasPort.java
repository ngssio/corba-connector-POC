package io.ngss.corbaprocessor.neo4j.entity.role;

import io.ngss.corbaprocessor.neo4j.entity.node.ManagedElement;
import io.ngss.corbaprocessor.neo4j.entity.node.TerminationPoint;
import io.ngss.corbaprocessor.neo4j.entity.node.TrafficTrunk;
import lombok.*;
import org.neo4j.ogm.annotation.*;

/**
 * Created by ngsscsalur on 8/23/2019.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@RelationshipEntity(type = "HAS_PORT")
public class HasPort {

    @Id
    @GeneratedValue
    private Long id;

    @StartNode
    private ManagedElement managedElement;

    @EndNode
    private TerminationPoint tp;
}
