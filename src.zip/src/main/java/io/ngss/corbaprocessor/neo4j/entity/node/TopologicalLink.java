package io.ngss.corbaprocessor.neo4j.entity.node;

import io.ngss.corbaprocessor.manager.DataManagerUpdated;
import lombok.*;
import org.neo4j.ogm.annotation.*;
import topologicalLink.TopologicalLink_T;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by ngsscsalur on 8/28/2019.
 */

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@NodeEntity
public class TopologicalLink {

    @Id
    @GeneratedValue
    private Long id;
    private String corbaId;
    private String nativeEMSName;

    @Properties
    private Map<String, String> name;

    @Relationship(type = "HAS_LINK")
    private List<TerminationPoint> terminationPoints = new ArrayList<>();


    public static TopologicalLink createTopoNode(TopologicalLink_T topo){
        TopologicalLink topoNode = new TopologicalLink();
        topoNode.setCorbaId(topo.name[1].value);
        topoNode.setNativeEMSName(topo.nativeEMSName);
        topoNode.setName(DataManagerUpdated.getNameAsHashMap(topo.name));
        return topoNode;
    }
}
