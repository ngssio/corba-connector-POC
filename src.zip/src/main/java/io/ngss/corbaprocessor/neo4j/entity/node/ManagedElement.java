package io.ngss.corbaprocessor.neo4j.entity.node;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.ngss.corbaprocessor.neo4j.entity.role.HasTunnel;
import lombok.*;
import managedElement.ManagedElement_T;
import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ngsscsalur on 8/23/2019.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@NodeEntity
public class ManagedElement {

    @Id
    @GeneratedValue
    private Long id;

    private String corbaId;
    private String nativeEMSName;

    @Relationship(type = "HAS_PORT")
    private List<TerminationPoint> terminationPoints = new ArrayList<>();


    @JsonIgnoreProperties("managedElement")
    @Relationship(type = "HAS_TUNNEL", direction = Relationship.INCOMING)
    private List<HasTunnel> tunnelsIncoming = new ArrayList<>();

    @JsonIgnoreProperties("managedElement")
    @Relationship(type = "HAS_TUNNEL", direction = Relationship.OUTGOING)
    private List<HasTunnel> tunnelsOutgoing = new ArrayList<>();


    public static ManagedElement createNode(ManagedElement_T me) {
        ManagedElement meNode = new ManagedElement();
        meNode.setCorbaId(me.name[1].value);
        meNode.setNativeEMSName(me.nativeEMSName);
        return meNode;
    }


}
