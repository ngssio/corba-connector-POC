package io.ngss.corbaprocessor.neo4j.entity.node;

import HW_vpnManager.TrafficTrunk_T;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.ngss.corbaprocessor.manager.DataManagerUpdated;
import io.ngss.corbaprocessor.neo4j.entity.role.Binded;
import io.ngss.corbaprocessor.neo4j.entity.role.BindedTrunk;
import lombok.*;
import org.neo4j.ogm.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by ngsscsalur on 8/27/2019.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@NodeEntity
public class TrafficTrunk {

    @Id
    @GeneratedValue
    private Long id;

    private String corbaId;

    private String nativeEMSName;
    private String userLabel;
    private String workingMode;

    @Properties
    private Map<String, String> name;


    //tp
    @Relationship(type = "HAS_TRUNK")
    private List<TerminationPoint> terminationPoints = new ArrayList<>();


    // fdfr
    @JsonIgnoreProperties("trafficTrunk")
    @Relationship(type = "BINDED", direction = Relationship.INCOMING)
    private List<Binded> fdfrBindings = new ArrayList<>();

    // trunk
    @JsonIgnoreProperties("trafficTrunk")
    @Relationship(type = "BINDED_TRUNK", direction = Relationship.INCOMING)
    private List<BindedTrunk> ttBindings = new ArrayList<>();

    // tunnel
    @Relationship(type = "HAS_TUNNEL")
    private List<ManagedElement> tunnels = new ArrayList<>();


    public static TrafficTrunk createNode(TrafficTrunk_T trunk){
        TrafficTrunk ttNode = new TrafficTrunk();
        ttNode.setCorbaId(trunk.name[2].value);
        ttNode.setNativeEMSName(trunk.nativeEMSName);
        ttNode.setUserLabel(trunk.userLabel);
        ttNode.setName(DataManagerUpdated.getNameAsHashMap(trunk.name));
        return ttNode;
    }




}
