package io.ngss.corbaprocessor.neo4j.entity.node;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.ngss.corbaprocessor.neo4j.entity.role.HasCircuit;
import io.ngss.corbaprocessor.neo4j.entity.role.RoutedOn.*;
import lombok.*;
import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ngsscsalur on 9/5/2019.
 */

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@NodeEntity
public class Service {

    @Id
    @GeneratedValue
    private Long id;

    private String name;
    private String vlan;

    @JsonIgnoreProperties("service")
    @Relationship(type = "ROUTED_ON", direction = Relationship.OUTGOING)
    private List<RoutedOnNodeb> nodebs = new ArrayList<>();

    @JsonIgnoreProperties("service")
    @Relationship(type = "ROUTED_ON", direction = Relationship.OUTGOING)
    private List<RoutedOnME> managedElements = new ArrayList<>();

    @JsonIgnoreProperties("service")
    @Relationship(type = "ROUTED_ON", direction = Relationship.OUTGOING)
    private List<RoutedOnCircuit> circuits= new ArrayList<>();

    @JsonIgnoreProperties("service")
    @Relationship(type = "ROUTED_ON", direction = Relationship.OUTGOING)
    private List<RoutedOnTP> tps= new ArrayList<>();

    @JsonIgnoreProperties("service")
    @Relationship(type = "ROUTED_ON", direction = Relationship.OUTGOING)
    private List<RoutedOnTT> tts = new ArrayList<>();

    @JsonIgnoreProperties("service")
    @Relationship(type = "ROUTED_ON", direction = Relationship.OUTGOING)
    private List<RoutedOnFDFR> fdfrs = new ArrayList<>();

    @JsonIgnoreProperties("service")
    @Relationship(type = "ROUTED_ON", direction = Relationship.OUTGOING)
    private List<RoutedOnMFDFR> mfdfrs= new ArrayList<>();

    @JsonIgnoreProperties("service")
    @Relationship(type = "ROUTED_ON", direction = Relationship.OUTGOING)
    private List<RoutedOnTopo> topos= new ArrayList<>();
}
