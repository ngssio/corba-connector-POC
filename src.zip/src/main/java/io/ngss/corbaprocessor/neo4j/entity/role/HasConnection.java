package io.ngss.corbaprocessor.neo4j.entity.role;

import io.ngss.corbaprocessor.neo4j.entity.node.FlowDomainFragment;
import io.ngss.corbaprocessor.neo4j.entity.node.ManagedElement;
import io.ngss.corbaprocessor.neo4j.entity.node.TerminationPoint;
import lombok.*;
import org.neo4j.ogm.annotation.*;

import java.util.Map;

/**
 * Created by ngsscsalur on 8/26/2019.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@RelationshipEntity(type = "HAS_CONNECTION")
public class HasConnection {

    @Id
    @GeneratedValue
    private Long id;

    @StartNode
    private FlowDomainFragment fdfr;

    @EndNode
    private TerminationPoint tp;


}
