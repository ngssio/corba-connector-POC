package io.ngss.corbaprocessor.neo4j.entity.role.RoutedOn;

import io.ngss.corbaprocessor.neo4j.entity.node.FlowDomainFragment;
import io.ngss.corbaprocessor.neo4j.entity.node.ManagedElement;
import io.ngss.corbaprocessor.neo4j.entity.node.Service;
import io.ngss.corbaprocessor.neo4j.entity.node.TrafficTrunk;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.neo4j.ogm.annotation.*;

/**
 * Created by ngsscsalur on 9/5/2019.
 */

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@RelationshipEntity(type = "ROUTED_ON")
public class RoutedOnME {

    @Id
    @GeneratedValue
    private Long id;

    @StartNode
    private ManagedElement startingNode;

    @EndNode
    private Service service;
}
