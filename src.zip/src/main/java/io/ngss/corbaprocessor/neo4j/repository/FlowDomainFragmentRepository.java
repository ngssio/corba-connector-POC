package io.ngss.corbaprocessor.neo4j.repository;

import io.ngss.corbaprocessor.neo4j.entity.node.FlowDomainFragment;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.repository.query.Param;

/**
 * Created by ngsscsalur on 8/27/2019.
 */
public interface FlowDomainFragmentRepository extends Neo4jRepository<FlowDomainFragment, Long> {

    FlowDomainFragment findByNativeEMSName(@Param("nativeEMSName") String nativeEMSName);

    FlowDomainFragment findByCorbaId(@Param("corbaId") String corbaId);
}
