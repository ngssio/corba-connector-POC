package io.ngss.corbaprocessor.neo4j.repository;

import io.ngss.corbaprocessor.neo4j.entity.node.MatrixFlowDomainFragment;
import io.ngss.corbaprocessor.neo4j.entity.node.TopologicalLink;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.data.repository.query.Param;

/**
 * Created by ngsscsalur on 8/28/2019.
 */
public interface TopologicalLinkRepository extends Neo4jRepository<TopologicalLink, Long> {

    TopologicalLink findByCorbaId(@Param("corbaId") String corbaId);
}
