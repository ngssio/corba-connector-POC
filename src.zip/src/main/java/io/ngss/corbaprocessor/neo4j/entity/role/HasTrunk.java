package io.ngss.corbaprocessor.neo4j.entity.role;

import io.ngss.corbaprocessor.neo4j.entity.node.TerminationPoint;
import io.ngss.corbaprocessor.neo4j.entity.node.TopologicalLink;
import io.ngss.corbaprocessor.neo4j.entity.node.TrafficTrunk;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.neo4j.ogm.annotation.*;

/**
 * Created by ngsscsalur on 9/2/2019.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@RelationshipEntity(type = "HAS_TRUNK")
public class HasTrunk {

    @Id
    @GeneratedValue
    private Long id;

    @StartNode
    private TrafficTrunk trafficTrunk;

    @EndNode
    private TerminationPoint terminationPoint;

}
