package io.ngss.corbaprocessor;

import HW_mstpInventory.HW_Flow_T;
import HW_mstpInventory.HW_MSTPEndPoint_T;
import HW_mstpInventory.HW_VirtualBridge_T;
import HW_mstpService.HW_AtmService_T;
import HW_mstpService.HW_EthService_T;
import HW_vpnManager.MatrixFlowDomainFragment_T;
import HW_vpnManager.TrafficTrunk_T;
import HW_vpnManager.FlowDomainFragment_T;
import flowDomain.FlowDomain_T;
import globaldefs.NameAndStringValue_T;
import managedElement.ManagedElement_T;
import multiLayerSubnetwork.RouteAndTopologicalLink_T;
import subnetworkConnection.CrossConnect_T;
import subnetworkConnection.SubnetworkConnection_T;
import subnetworkConnection.TPData_T;
import terminationPoint.TerminationPoint_T;
import topologicalLink.TopologicalLink_T;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by ngssrgunaydin on 8/8/2019.
 */
public class InternalDatabase {
    public static List<ManagedElement_T> allManagedElements = new ArrayList<>();
    public static List<TerminationPoint_T> allPTPs = new ArrayList<>();
    public static List<NameAndStringValue_T[]> allPTPNames = new ArrayList<>();

    public static List<SubnetworkConnection_T> allSubnetworkConnections = new ArrayList<>();
    public static List<TopologicalLink_T> allTopologicalLinks = new ArrayList<>();
    public static List<RouteAndTopologicalLink_T> allRouteAndTopologicalLinks = new ArrayList<>();
    public static List<HW_EthService_T> allEthService = new ArrayList<>();
    public static List<HW_AtmService_T> allAtmServices = new ArrayList<>();
    public static List<TerminationPoint_T> allContainedInUseTPs = new ArrayList<>();
    public static List<SubnetworkConnection_T> allSubnetworkConnectionsByTP = new ArrayList<>();
    public static List<HW_MSTPEndPoint_T> allHwMstpEndPointTS = new ArrayList<>();
    public static List<HW_VirtualBridge_T> allHwVirtualBridges = new ArrayList<>();
    public static List<HW_Flow_T> allFlows = new ArrayList<>();
    public static List<FlowDomain_T> allFlowDomains = new ArrayList<>();
    public static List<FlowDomainFragment_T> allFlowDomainFragments = new ArrayList<>();
    public static List<TrafficTrunk_T> allTrafficTrunks = new ArrayList<>();
    public static List<TrafficTrunk_T> allTrafficTrunksWithME = new ArrayList<>();
    public static List<MatrixFlowDomainFragment_T> allMFDFrs = new ArrayList<>();
    public static List<NameAndStringValue_T[]> allTopLevelSubnetworkNames = new ArrayList<>();
    public static List<CrossConnect_T> allRoutes = new ArrayList<>();

    public static HashMap<Long, ManagedElement_T> managedElementMap = new HashMap<>();

    public static final String DELIMITER = ";";

    public static short[] layerRateList = {2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28,
            40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 58, 59,
            61, 62, 63, 64, 65, 66, 67, 68, 72, 73, 74, 75, 76, 77, 78, 110, 111, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 93, 96, 97, 98, 99, 100, 101, 103, 113, 115,
            8001, 8002, 8003, 8004, 8005, 104, 105, 106, 8041, 107, 108, 109, 8042, 8006, 8007, 303, 8023, 8024, 8021, 8038, 8022, 8037, 8025, 8031, 69, 305, 8008, 8009,
            8011, 8020, 8026, 8027, 8028, 8029, 8030, 8032, 8033, 8034, 8035, 8036, 8039, 8043, 8044, 8045, 8046, 8047, 8051, 8060, 8069, 8070,
            8071, 8072, 8073, 299, 335, 8012, 8075
    };

    public static void test() {
        System.out.println("adsas");
    }

    public static String getTrafficTrunkAsString(TrafficTrunk_T t) {

        StringBuilder sb = new StringBuilder();
        sb.append("----------------------\n");
        sb.append("|").append("TRAFFICTRUNKNAME").append("|").append(getNameAndStringValueAsString(t.name)).append("\n");
        sb.append("|").append("User Label").append("|").append(t.userLabel).append("\n");
        sb.append("|").append("Native EMS Name").append("|").append(t.nativeEMSName).append("\n");
        sb.append("|").append("Transmission Params").append("|").append("Layer").append(t.transmissionParams.layer).append(";").append(getNameAndStringValueAsString(t.transmissionParams.transmissionParams)).append("\n");
        int i = 0;
        sb.append("-----A END PORT DATA-----").append("\n");
        for (TPData_T t1 : t.aEnd) {
            sb.append("|").append("A End Port : ").append(i).append(" |").append(getNameAndStringValueAsString(t1.tpName)).append("\n");
            if (t1.transmissionParams.length > 0 && t1.transmissionParams[0].transmissionParams.length > 0)
                sb.append("|").append("TransmissionParameters").append("|").append(getNameAndStringValueAsString(t1.transmissionParams[0].transmissionParams)).append("\n");
        }
        sb.append("-----END OF A END PORT DATA-----").append("\n");
        i = 0;
        sb.append("-----Z END PORT DATA-----").append("\n");
        for (TPData_T t1 : t.zEnd) {
            sb.append("|").append("Z End Port : ").append(i).append(" |").append(getNameAndStringValueAsString(t1.tpName)).append("\n");
            if (t1.transmissionParams.length > 0 && t1.transmissionParams[0].transmissionParams.length > 0)
                sb.append("|").append("TransmissionParameters").append("|").append(getNameAndStringValueAsString(t1.transmissionParams[0].transmissionParams)).append("\n");
        }
        sb.append("-----END OF Z END PORT DATA-----").append("\n");

        return sb.toString();
    }

    public static String getMFDFRAsString(MatrixFlowDomainFragment_T m) {

        StringBuilder sb = new StringBuilder();
        sb.append("----------------------\n");
        sb.append("|").append("MFDRNAME").append("|").append(getNameAndStringValueAsString(m.name)).append("\n");
        sb.append("|").append("User Label").append("|").append(m.userLabel).append("\n");
        sb.append("|").append("Native EMS Name").append("|").append(m.nativeEMSName).append("\n");
        sb.append("|").append("Transmission Params").append("|").append("Layer").append(DELIMITER).append(m.transmissionParams.layer).append(DELIMITER).append(getNameAndStringValueAsString(m.transmissionParams.transmissionParams)).append("\n");
        int i = 0;
        sb.append("-----A END PORT DATA-----").append("\n");
        for (TPData_T t : m.aEnd) {
            sb.append("|").append("A End Port : ").append(i).append(" |").append(getNameAndStringValueAsString(t.tpName)).append("\n");
            sb.append("|").append("TransmissionParameters").append("|").append(getNameAndStringValueAsString(t.transmissionParams[0].transmissionParams)).append("\n");
        }
        sb.append("-----END OF A END PORT DATA-----").append("\n");
        i = 0;
        sb.append("-----Z END PORT DATA-----").append("\n");
        for (TPData_T t : m.zEnd) {
            sb.append("|").append("Z End Port : ").append(i).append(" |").append(getNameAndStringValueAsString(t.tpName)).append("\n");
            sb.append("|").append("TransmissionParameters").append("|").append(getNameAndStringValueAsString(t.transmissionParams[0].transmissionParams)).append("\n");
        }
        sb.append("-----END OF Z END PORT DATA-----").append("\n");

        return sb.toString();
    }

    public static String getFDFrAsString(FlowDomainFragment_T fdfr) {
        StringBuilder sb = new StringBuilder();

        sb.append("----------------------\n");
        sb.append("|").append("FDRNAME").append("|").append(getNameAndStringValueAsString(fdfr.name)).append("\n");
        sb.append("|").append("Native EMS Name").append("|").append(fdfr.nativeEMSName).append("\n");
        sb.append("|").append("Transmission Params").append("|").append("Layer").append(DELIMITER).append(fdfr.transmissionParams.layer).append(DELIMITER)
                .append(getNameAndStringValueAsString(fdfr.transmissionParams.transmissionParams)).append("\n");
        int i = 0;
        sb.append("-----A END PORT DATA-----").append("\n");
        for (TPData_T t : fdfr.aEnd) {
            sb.append("|").append("A End Port : ").append(i).append(" |").append(getNameAndStringValueAsString(t.tpName)).append("\n");
            sb.append("|").append("TransmissionParameters").append("|").append(getNameAndStringValueAsString(t.transmissionParams[0].transmissionParams)).append("\n");
        }
        sb.append("-----END OF A END PORT DATA-----").append("\n");
        i = 0;
        sb.append("-----Z END PORT DATA-----").append("\n");
        for (TPData_T t : fdfr.zEnd) {
            sb.append("|").append("Z End Port : ").append(i).append(" |").append(getNameAndStringValueAsString(t.tpName)).append("\n");
            sb.append("|").append("TransmissionParameters").append("|").append(getNameAndStringValueAsString(t.transmissionParams[0].transmissionParams)).append("\n");
        }
        sb.append("-----END OF Z END PORT DATA-----").append("\n");
        return sb.toString();
    }

    public static String getNameAndStringValueAsString(NameAndStringValue_T[] nas) {
        StringBuilder sb = new StringBuilder();

        for (NameAndStringValue_T n : nas) {
            sb.append(n.name).append(DELIMITER).append(n.value).append(DELIMITER);
        }
        String str = sb.toString();
        try {
            return str.substring(0, str.lastIndexOf(DELIMITER));
        } catch (Exception e) {
            return str;
        }
    }

    public static String getManagedElementAsString(ManagedElement_T me) {
        StringBuilder sb = new StringBuilder();
        sb.append("----------------------\n");
        sb.append("|").append("MENAME").append("|").append(getNameAndStringValueAsString(me.name)).append("\n");
        sb.append("|").append("Native EMS Name").append("|").append(me.nativeEMSName).append("\n");
        sb.append("|").append("Version").append("|").append(me.version).append("\n");
        sb.append("|").append("Product Name").append("|").append(me.productName).append("\n");
        sb.append("|").append("AdditionalInfo").append("|").append((getNameAndStringValueAsString(me.additionalInfo))).append("\n");
        return sb.toString();
    }

    public static String getTopologicalLinkAsString(TopologicalLink_T t ){
        StringBuilder sb = new StringBuilder();
        sb.append("----------------------\n");
        sb.append("|").append("TOPOLOGICALLINK").append("|").append(getNameAndStringValueAsString(t.name)).append("\n");
        sb.append("|").append("Native EMS Name").append("|").append(t.nativeEMSName).append("\n");
        sb.append("|").append("Rate").append("|").append(t.rate).append("\n");
        sb.append("|").append("A END TP").append("|").append(getNameAndStringValueAsString(t.aEndTP)).append("\n");;
        sb.append("|").append("Z END TP").append("|").append(getNameAndStringValueAsString(t.zEndTP)).append("\n");;
        sb.append("|").append("AdditionalInfo").append("|").append((getNameAndStringValueAsString(t.additionalInfo))).append("\n");
        return sb.toString();
    }

    public static String getSubnetworkConnectionAsString(SubnetworkConnection_T snc){
        StringBuilder sb = new StringBuilder();
        sb.append("----------------------\n");
        sb.append("|").append("SUBNETWORKCONNECTION").append("|").append(getNameAndStringValueAsString(snc.name)).append("\n");
        sb.append("|").append("Native EMS Name").append("|").append(snc.nativeEMSName).append("\n");
        sb.append("|").append("Rate").append("|").append(snc.rate).append("\n");
        int i = 0;
        sb.append("-----A END PORT DATA-----").append("\n");
        for (TPData_T t : snc.aEnd) {
            sb.append("|").append("A End Port : ").append(i).append(" |").append(getNameAndStringValueAsString(t.tpName)).append("\n");
            sb.append("|").append("TransmissionParameters").append("|").append(getNameAndStringValueAsString(t.transmissionParams[0].transmissionParams)).append("\n");
        }
        sb.append("-----END OF A END PORT DATA-----").append("\n");
        i = 0;
        sb.append("-----Z END PORT DATA-----").append("\n");
        for (TPData_T t : snc.zEnd) {
            sb.append("|").append("Z End Port : ").append(i).append(" |").append(getNameAndStringValueAsString(t.tpName)).append("\n");
            sb.append("|").append("TransmissionParameters").append("|").append(getNameAndStringValueAsString(t.transmissionParams[0].transmissionParams)).append("\n");
        }
        sb.append("-----END OF Z END PORT DATA-----").append("\n");
        sb.append("|").append("AdditionalInfo").append("|").append((getNameAndStringValueAsString(snc.additionalInfo))).append("\n");
        return sb.toString();
    }

}
