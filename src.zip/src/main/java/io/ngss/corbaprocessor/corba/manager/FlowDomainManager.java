package io.ngss.corbaprocessor.corba.manager;

import common.Common_I;
import common.Common_IHolder;
import emsSession.EmsSession_I;
import flowDomain.*;
import flowDomainFragment.FDFrIterator_IHolder;
import flowDomainFragment.FDFrList_THolder;
import flowDomainFragment.FlowDomainFragment_T;
import flowDomainFragment.FlowDomainFragment_THolder;
import globaldefs.NameAndStringValue_T;
import globaldefs.NamingAttributesList_THolder;
import globaldefs.ProcessingFailureException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Created by ngssrgunaydin on 8/15/2019.
 */
public class FlowDomainManager {

    private static Logger logger = LogManager.getLogger(FlowDomainManager.class);

    private EmsSession_I emsSession;

    private FlowDomainMgr_I flowDomainMgrI;

    public FlowDomainManager(EmsSession_I emsSessionI) {
        this.emsSession = emsSessionI;
    }

    protected FlowDomainMgr_I getFlowDomainMgrI() throws ProcessingFailureException {

        if (null == flowDomainMgrI) {
            logger.info("getFlowDomainMgrI started...");

            Common_IHolder FlowDomain_holder = new Common_IHolder();
            emsSession.getManager("FlowdomainManagement", FlowDomain_holder);
            Common_I mstpCommon = FlowDomain_holder.value;
            flowDomainMgrI = FlowDomainMgr_IHelper.narrow(mstpCommon);

            logger.info("getFlowDomainMgrI finished...");
        }

        return flowDomainMgrI;
    }

    public FlowDomain_T[] getAllFlowDomains() throws ProcessingFailureException {
        int how_many_me = 50000;
        FDList_THolder fdList_tHolder = new FDList_THolder();
        FDIterator_IHolder fdIterator_iHolder = new FDIterator_IHolder();

        this.getFlowDomainMgrI().getAllFlowDomains(how_many_me, fdList_tHolder, fdIterator_iHolder);
        return fdList_tHolder.value;
    }

    public FlowDomainFragment_T[] getAllFDFrs(NameAndStringValue_T[] fdName, short layerRate) throws ProcessingFailureException {
        int how_many_me = 50000;
        short[] shorts = {layerRate};
        FDFrList_THolder fdFrList_tHolder = new FDFrList_THolder();
        FDFrIterator_IHolder fdFrIterator_iHolder = new FDFrIterator_IHolder();

        this.getFlowDomainMgrI().getAllFDFrs(fdName, how_many_me, shorts, fdFrList_tHolder, fdFrIterator_iHolder);
        return fdFrList_tHolder.value;
    }


    public NameAndStringValue_T[][] getFDFrServerTrail(NameAndStringValue_T[] fdfrName) throws ProcessingFailureException {
        int how_many = 100;
        NamingAttributesList_THolder holder = new NamingAttributesList_THolder();
        getFlowDomainMgrI().getFDFrServerTrail(fdfrName, holder);
        return holder.value;
    }

    public FlowDomainFragment_T getFDFr(NameAndStringValue_T[] fdfrName) throws ProcessingFailureException {
        FlowDomainFragment_THolder holder = new FlowDomainFragment_THolder();
        getFlowDomainMgrI().getFDFr(fdfrName, holder);
        return holder.value;
    }
}
