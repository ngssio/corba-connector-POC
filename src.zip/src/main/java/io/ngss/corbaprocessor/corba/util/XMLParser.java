package io.ngss.corbaprocessor.corba.util;

import org.springframework.stereotype.Component;
import org.w3c.dom.*;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by ngsscsalur on 9/4/2019.
 */

//@Component
public class XMLParser {


    public XMLParser(){
//        parseFile("exports/CMExport_GL34_00892_MKOY_ANTIKACILAR_10.203.97.94_2019090406.xml");

        List<String> xmlfiles = listXmlFiles("exports");
        for (String filePath: xmlfiles) {
            parseFile(filePath);
        }
    }

    public static List<String> listXmlFiles(String folderPath) {

        File folder = new File(folderPath);
        List<String> xmlFiles = new ArrayList<>();
        for (File file :folder.listFiles()) {
            if(file.getName().endsWith(".xml"))
                xmlFiles.add(file.getAbsolutePath());
        }
        return xmlFiles;
    }


    public static List<XMLNode> parseFile(String filePath) {

        List<XMLNode> xmlNodes = new ArrayList<>();
        System.out.println("\nFile Name: " + filePath);

        //clean xml
//        BufferedReader reader = null;
//        String line = reader.readLine().replaceAll("[\\x00-\\x1F]", "");


        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
//        dbf.setValidating(true);
        dbf.setIgnoringElementContentWhitespace(true);

        try {

//            FileInputStream fis = new FileInputStream(filePath);
//            InputStreamReader reader = new InputStreamReader(fis, "UTF-8");
//            InputSource source = new InputSource(reader);


            Document document = dbf.newDocumentBuilder().parse(filePath);

            XPath xPath = XPathFactory.newInstance().newXPath();

            Node nameNode = (Node) xPath.compile("/MOTree/MO/attr[@name='name']").evaluate(document, XPathConstants.NODE);
            String nodeBName = nameNode.getTextContent();


            // BTS3900DEVIP alip loopint olmayanlara bakicaz
            NodeList devipNodes = (NodeList) xPath.compile("/MOTree/MO/MO[@className='BTS3900DEVIP']").evaluate(document, XPathConstants.NODESET);

            for (int i = 0; i < devipNodes.getLength() ; i++) {
                Node devipNode = devipNodes.item(i);
                NodeList attrNodes = devipNode.getChildNodes();

                String pt = findAttr(attrNodes, "name", "PT");
                if(pt != null && !pt.equals("LOOPINT")){
                    String port = findAttr(attrNodes, "name", "PN");
                    String ip = findAttr(attrNodes, "name", "IP");
                    String prefixIp1 = ip.substring(0,(ip.lastIndexOf(".")));
                    String slot = findAttr(attrNodes, "name", "SN");

                    NodeList vlans = (NodeList) xPath.compile("/MOTree/MO/MO[@className='BTS3900VLANMAP']").evaluate(document, XPathConstants.NODESET);

                    for (int j = 0; j < vlans.getLength(); j++) {
                        Node vlanNode = vlans.item(j);
                        NodeList vlanAttrs = vlanNode.getChildNodes();
                        String nextHopIp = findAttr(vlanAttrs, "name", "NEXTHOPIP");
                        String prefixIp2 = nextHopIp.substring(0,(nextHopIp.lastIndexOf(".")));

                        if(prefixIp1.equals(prefixIp2)){
                            String vlan = findAttr(vlanAttrs, "name", "VLANID");
                            System.out.println("port: " + port +  ", slot: " + slot + ", vlan: " + vlan);
                            XMLNode xmlNode = new XMLNode(nodeBName,port,slot,vlan);
                            xmlNodes.add(xmlNode);
                        }
                    }

                }
            }

            return xmlNodes;

        } catch (Exception e){
            e.printStackTrace();
        }

        return xmlNodes;
    }


    public static String findAttr(NodeList attrNodes, String attrKey, String attrValue){
        for (int j = 0; j <  attrNodes.getLength(); j++) {
            Node attrNode = attrNodes.item(j);
            if (attrNode.hasAttributes()){
                Node pt =  attrNode.getAttributes().getNamedItem(attrKey);
                if(pt != null && pt.getNodeValue().equals(attrValue)){
                    return attrNode.getTextContent();
                }
            }
        }
        return null;
    }
}
