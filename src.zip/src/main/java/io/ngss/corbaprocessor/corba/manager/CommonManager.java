package io.ngss.corbaprocessor.corba.manager;

import common.CapabilityList_THolder;
import common.Common_I;
import common.Common_IHolder;
import emsMgr.EMSMgr_I;
import emsMgr.EMSMgr_IHelper;
import emsSession.EmsSession_I;
import globaldefs.NameAndStringValue_T;
import globaldefs.ProcessingFailureException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Created by ngsscsalur on 8/19/2019.
 */
public class CommonManager {

    private static Logger logger = LogManager.getLogger(CommonManager.class);

    private EmsSession_I emsSession;
    private Common_I common_i;

    public CommonManager(EmsSession_I emsSession){
        this.emsSession = emsSession;
    }

    protected Common_I getCommonI() throws ProcessingFailureException {
        if (null == common_i) {
            logger.info("getCommonI started...");

            Common_IHolder common_iHolder = new Common_IHolder();
            emsSession.getManager("Common", common_iHolder);
            Common_I common = common_iHolder.value;
            common_i = EMSMgr_IHelper.narrow(common);

            logger.info("getCommonI finished...");
        }
        return common_i;
    }

    public NameAndStringValue_T[] getCapabilities() throws ProcessingFailureException {
        CapabilityList_THolder capabilityList_tHolder = new CapabilityList_THolder();
        this.getCommonI().getCapabilities(capabilityList_tHolder);

        return capabilityList_tHolder.value;

    }

}
