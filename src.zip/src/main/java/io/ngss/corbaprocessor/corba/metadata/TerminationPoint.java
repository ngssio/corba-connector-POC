package io.ngss.corbaprocessor.corba.metadata;

import globaldefs.NameAndStringValue_T;
import io.ngss.corbaprocessor.corba.interfaces.CSVCompatible;
import lombok.*;

import java.io.Serializable;

/**
 * Created by ngsscsalur on 8/5/2019.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class TerminationPoint implements Serializable, CSVCompatible {
    private Integer rackNo;
    private Integer shelfNo;
    private Integer slotNo;
    private Integer portNo;
    private String domain;
    private NameAndStringValue_T[] corbaName;
    private String nativeEmsName;
    private ManagedElement me;

    @Override
    public String toCSVString() {
        return String.format("%d,%d,%d,%d,%s,%d",
                me.getId(), rackNo, shelfNo, slotNo, nativeEmsName, portNo);
    }

    @Override
    public String CSVHeaders() {
        return "ManagedElementId,RackNo,ShelfNo,SlotNo,NativeEmsName,PortNo";
    }
}
