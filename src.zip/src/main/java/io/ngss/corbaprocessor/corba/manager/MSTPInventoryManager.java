package io.ngss.corbaprocessor.corba.manager;

import HW_mstpInventory.*;
import common.Common_I;
import common.Common_IHolder;
import emsSession.EmsSession_I;
import globaldefs.NameAndStringValue_T;
import globaldefs.ProcessingFailureException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Created by ngssrgunaydin on 8/9/2019.
 */
public class MSTPInventoryManager {

    private static Logger logger = LogManager.getLogger(MSTPServiceManager.class);

    private EmsSession_I emsSession;
    private HW_MSTPInventoryMgr_I hw_mstpInventoryMgr_i;

    public MSTPInventoryManager(EmsSession_I emsSessionI) {
        this.emsSession = emsSessionI;
    }

    protected HW_MSTPInventoryMgr_I getMstpInventoryManager() throws ProcessingFailureException {

        if (null == hw_mstpInventoryMgr_i) {
            logger.info("getmstpInventoryManager started...");

            Common_IHolder MSTPInventory_holder = new Common_IHolder();
            emsSession.getManager("CORBA_MSTP_INV", MSTPInventory_holder);
            Common_I mstpCommon = MSTPInventory_holder.value;
            hw_mstpInventoryMgr_i = HW_MSTPInventoryMgr_IHelper.narrow(mstpCommon);

            logger.info("getmstpInventoryManager finished...");
        }
        return hw_mstpInventoryMgr_i;
    }

    public HW_MSTPEndPoint_T[] getAllMstpEndPoints(NameAndStringValue_T[] meName) throws ProcessingFailureException {

        int how_many_me = 50000;

        HW_MSTPEndPointType_T[] endPointTypes = {
                HW_MSTPEndPointType_T.HW_MEPT_ATM,
                HW_MSTPEndPointType_T.HW_MEPT_ATMTRUNK,
                HW_MSTPEndPointType_T.HW_MEPT_ETH,
                HW_MSTPEndPointType_T.HW_MEPT_ETHTRUNK,
                HW_MSTPEndPointType_T.HW_MEPT_LP,
//                HW_MSTPEndPointType_T.HW_MEPT_NA,
                HW_MSTPEndPointType_T.HW_MEPT_RPR
        };

        HW_MSTPEndPointList_THolder endPointListTHolder = new HW_MSTPEndPointList_THolder();
        HW_MSTPEndPointIterator_IHolder endPointIteratorIHolder = new HW_MSTPEndPointIterator_IHolder();

        this.getMstpInventoryManager().getAllMstpEndPoints(meName, new HW_MSTPEndPointType_T[0], how_many_me, endPointListTHolder, endPointIteratorIHolder);
        return endPointListTHolder.value;

    }

    public HW_VirtualBridge_T[] getAllVBs(NameAndStringValue_T[] meName) throws ProcessingFailureException {
        int how_many_me = 50000;

        HW_VirtualBridgeList_THolder holder = new HW_VirtualBridgeList_THolder();
        HW_VirtualBridgeIterator_IHolder iterator = new HW_VirtualBridgeIterator_IHolder();

        this.getMstpInventoryManager().getAllVBs(meName,how_many_me,holder,iterator);
        return holder.value;

    }

    public HW_Flow_T[] getAllFlows(NameAndStringValue_T[] meName) throws ProcessingFailureException {
        int how_many_me = 50000;

        HW_FlowList_THolder holder = new HW_FlowList_THolder();
        HW_FlowIterator_IHolder iterator = new HW_FlowIterator_IHolder();

        this.getMstpInventoryManager().getAllFlows(meName,how_many_me,holder,iterator);

        return holder.value;

    }

}
