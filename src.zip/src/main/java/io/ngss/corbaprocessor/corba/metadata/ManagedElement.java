package io.ngss.corbaprocessor.corba.metadata;

import globaldefs.NameAndStringValue_T;
import io.ngss.corbaprocessor.corba.interfaces.CSVCompatible;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.io.Serializable;

/**
 * Created by ngsscsalur on 8/5/2019.
 */
@Getter
@AllArgsConstructor
public class ManagedElement implements Serializable, CSVCompatible {

    private Integer id;
    private String name;
    private String productName;
    private NameAndStringValue_T[] nameAndStringValue;


    @Override
    public String toCSVString() {
        return String.format("%d,%s,%s,%s,%s,%s,%s", this.getId(), this.getName(), this.getProductName(),
                this.getNameAndStringValue()[0].name,this.getNameAndStringValue()[0].value,this.getNameAndStringValue()[1].name,this.getNameAndStringValue()[1].value );
    }

    @Override
    public String CSVHeaders() {
        return "Id,Name,ProductName,NS[0].name,NS[0].value,NS[1].name,NS[1].value";
    }

    @Override
    public String toString() {
        return "ManagedElement{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", productName='" + productName + '\'' +
                ", nameAndStringValue[0]=" + nameAndStringValue[0].value +
                ", nameAndStringValue[1]=" + nameAndStringValue[1].value +
                '}';
    }
}
