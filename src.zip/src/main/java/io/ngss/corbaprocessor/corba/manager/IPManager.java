package io.ngss.corbaprocessor.corba.manager;

import common.Common_I;
import common.Common_IHolder;
import emsSession.EmsSession_I;
import globaldefs.ProcessingFailureException;
import ipMgr.IPMgr_I;
import ipMgr.IPMgr_IHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Created by ngsscsalur on 8/22/2019.
 */
public class IPManager {

    private static Logger logger = LogManager.getLogger(IPManager.class);

    private EmsSession_I emsSession;
    private IPMgr_I ipManager;

    public IPManager(EmsSession_I emsSession) {
        this.emsSession = emsSession;
    }

    protected IPMgr_I getIPManager() throws ProcessingFailureException {
        if (null == ipManager) {
            logger.info("getIPManager started...");

            Common_IHolder IP_holder = new Common_IHolder();
            emsSession.getManager("CORBA_VPN", IP_holder);
            Common_I mstpCommon = IP_holder.value;
            ipManager = IPMgr_IHelper.narrow(mstpCommon);

            logger.info("getIPManager finished...");
        }

        return ipManager;

    }
}
