package io.ngss.corbaprocessor.corba.manager;

import HW_mstpService.*;
import common.Common_I;
import common.Common_IHolder;
import emsSession.EmsSession_I;
import globaldefs.NameAndStringValue_T;
import globaldefs.ProcessingFailureException;
import io.ngss.corbaprocessor.InternalDatabase;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Created by ngssrgunaydin on 8/8/2019.
 */
public class MSTPServiceManager {

    private static Logger logger = LogManager.getLogger(MSTPServiceManager.class);

    private EmsSession_I emsSession;
    private HW_MSTPServiceMgr_I mstpServiceManager;


    public MSTPServiceManager(EmsSession_I emsSessionI) {
        this.emsSession = emsSessionI;
    }

    protected HW_MSTPServiceMgr_I getMstpServiceManager() throws ProcessingFailureException {

        if (null == mstpServiceManager) {
            logger.info("getmstpServiceManager started...");

            Common_IHolder MSTPService_holder = new Common_IHolder();
            emsSession.getManager("CORBA_MSTP_SVC", MSTPService_holder);
            Common_I mstpCommon = MSTPService_holder.value;
            mstpServiceManager = HW_MSTPServiceMgr_IHelper.narrow(mstpCommon);

            logger.info("getmstpServiceManager finished...");
        }

        return mstpServiceManager;

    }


    public HW_EthService_T[] getAllEthService(NameAndStringValue_T[] meName) throws ProcessingFailureException {

        int how_many_me = 50000;

        HW_EthServiceType_T[] ethServiceTypes = {
                HW_EthServiceType_T.HW_EST_EPL,
                HW_EthServiceType_T.HW_EST_EPLAN,
                HW_EthServiceType_T.HW_EST_EVPL,
                HW_EthServiceType_T.HW_EST_EVPLAN,
//                HW_EthServiceType_T.HW_EST_NA
        };

        HW_EthServiceList_THolder ethServiceList_tHolder = new HW_EthServiceList_THolder();
        HW_EthServiceIterator_IHolder ethServiceIterator_iHolder = new HW_EthServiceIterator_IHolder();

        this.getMstpServiceManager().getAllEthService(meName, new HW_EthServiceType_T[0], how_many_me, ethServiceList_tHolder, ethServiceIterator_iHolder);

        return ethServiceList_tHolder.value;
    }

    public void getAllATMService(NameAndStringValue_T[] meName) throws ProcessingFailureException {
        int how_many_me = 50000;
        HW_AtmServiceType_T[] atmServiceTypes = {
//                HW_AtmServiceType_T.HW_AST_PVP,
//                HW_AtmServiceType_T.HW_AST_PVC,
                HW_AtmServiceType_T.HW_AST_NA
        };

        HW_AtmServiceList_THolder holder = new HW_AtmServiceList_THolder();
        HW_AtmServiceIterator_IHolder iterator = new HW_AtmServiceIterator_IHolder();

        this.getMstpServiceManager().getAllAtmService(meName,atmServiceTypes,how_many_me,holder,iterator);

        for(HW_AtmService_T atmService : holder.value){
            InternalDatabase.allAtmServices.add(atmService);
        }
    }

}
