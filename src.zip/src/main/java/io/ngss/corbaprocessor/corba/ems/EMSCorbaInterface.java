package io.ngss.corbaprocessor.corba.ems;

import java.util.LinkedHashMap;

/**
 * Created by ngsscsalur on 8/5/2019.
 */
public interface EMSCorbaInterface {
    String host();
    String port();
    String username();
    String password();
    LinkedHashMap<String, String> nameComponents();
}
