package io.ngss.corbaprocessor.corba.manager;

import common.Common_I;
import common.Common_IHolder;
import emsMgr.EMSMgr_I;
import emsMgr.EMSMgr_IHelper;
import emsSession.EmsSession_I;
import globaldefs.NameAndStringValue_T;
import globaldefs.NamingAttributesIterator_IHolder;
import globaldefs.NamingAttributesList_THolder;
import globaldefs.ProcessingFailureException;
import io.ngss.corbaprocessor.InternalDatabase;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Created by ngssrgunaydin on 8/16/2019.
 */
public class EMSManager {

    private static Logger logger = LogManager.getLogger(MSTPServiceManager.class);

    private EmsSession_I emsSession;

    private EMSMgr_I emsMgrI;

    public EMSManager(EmsSession_I emsSession) {
        this.emsSession = emsSession;
    }

    protected EMSMgr_I getEmsMgrI() throws ProcessingFailureException {
        if (null == emsMgrI) {
            logger.info("getEmsMgrI started...");

            Common_IHolder MSTPService_holder = new Common_IHolder();
            emsSession.getManager("EMS", MSTPService_holder);
            Common_I mstpCommon = MSTPService_holder.value;
            emsMgrI = EMSMgr_IHelper.narrow(mstpCommon);

            logger.info("getEmsMgrI finished...");
        }
        return emsMgrI;
    }

    public NameAndStringValue_T[][] getAllTopLevelSubnetworkNames() throws ProcessingFailureException {
        int how_many_me = 50000;

        NamingAttributesList_THolder listTHolder = new NamingAttributesList_THolder();

        NamingAttributesIterator_IHolder iteratorIHolder = new NamingAttributesIterator_IHolder();

        this.getEmsMgrI().getAllTopLevelSubnetworkNames(how_many_me, listTHolder, iteratorIHolder);

        return listTHolder.value;

//        for (NameAndStringValue_T[] value : listTHolder.value) {
//            InternalDatabase.allTopLevelSubnetworkNames.add(value);
//        }
    }
}
