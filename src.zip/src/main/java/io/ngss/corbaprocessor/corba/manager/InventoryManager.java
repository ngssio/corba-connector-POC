package io.ngss.corbaprocessor.corba.manager;

import emsSession.EmsSession_I;
import globaldefs.NameAndStringValue_T;
import globaldefs.ProcessingFailureException;
import io.ngss.corbaprocessor.corba.metadata.ManagedElement;
import io.ngss.corbaprocessor.corba.metadata.TerminationPoint;
import io.ngss.corbaprocessor.corba.metadata.TopologicalLink;
import managedElement.ManagedElement_T;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.omg.CORBA.ORB;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;

/**
 * Created by ngsscsalur on 8/5/2019.
 */
public class InventoryManager {

    private ORB orb;
    private EmsSession_I emsSession;

    public MLSNManager mlsnManager = null;
    public ManagedElementManager managedElementManager = null;
    public MSTPServiceManager mstpServiceManager = null;
    public MSTPInventoryManager mstpInventoryManager = null;
    public FlowDomainManager flowDomainManager = null;
    public VPNManager vpnManager = null;
    public EMSManager emsManager = null;
    public CommonManager commonManager = null;
    public EquipmentInventoryManager equipmentInventoryManager = null;

    private HashMap<Integer, ManagedElement> meList = new HashMap<>();
    private Collection<TopologicalLink> topoLinks = null;
    private Collection<ManagedElement> managedElements = null;
    private Collection<TerminationPoint> terminationPoints = null;

    private static Logger logger = LogManager.getLogger(InventoryManager.class);

    public InventoryManager(ORB orb, EmsSession_I emsSession) {
        this.orb = orb;
        this.emsSession = emsSession;
        this.getManagedElementManager();
        this.getMLSNManager();
        this.getMstpServiceManager();
        this.getMstpInventoryManager();
        this.getFlowDomainManager();
        this.getVpnManager();
        this.getEmsManager();
        this.getCommonManager();
        this.getEquipmentInventoryManager();
    }


    public Collection<TopologicalLink> getAllTopologicalLinks() throws ProcessingFailureException {
        mlsnManager = getMLSNManager();
        managedElementManager = getManagedElementManager();
        topoLinks = mlsnManager.getAllTopologicalLinks(meList, managedElementManager);

       /* managedElementManager = getManagedElementManager();
        topoLinks = this.getManagedElementManager()*/

        return topoLinks;
    }


    private MLSNManager getMLSNManager() {

        if (null == mlsnManager) {
            mlsnManager = new MLSNManager(emsSession);
        }
        return mlsnManager;
    }

    private ManagedElementManager getManagedElementManager() {
        if (null == managedElementManager) {
            managedElementManager = new ManagedElementManager(emsSession);
            logger.info("Managed Element Manager Created!");
        }
        return managedElementManager;
    }

    private EMSManager getEmsManager() {
        if (null == emsManager) {
            emsManager = new EMSManager(emsSession);
            logger.info("EMS Manager Created!");
        }
        return emsManager;
    }

    private FlowDomainManager getFlowDomainManager() {
        if (null == flowDomainManager) {
            flowDomainManager = new FlowDomainManager(emsSession);
            logger.info("FlowDomain Service Manager Created!");
        }
        return flowDomainManager;
    }

    private MSTPServiceManager getMstpServiceManager() {
        if (null == mstpServiceManager) {
            mstpServiceManager = new MSTPServiceManager(emsSession);
            logger.info("MSTP Service Manager Created!");
        }
        return mstpServiceManager;
    }

    private MSTPInventoryManager getMstpInventoryManager() {
        if (null == mstpInventoryManager) {
            mstpInventoryManager = new MSTPInventoryManager(emsSession);
            logger.info("MSTP Inventory Manager Created!");
        }
        return mstpInventoryManager;
    }

    private VPNManager getVpnManager() {
        if (null == vpnManager) {
            vpnManager = new VPNManager(emsSession);
            logger.info("VPN Manager Created!");
        }
        return vpnManager;
    }

    private CommonManager getCommonManager() {
        if(null == commonManager){
            commonManager = new CommonManager(emsSession);
            logger.info("Common Manager Created!");
        }
        return commonManager;
    }

    private EquipmentInventoryManager getEquipmentInventoryManager() {
        if(null == equipmentInventoryManager){
            equipmentInventoryManager= new EquipmentInventoryManager(emsSession);
            logger.info("EquipmentInventoryManager Created!");
        }
        return equipmentInventoryManager;
    }

    public Collection<ManagedElement> getAllManagedElements() throws ProcessingFailureException {
        if (meList.size() < 1) {
            //meList = getMLSNManager().getAllManagedElements();
            //meList = (new ManagedElementManager(CorbaConnection.getInstance().getEmsSession())).getAllManagedElements();
            meList = getManagedElementManager().getAllManagedElements();
        }

        managedElements = meList.values();
        logger.info("All Managed Elements have taken");

        return managedElements;
    }

    public ManagedElement_T getManagedElement(NameAndStringValue_T[] name) throws ProcessingFailureException {
        //todo
        return getManagedElementManager().getManagedElement(name);
    }


    public void getAllCrossConnection(NameAndStringValue_T[] managedElementName) throws ProcessingFailureException {
        this.getManagedElementManager().getAllCrossConnection(managedElementName);
    }

//    public void getSNC() throws ProcessingFailureException {
//        //this.getMLSNManager().getSNC(" ");
//        this.getMLSNManager().getAllSubnetworkConnections();
//    }

    public Collection<ManagedElement> getAllMLSNManagedElements() throws ProcessingFailureException {

        managedElements = this.getMLSNManager().getAllManagedElements().values();
        logger.info("All MLSN Managed Elements have taken");

        return managedElements;
    }


    public Collection<TerminationPoint> getAllTerminationPoints() throws ProcessingFailureException {

        if (topoLinks.size() < 1) {
            topoLinks = getAllTopologicalLinks();
        }
        terminationPoints = new ArrayList<>();
        if (terminationPoints.size() < 1) {
            for (TopologicalLink topologicalLink : topoLinks) {
                terminationPoints.addAll(Arrays.asList(topologicalLink.getAEndTerminationPoint(), topologicalLink.getZEndTerminationPoint()));
            }
        }
        return terminationPoints;
    }
}
