package io.ngss.corbaprocessor.corba.manager;

import common.Common_I;
import common.Common_IHolder;
import emsSession.EmsSession_I;
import globaldefs.NameAndStringValue_T;
import globaldefs.NamingAttributesIterator_IHolder;
import globaldefs.NamingAttributesList_THolder;
import globaldefs.ProcessingFailureException;
import io.ngss.corbaprocessor.InternalDatabase;
import io.ngss.corbaprocessor.corba.metadata.ManagedElement;
import managedElement.ManagedElementIterator_IHolder;
import managedElement.ManagedElementList_THolder;
import managedElement.ManagedElement_T;
import managedElement.ManagedElement_THolder;
import managedElementManager.ManagedElementMgr_I;
import managedElementManager.ManagedElementMgr_IHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import subnetworkConnection.*;
import terminationPoint.TerminationPointIterator_IHolder;
import terminationPoint.TerminationPointList_THolder;
import terminationPoint.TerminationPoint_T;
import terminationPoint.TerminationPoint_THolder;

import java.util.HashMap;

/**
 * Created by ngsscsalur on 8/5/2019.
 */
public class ManagedElementManager {

    private static Logger logger = LogManager.getLogger(ManagedElementManager.class);


    private EmsSession_I emsSession;
    private ManagedElementMgr_I managedElementMgrI = null;


    public ManagedElementManager(EmsSession_I emsSession) {
        this.emsSession = emsSession;
    }

    public ManagedElementMgr_I getManagedElementManager() {
        try {
            if (null == managedElementMgrI) {

                Common_IHolder managedElementHolder = new Common_IHolder();

                emsSession.getManager("ManagedElement", managedElementHolder);

                Common_I meManagerCommon = managedElementHolder.value;
                managedElementMgrI = ManagedElementMgr_IHelper.narrow(meManagerCommon);

            }
        } catch (ProcessingFailureException e) {
            e.printStackTrace();
            logger.error("failed!", e);
        }

        return managedElementMgrI;
    }

    public TerminationPoint_T getTP(NameAndStringValue_T[] tpName) throws ProcessingFailureException {
        TerminationPoint_THolder tpHolder = new TerminationPoint_THolder();

        this.getManagedElementManager().getTP(tpName, tpHolder);
        return tpHolder.value;
    }

    public ManagedElement_T getManagedElement(NameAndStringValue_T[] name) throws ProcessingFailureException {

        ManagedElement_THolder meHolder = new ManagedElement_THolder();
        this.getManagedElementManager().getManagedElement(name, meHolder);

        return meHolder.value;
    }

    public HashMap<Integer, ManagedElement> getAllManagedElements() throws ProcessingFailureException {

        HashMap<Integer, ManagedElement> meList = new HashMap<>();

        ManagedElementList_THolder meListHolder = new ManagedElementList_THolder();
        ManagedElementIterator_IHolder meListIt = new ManagedElementIterator_IHolder();

        int how_many_me = 50000;


        this.getManagedElementManager().getAllManagedElements(how_many_me, meListHolder, meListIt);

        for (ManagedElement_T me : meListHolder.value) {
            ManagedElement managedElement = new ManagedElement(
                    Integer.parseInt(me.name[1].value),
                    me.nativeEMSName,
                    me.productName,
                    me.name);
            meList.put(managedElement.getId(), managedElement);
            InternalDatabase.allManagedElements.add(me);
            InternalDatabase.managedElementMap.put(Long.parseLong(me.name[1].value), me);
        }

        return meList;
    }

    public TerminationPoint_T[] getAllPTPs(NameAndStringValue_T[] meName) throws ProcessingFailureException {

        TerminationPointList_THolder tpListHolder = new TerminationPointList_THolder();
        TerminationPointIterator_IHolder tpIterator = new TerminationPointIterator_IHolder();

        int how_many_me = 50000;
        short[] shorts = new short[0];
        short[] shorts1 = new short[0];

        this.getManagedElementManager().getAllPTPs(meName, shorts, shorts1, how_many_me, tpListHolder, tpIterator);
        logger.info("getAllPTPs length: " + tpListHolder.value.length);
        return tpListHolder.value;

//        for (TerminationPoint_T tp : tpListHolder.value) {
//            if (!tp.nativeEMSName.equals(""))
//                InternalDatabase.allPTPs.add(tp);
//        }
    }

    public void getAllPTPNames(NameAndStringValue_T[] meName) throws ProcessingFailureException {
        NamingAttributesList_THolder namingAttributesList_tHolder = new NamingAttributesList_THolder();
        NamingAttributesIterator_IHolder namingAttributesIterator_iHolder = new NamingAttributesIterator_IHolder();

        int how_many_me = 50000;
        short[] shorts = new short[0];
        short[] shorts1 = new short[0];

        this.getManagedElementManager().getAllPTPNames(meName, shorts, shorts1, how_many_me, namingAttributesList_tHolder, namingAttributesIterator_iHolder);

        for (NameAndStringValue_T[] value : namingAttributesList_tHolder.value) {
            InternalDatabase.allPTPNames.add(value);
        }
    }

    public void getContainedInUseTPs(NameAndStringValue_T[] tpName) throws ProcessingFailureException {
        TerminationPointList_THolder tpListHolder = new TerminationPointList_THolder();
        TerminationPointIterator_IHolder tpIterator = new TerminationPointIterator_IHolder();

        short[] shorts = new short[0];
        int how_many_me = 50000;

        this.getManagedElementManager().getContainedInUseTPs(tpName, shorts, how_many_me, tpListHolder, tpIterator);
        logger.info("getContainedInUseTPs length: " + tpListHolder.value.length);

        for (TerminationPoint_T tp : tpListHolder.value) {
            InternalDatabase.allContainedInUseTPs.add(tp);
        }

    }

    public CrossConnect_T[] getAllCrossConnection(NameAndStringValue_T[] managedElementName) throws ProcessingFailureException {

        int how_many_me = 50000;
        short[] shorts = {2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27,
                28, 42, 43, 44, 45, 46, 47, 48, 58, 59, 61, 62, 63, 64, 65, 66, 67, 68, 72, 73, 74, 75, 76, 77, 78, 110,
                111, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 96, 97, 98, 99, 100, 101, 113, 115, 8001, 8002,
                8003, 8004, 8005, 8042, 303, 8023, 8024, 8021, 8038, 8022, 8037, 8025, 69, 305, 8008, 8009, 8011, 8020,
                8026, 8027, 8028, 8029, 8030, 8032, 8033, 8035, 8036, 8039, 8043, 8044, 8045, 8046, 8047, 8051, 8060,
                8069, 8070, 299, 8012, 8075};

        CrossConnectList_THolder ccListHolder = new CrossConnectList_THolder();
        CCIterator_IHolder ccIterator = new CCIterator_IHolder();

        this.getManagedElementManager().getAllCrossConnections(managedElementName, shorts, how_many_me, ccListHolder, ccIterator);
        return ccListHolder.value;
    }

//    public void getTP(NameAndStringValue_T[] tpName) throws ProcessingFailureException{
//        TerminationPoint_THolder tpHolder = new TerminationPoint_THolder();
//        this.getManagedElementManager().getTP(tpName,tpHolder);
//        return tpHolder.value;
//    }

    public TPData_T[] getFTPMembers(NameAndStringValue_T[] ftpName) throws ProcessingFailureException {
        TPDataList_THolder holder = new TPDataList_THolder();

        this.getManagedElementManager().getFTPMembers(ftpName, holder);

        return holder.value;
    }

    public NameAndStringValue_T[][] getNEStaticInfo(NameAndStringValue_T[] meName) throws ProcessingFailureException {
        int how_many = 50000;

        NamingAttributesList_THolder holder = new NamingAttributesList_THolder();
        NamingAttributesIterator_IHolder iterator = new NamingAttributesIterator_IHolder();

        this.getManagedElementManager().getNEStaticInfo(meName, how_many, holder, iterator);

        return holder.value;
    }


    public NameAndStringValue_T[] getNameAndStringValue(String managedElementName) {

        NameAndStringValue_T[] name = {new NameAndStringValue_T("EMS", "Huawei/T2000"), new NameAndStringValue_T("ManagedElement", managedElementName)};

        return name;
    }


}
