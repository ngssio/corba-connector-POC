package io.ngss.corbaprocessor.corba.connection;

import emsSession.EmsSession_I;
import emsSession.EmsSession_IHolder;
import emsSession.EmsSession_IPackage.managerNames_THolder;
import emsSessionFactory.EmsSessionFactory_I;
import emsSessionFactory.EmsSessionFactory_IHelper;
import globaldefs.ProcessingFailureException;
import io.ngss.corbaprocessor.corba.ems.EMSCorbaInterface;
import nmsSession.NmsSession_I;
import nmsSession.NmsSession_IPOA;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContext;
import org.omg.CosNaming.NamingContextExt;
import org.omg.DynamicAny.DynAnyFactory;
import org.omg.DynamicAny.DynAnyFactoryHelper;
import org.omg.PortableServer.POAManagerPackage.AdapterInactive;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by ngsscsalur on 8/5/2019.
 */
public class CorbaConnection {
    private static Logger logger = LogManager.getLogger(CorbaConnection.class);

    static Object obj;
    //ORB object
    private static org.omg.CORBA.ORB orb = null;
    //POA object reference
    private static org.omg.PortableServer.POA rootPOA = null;
    //emsSeesion object
    private static EmsSession_I emsSession = null;
    //Tanmssession object
    private static NmsSession_IPOA pNmsSessionServant = null;
    //nmsSession object
    private static NmsSession_I NmsSession = null;

    private boolean isConnected=false;

    //dynamic any factory,  for translating any type to dynamic any type
    private static DynAnyFactory dynAnyFactory = null;
    private static CorbaConnection instance = new CorbaConnection();

    public EMSCorbaInterface ems;

    public CorbaConnection() {
    }

    public static CorbaConnection getInstance() {
        return instance;
    }

    private static void setInstance(CorbaConnection instance) {
        CorbaConnection.instance = instance;
    }

    private static void constructDynFactory() {
        try {
            dynAnyFactory = DynAnyFactoryHelper.narrow(orb
                    .resolve_initial_references("DynAnyFactory"));

        } catch (InvalidName invalidName) {
            invalidName.printStackTrace();
            logger.error("failed!",invalidName);
        }
        logger.info("the step 3: construct dynamic any factory."
              + (dynAnyFactory != null ? "successfully!" : "failed!"));
    }

    public static DynAnyFactory getDynAnyFactory() {
        if (null == dynAnyFactory) {
            constructDynFactory();
        }
        return dynAnyFactory;
    }

    /**
     * Setter function, set dynAnyFactory
     */
    private static void setDynAnyFactory(DynAnyFactory dynAnyFactory) {
        CorbaConnection.dynAnyFactory = dynAnyFactory;
    }

    /**
     * Getter function, return isConnected
     */
    public boolean isConnected() {
        return isConnected;
    }

    /**
     * Getter function, return emsSession
     */
    public static EmsSession_I getEmsSession() {
        return emsSession;
    }

    /**
     * Setter function, set emsSession
     */
    private static void setEmsSession(EmsSession_I emsSession) {
        CorbaConnection.emsSession = emsSession;
    }

    /**
     * Getter function, return orb
     */
    public static org.omg.CORBA.ORB getOrb() {
        return orb;
    }

    /**
     * Setter function,set orb
     */
    private static void setOrb(org.omg.CORBA.ORB orb) {
        CorbaConnection.orb = orb;
    }

    /**
     * Getter function, return rootPOA
     */
    private static org.omg.PortableServer.POA getRootPOA() {
        return rootPOA;
    }

    /**
     * Setter function,set rootPOA
     */
    private static void setRootPOA(org.omg.PortableServer.POA rootPOA) {
        CorbaConnection.rootPOA = rootPOA;
    }

    public int connect(EMSCorbaInterface ems) throws Exception {
        int status = 0;
        /*if(this.isConnected){
            disconnect();
        }
        this.ems = ems;
        logger.info("Corba new connection is in progress!");
        CorbaConnection.getInstance().connectToInterface(ems.host(), ems.port(), ems.username(), ems.password());*/

        if(!this.isConnected) {
            this.ems = ems;
            status = CorbaConnection.getInstance().connectToInterface(ems.host(), ems.port(), ems.username(), ems.password());
        }
        //orb.run();
        return status;
    }

    public void disconnect() {

        emsSession.endSession();
        pNmsSessionServant.endSession();
        //orb.disconnect(emsSession);
        NmsSession.endSession();
        orb.destroy();
        isConnected = false;

        logger.info("Disconnected!");
    }

    public int connectToInterface(String host, String port, String username, String password) throws Exception {

        //The step 1: initialize ORB
        initializeOrb(host, port);

        //The step 2: get RootPOA
        startRootPOA();

        //the step 3: construct dynamic any factory
        constructDynFactory();

        //The step 4: get naming service root object reference
        NamingContext nc = getNamingRootObj();
        if(nc == null ){
            return 200;
        }

        //The step 5: get EmsSessionFactory_I object reference from naming service

        //construct EmsSessionFactory_I NameComponent,please get it's parameters from HuaWei
        EmsSessionFactory_I EmsSessionFactory = constructEmsSessionFactory(nc);

        //get emsSession
        NmsSession = constructEmsSession();

        //The step 6: invoke getEmsSession interface to login U2000 CORBA

        int status = loginToCorba(EmsSessionFactory, username, password, NmsSession);

        logAllSupportedManagers();

        if(status != 0){
            return status;
        }

        //get and list all supported Managers
        // logAllSupportedManagers();

        //  disconnect();
        return 0;


    }

    private void logAllSupportedManagers() {
        managerNames_THolder managerNames_Holder = null;

        try {
            logger.info("The step 7: list all supported Managers:");
            managerNames_Holder = new managerNames_THolder();
            emsSession.getSupportedManagers(managerNames_Holder);
        } catch (ProcessingFailureException e) {
            e.printStackTrace();
            logger.error("failed!",e);
        }

        for (int i = 0; i < managerNames_Holder.value.length; i++) {
            logger.info("EmsManagerName[" + i + "] " + managerNames_Holder.value[i]);
        }
    }

    private int loginToCorba(EmsSessionFactory_I EmsSessionFactory, String username, String password, NmsSession_I NmsSession) {
        EmsSession_IHolder emsSessionInterfaceHolder = new EmsSession_IHolder();
        try {
            EmsSessionFactory.getEmsSession(username, password, NmsSession, emsSessionInterfaceHolder);
            emsSession = emsSessionInterfaceHolder.value;
            this.isConnected=true;
            logger.info("The step 6: invoke getEmsSession interface to login U2000 CORBA successfully!");
        } catch (Exception ex) {
            logger.error("The step 6: invoke getEmsSession interface to login U2000 CORBA failed!");
                        logger.error(ex.getLocalizedMessage());

            ex.printStackTrace();
            logger.error("failed!",ex);
            disconnect();

            // todo yeni jar dosyası çalıştırılacak
            //System.exit(200);
            return 200;
        }
        return 0;
    }

    private NmsSession_I constructEmsSession() {
        pNmsSessionServant = new TANmsSession_Impl();
        NmsSession_I NmsSession = pNmsSessionServant._this(orb);
        return NmsSession;
    }

    private EmsSessionFactory_I constructEmsSessionFactory(NamingContext nc) {
        org.omg.CosNaming.NameComponent[] name;
        LinkedHashMap<String, String> nameComponents = ems.nameComponents();
        name = new NameComponent[nameComponents.size()];

        int i = 0;

        for (Map.Entry<String, String> entry : nameComponents.entrySet()) {
            name[i++] = new NameComponent(entry.getValue(), entry.getKey());
        }

        EmsSessionFactory_I EmsSessionFactory = null;
        try {
            EmsSessionFactory = EmsSessionFactory_IHelper.narrow(nc.resolve(name));
            if (null != EmsSessionFactory) {
                logger.info("The step 5: get EmsSessionFactory_I object refrence from naming service successfully!");
            }
        } catch (Exception ex) {
            logger.error("The step 5: get EmsSessionFactory_I object refrence from naming service failed! \n please confirm U2000 CORBA is running and EMS name!");
            ex.printStackTrace();
        }
        return EmsSessionFactory;
    }

    private NamingContextExt getNamingRootObj() {
        NamingContextExt nc = null;
        try {
            nc = org.omg.CosNaming.NamingContextExtHelper
                    .narrow(orb.resolve_initial_references("NameService"));
        } catch (InvalidName invalidName) {
            logger.error("The step 4: failed! to get naming service root object refrence!");
            invalidName.printStackTrace();
            logger.error("failed!",invalidName);
        } catch (Exception e) {
            logger.error("The step 4: failed!");
            e.printStackTrace();
            logger.error("failed!",e);
            //System.exit(125);
            return null;
        }
        logger.info("The step 4: get naming service root object refrence successfully!");

        return nc;
    }

    private void startRootPOA() {
        try {
            rootPOA = org.omg.PortableServer.POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
            rootPOA.the_POAManager().activate();
            logger.info("The step 2: get RootPOA successfully!");
        } catch (InvalidName invalidName) {
            logger.error("The step 2: failed to get RootPOA");
            invalidName.printStackTrace();
            logger.error("failed!",invalidName);
        } catch (AdapterInactive adapterInactive) {
            logger.error("The step 2: failed to get RootPOA");
            adapterInactive.printStackTrace();
            logger.error("failed!",adapterInactive);
        }


    }

    private void initializeOrb(String host, String port) {

        String argv[] = new String[2];
        argv[0] = "-ORBInitRef";
        argv[1] = "NameService=corbaloc::" + host + ":" + port + "/NameService";

        orb = org.omg.CORBA.ORB.init(argv, null);
        logger.info("The step 1: initialize ORB successfully!");

    }
}
