package io.ngss.corbaprocessor.corba.manager;

import common.Common_I;
import common.Common_IHolder;
import emsMgr.EMSMgr_I;
import emsMgr.EMSMgr_IHelper;
import emsSession.EmsSession_I;
import globaldefs.NameAndStringValue_T;
import globaldefs.NamingAttributesIterator_IHolder;
import globaldefs.NamingAttributesList_THolder;
import globaldefs.ProcessingFailureException;
import io.ngss.corbaprocessor.InternalDatabase;
import io.ngss.corbaprocessor.corba.metadata.ManagedElement;
import io.ngss.corbaprocessor.corba.metadata.TerminationPoint;
import io.ngss.corbaprocessor.corba.metadata.TopologicalLink;
import managedElement.ManagedElementIterator_IHolder;
import managedElement.ManagedElementList_THolder;
import managedElement.ManagedElement_T;
import multiLayerSubnetwork.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import subnetworkConnection.*;
import terminationPoint.TerminationPointIterator_IHolder;
import terminationPoint.TerminationPointList_THolder;
import terminationPoint.TerminationPoint_T;
import topologicalLink.TopologicalLinkIterator_IHolder;
import topologicalLink.TopologicalLinkList_THolder;
import topologicalLink.TopologicalLink_T;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by ngsscsalur on 8/5/2019.
 */
public class MLSNManager {

    private static Logger logger = LogManager.getLogger(MLSNManager.class);

    private EmsSession_I emsSession;
    private NameAndStringValue_T[] mlsnName;
    private EMSMgr_I emsManager;
    private MultiLayerSubnetworkMgr_I mlsnManager;

    public MLSNManager(EmsSession_I emsSession) {
        this.emsSession = emsSession;
    }

    protected MultiLayerSubnetworkMgr_I getMlsnManager() throws ProcessingFailureException {
        if (null == mlsnManager) {
            logger.info("getmlsnmanager started...");

            Common_IHolder MLSN_holder = new Common_IHolder();
            emsSession.getManager("MultiLayerSubnetwork", MLSN_holder);
            Common_I mlsnCommon = MLSN_holder.value;
            mlsnManager = multiLayerSubnetwork.MultiLayerSubnetworkMgr_IHelper.narrow(mlsnCommon);

            logger.info("getmlsnmanager finished...");

        }

        return mlsnManager;
    }

    public MultiLayerSubnetwork_T getSubnetwork() throws ProcessingFailureException {
        MultiLayerSubnetwork_THolder subnetworkHolder = new MultiLayerSubnetwork_THolder();
        getMlsnManager().getMultiLayerSubnetwork(getMlsnManagerName(), subnetworkHolder);
        return subnetworkHolder.value;
    }

    public MultiLayerSubnetwork_T getMultiLayerSubnetwork(NameAndStringValue_T[] subnetName) throws ProcessingFailureException {
        MultiLayerSubnetwork_THolder subnetworkHolder = new MultiLayerSubnetwork_THolder();

        getMlsnManager().getMultiLayerSubnetwork(subnetName, subnetworkHolder);
        return subnetworkHolder.value;
    }

    private EMSMgr_I getEmsManager() throws ProcessingFailureException {

        if (null == emsManager) {
            Common_IHolder EMS_holder = new Common_IHolder();

            emsSession.getManager("EMS", EMS_holder);
            Common_I emsCommon = EMS_holder.value;
            emsManager = EMSMgr_IHelper.narrow(emsCommon);

        }
        return emsManager;
    }

    private NameAndStringValue_T[] getMlsnManagerName() {

        if (null == mlsnName) {

            int how_many = 1;

            NamingAttributesList_THolder nameList = new NamingAttributesList_THolder();
            NamingAttributesIterator_IHolder nameIt = new NamingAttributesIterator_IHolder();

            try {
                getEmsManager().getAllTopLevelSubnetworkNames(how_many, nameList, nameIt);
            } catch (ProcessingFailureException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                logger.error("failed!", e);
            }

            NameAndStringValue_T[][] names = nameList.value;

            mlsnName = names[0];
        }

        return mlsnName;

    }

    public TopologicalLink_T[] getAllTopologicalLinksNew(NameAndStringValue_T[] subnetName) throws ProcessingFailureException {
        TopologicalLinkList_THolder topoListHolder = new TopologicalLinkList_THolder();
        TopologicalLinkIterator_IHolder topoIt = new TopologicalLinkIterator_IHolder();

        int how_many = 50000;
        this.getMlsnManager().getAllTopologicalLinks(subnetName, how_many, topoListHolder, topoIt);

        return topoListHolder.value;

    }

    public TopologicalLink_T[] getAllInternalTopologicalLinks(NameAndStringValue_T[] meName) throws ProcessingFailureException {
        int how_many = 50000;
        TopologicalLinkList_THolder topologicalLinkList_tHolder = new TopologicalLinkList_THolder();
        TopologicalLinkIterator_IHolder iterator_iHolder = new TopologicalLinkIterator_IHolder();

        getMlsnManager().getAllInternalTopologicalLinks(meName,how_many,topologicalLinkList_tHolder,iterator_iHolder);
        return topologicalLinkList_tHolder.value;
    }

    public TerminationPoint_T[] getAllEdgePoints(NameAndStringValue_T[] subnetName) throws ProcessingFailureException {
        //todo anlamadım bunu
        short[] tpLayerRateList = new short[0];
        short[] connectionLayerRateList = new short[0];
        int how_many = 5000;

        TerminationPointList_THolder tpHolder = new TerminationPointList_THolder();
        TerminationPointIterator_IHolder iterator_iHolder = new TerminationPointIterator_IHolder();

        getMlsnManager().getAllEdgePoints(subnetName,tpLayerRateList,connectionLayerRateList,how_many,tpHolder,iterator_iHolder);
        return tpHolder.value;
    }

    public List<TopologicalLink> getAllTopologicalLinks(HashMap<Integer, ManagedElement> meList, ManagedElementManager mem) throws ProcessingFailureException {

        List<TopologicalLink> topoLinks = new ArrayList<>();

        if (meList.size() == 0) {
            //meList = this.mlsnManager.getAllManagedElements();
            meList = mem.getAllManagedElements();

            //meList = (new ManagedElementManager(CorbaConnection.getInstance().getEmsSession())).getAllManagedElements();

            /*ManagedElementList_THolder meListHolder = new ManagedElementList_THolder();
            ManagedElementIterator_IHolder meListIt = new ManagedElementIterator_IHolder();
            int how_many = 50000;
            ManagedElementManager.getManagedElementManager().getAllManagedElements(how_many,meListHolder,meListIt);*/

        }

        TopologicalLinkList_THolder topoListHolder = new TopologicalLinkList_THolder();
        TopologicalLinkIterator_IHolder topoIt = new TopologicalLinkIterator_IHolder();

        int how_many = 50000;
        NameAndStringValue_T[] subnetworkName = getSubnetwork().name;
        mlsnManager.getAllTopologicalLinks(subnetworkName, how_many, topoListHolder, topoIt);

        int i = 0;
        for (TopologicalLink_T topo : Arrays.asList(topoListHolder.value)) {
            InternalDatabase.allTopologicalLinks.add(topo);

            TopologicalLink topologicalLink = new TopologicalLink();
            topologicalLink.setLinkName(topo.nativeEMSName);
            topologicalLink.setAEndManagedElement(meList.get(Integer.parseInt(topo.aEndTP[1].value)));
            topologicalLink.setZEndManagedElement(meList.get(Integer.parseInt(topo.zEndTP[1].value)));
            topologicalLink.setLinkType(topo.additionalInfo[1].value);
            topologicalLink.setRate(topo.rate);
            String rawAEndTPData = topo.aEndTP[2].value;
            String rawZEndTPData = topo.zEndTP[2].value;
            topologicalLink.setRawMELinksName(topo.aEndTP[1].value + rawAEndTPData);
            topologicalLink.setZEndRawMEName(topo.zEndTP[1].value + rawZEndTPData);
            topologicalLink.setCorbaName(topo.name);
            topologicalLink.setAEndTPCorbaName(topo.aEndTP);
            topologicalLink.setZEndTPCorbaName(topo.zEndTP);

            /*if (topologicalLink.getaEndManagedElement().getId()==4063587) {
                System.out.println("Native EMS Name : " + topo.nativeEMSName);
                System.out.println(topo.name.length);
                System.out.println("Name 1 : " + topo.name[1].value);
                System.out.println("User label : " + topo.userLabel);
            }*/
           /* System.out.println("Addinfo start");
            for(NameAndStringValue_T n : topo.additionalInfo){
                System.out.println(n.name +":"+n.value);
            }
            System.out.println("Addinfo end");*/
            //fillInternalDatabase(topo.aEndTP[1].value, rawAEndTPData, topo.zEndTP[1].value, rawZEndTPData, topo.nativeEMSName);

            Pattern rackPattern = Pattern.compile(".*rack=(\\d+)");
            Pattern shelfPattern = Pattern.compile(".*shelf=(\\d+)");
            Pattern slotPattern = Pattern.compile(".*slot=(\\d+)");
            Pattern domainPattern = Pattern.compile(".*domain=(\\w+)");
            Pattern portPattern = Pattern.compile(".*port=(\\d+)");

            TerminationPoint aEndTP = new TerminationPoint();
            TerminationPoint zEndTP = new TerminationPoint();

            aEndTP.setCorbaName(topo.aEndTP);
            zEndTP.setCorbaName(topo.zEndTP);

            aEndTP.setMe(meList.get(Integer.parseInt(topo.aEndTP[1].value)));
            zEndTP.setMe(meList.get(Integer.parseInt(topo.zEndTP[1].value)));

            Matcher aEndRackMatcher = rackPattern.matcher(rawAEndTPData);
            if (aEndRackMatcher.find()) {
                aEndTP.setRackNo(Integer.parseInt(aEndRackMatcher.group(1)));
            }
            Matcher zEndRackMatcher = rackPattern.matcher(rawZEndTPData);
            if (zEndRackMatcher.find()) {
                zEndTP.setRackNo(Integer.parseInt(zEndRackMatcher.group(1)));
            }

            Matcher aEndShelfMatcher = shelfPattern.matcher(rawAEndTPData);
            if (aEndShelfMatcher.find()) {
                aEndTP.setShelfNo(Integer.parseInt(aEndShelfMatcher.group(1)));
            }
            Matcher zEndShelfMatcher = shelfPattern.matcher(rawZEndTPData);
            if (zEndShelfMatcher.find()) {
                zEndTP.setShelfNo(Integer.parseInt(zEndShelfMatcher.group(1)));
            }

            Matcher aEndSlotMatcher = slotPattern.matcher(rawAEndTPData);
            if (aEndSlotMatcher.find()) {
                aEndTP.setSlotNo(Integer.parseInt(aEndSlotMatcher.group(1)));
            }
            Matcher zEndSlotMatcher = slotPattern.matcher(rawZEndTPData);
            if (zEndSlotMatcher.find()) {
                zEndTP.setSlotNo(Integer.parseInt(zEndSlotMatcher.group(1)));
            }

            Matcher aEndDomainMatcher = domainPattern.matcher(rawAEndTPData);
            if (aEndDomainMatcher.find()) {
                aEndTP.setDomain(aEndDomainMatcher.group(1));
            }
            Matcher zEndDomainMatcher = domainPattern.matcher(rawZEndTPData);
            if (zEndDomainMatcher.find()) {
                zEndTP.setDomain(zEndDomainMatcher.group(1));
            }

            Matcher aEndPortMatcher = portPattern.matcher(rawAEndTPData);
            if (aEndPortMatcher.find()) {
                aEndTP.setPortNo(Integer.parseInt(aEndPortMatcher.group(1)));
            }
            Matcher zEndPortMatcher = portPattern.matcher(rawZEndTPData);
            if (zEndPortMatcher.find()) {
                zEndTP.setPortNo(Integer.parseInt(zEndPortMatcher.group(1)));
            }

            topologicalLink.setAEndTerminationPoint(aEndTP);
            topologicalLink.setZEndTerminationPoint(zEndTP);
            topoLinks.add(topologicalLink);

        }

        return topoLinks;

    }

    private void fillInternalDatabase(String meId, String rawAEndTPData, String zEndMEId, String rawzEndTPData, String nativeEMSName) {
        if ((meId + rawAEndTPData).equals("4063587/rack=1/shelf=3147151/slot=1/domain=wdm/port=1")) {
            logger.info("NATIVITTO : " + nativeEMSName);
        }
        //todo buraya bakilacak
        //InternalDatabase.portCircuitNameMap.put(meId + rawAEndTPData, zEndMEId + rawzEndTPData);
    }

    public HashMap<Integer, ManagedElement> getAllManagedElements() throws ProcessingFailureException {

        HashMap<Integer, ManagedElement> meList = new HashMap<>();

        ManagedElementList_THolder meListHolder = new ManagedElementList_THolder();
        ManagedElementIterator_IHolder meListIt = new ManagedElementIterator_IHolder();

        int how_many_me = 50000;


        this.getMlsnManager().getAllManagedElements(getMlsnManagerName(), how_many_me, meListHolder, meListIt);

        for (ManagedElement_T me : meListHolder.value) {
            ManagedElement managedElement = new ManagedElement(
                    Integer.parseInt(me.name[1].value),
                    me.nativeEMSName,
                    me.productName,
                    me.name);
            meList.put(managedElement.getId(), managedElement);
        }

        return meList;
    }


    public SubnetworkConnection_T getSNC(NameAndStringValue_T[] name) throws ProcessingFailureException {

        SubnetworkConnection_THolder subnetworkConnection_tHolder = new SubnetworkConnection_THolder();
        this.getMlsnManager().getSNC(getMlsnManagerName(), subnetworkConnection_tHolder);

        return subnetworkConnection_tHolder.value;

    }

    public CrossConnect_T[] getRoute(NameAndStringValue_T[] sncName) throws ProcessingFailureException {

        boolean includeHigherOrderCCs = true;
        Route_THolder holder = new Route_THolder();

        this.getMlsnManager().getRoute(sncName, includeHigherOrderCCs, holder);
        return holder.value;
    }

    public HW_ConjunctionSNC_T[] getAllConjuctionSNCs() throws ProcessingFailureException {
        int how_many = 5000;
        HW_ConjunctionSNCList_THolder sncList_tHolder = new HW_ConjunctionSNCList_THolder();
        HW_ConjunctionSNCIterator_IHolder iterator_iHolder = new HW_ConjunctionSNCIterator_IHolder();

        getMlsnManager().getAllConjunctionSNCs(how_many, sncList_tHolder, iterator_iHolder);
        return sncList_tHolder.value;
    }

    public SubnetworkConnection_T[] getAllSubnetworkConnections(NameAndStringValue_T[] subnetName) throws ProcessingFailureException {

        int how_many_me = 50000;
        short[] shorts = new short[0];

        SubnetworkConnectionList_THolder sncListHolder = new SubnetworkConnectionList_THolder();
        SNCIterator_IHolder sncIterator = new SNCIterator_IHolder();

        this.getMlsnManager().getAllSubnetworkConnections(subnetName, shorts, how_many_me, sncListHolder, sncIterator);
        logger.info("getAllSubnetworkConnections length: " + sncListHolder.value.length);
        return sncListHolder.value;

    }

    public void getAllSubnetworkConnectionsWithTP(NameAndStringValue_T[] nameAndStringValue_t) throws ProcessingFailureException {

        int how_many_me = 50000;
        short[] shorts = new short[0];

        SubnetworkConnectionList_THolder sncListHolder = new SubnetworkConnectionList_THolder();
        SNCIterator_IHolder sncIterator = new SNCIterator_IHolder();

        this.getMlsnManager().getAllSubnetworkConnectionsWithTP(nameAndStringValue_t, shorts, how_many_me, sncListHolder, sncIterator);

        for (SubnetworkConnection_T snc : sncListHolder.value) {
            InternalDatabase.allSubnetworkConnectionsByTP.add(snc);
        }
    }

    public RouteAndTopologicalLink_T getRouteAndTopologicalLinks(NameAndStringValue_T[] sncName) throws ProcessingFailureException {

        Route_THolder route_tHolder = new Route_THolder();
        TopologicalLinkList_THolder topologicalLinkList_tHolder = new TopologicalLinkList_THolder();

        this.getMlsnManager().getRouteAndTopologicalLinks(sncName, route_tHolder, topologicalLinkList_tHolder);

        RouteAndTopologicalLink_T rt = new RouteAndTopologicalLink_T();
        rt.route = route_tHolder.value;
        rt.topologicalLinkList = topologicalLinkList_tHolder.value;
        return rt;
    }

    public RouteAndTopologicalLink_T[] getRouteAndTopologicalLinksBySNCs(NameAndStringValue_T[][] nameAndStringValue_ts) throws ProcessingFailureException {

        RouteAndTopologicalLinkList_THolder routeAndTopologicalLinkList_tHolder = new RouteAndTopologicalLinkList_THolder();
        RouteAndTopologicalLinkIterator_IHolder routeAndTopologicalLinkIterator_iHolder = new RouteAndTopologicalLinkIterator_IHolder();

        int how_many_me = 50000;
        this.getMlsnManager().getRouteAndTopologicalLinksBySNCs(nameAndStringValue_ts, how_many_me, routeAndTopologicalLinkList_tHolder, routeAndTopologicalLinkIterator_iHolder);

        return routeAndTopologicalLinkList_tHolder.value;
    }


    public NameAndStringValue_T[] getNameAndStringValue(String managedElementName) {

        NameAndStringValue_T[] name = {new NameAndStringValue_T("EMS", "Huawei/U2000"), new NameAndStringValue_T("ManagedElement", managedElementName)};

        return name;
    }

}
