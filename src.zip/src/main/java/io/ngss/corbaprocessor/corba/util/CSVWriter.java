package io.ngss.corbaprocessor.corba.util;

import io.ngss.corbaprocessor.corba.interfaces.CSVCompatible;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;

/**
 * Created by ngsscsalur on 8/5/2019.
 */
public class CSVWriter {

    private static final Logger logger = LoggerFactory.getLogger(CSVWriter.class);

    public static void writeToCSV(Collection<CSVCompatible> csvs, String fileName) {

        // final String fileName = "C:\\inventoryfiles\\managedElements.csv";
        try {
            PrintWriter writer = new PrintWriter(fileName, "UTF-8");
            writerHeader(csvs.iterator().next(), writer);
            for (CSVCompatible csv : csvs) {
                writer.println(csv.toCSVString());
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
            logger.error("CSVWriter failed!",e);
        }

    }

    private static void writerHeader(CSVCompatible next, PrintWriter writer) {
        writer.println(next.CSVHeaders());
    }
}
