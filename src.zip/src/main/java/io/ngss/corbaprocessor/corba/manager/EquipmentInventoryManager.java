package io.ngss.corbaprocessor.corba.manager;

import common.Common_I;
import common.Common_IHolder;
import emsSession.EmsSession_I;
import equipment.*;
import globaldefs.NameAndStringValue_T;
import globaldefs.NamingAttributesIterator_IHolder;
import globaldefs.NamingAttributesList_THolder;
import globaldefs.ProcessingFailureException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import terminationPoint.TerminationPointIterator_IHolder;
import terminationPoint.TerminationPointList_THolder;
import terminationPoint.TerminationPoint_T;

/**
 * Created by ngsscsalur on 8/19/2019.
 */
public class EquipmentInventoryManager {
    private static Logger logger = LogManager.getLogger(EquipmentInventoryManager.class);
    private EmsSession_I emsSession;
    private EquipmentInventoryMgr_I equipmentInventoryMgr;

    public EquipmentInventoryManager(EmsSession_I emsSession) {
        this.emsSession = emsSession;
    }

    protected EquipmentInventoryMgr_I getEquipmentInventoryMgr() throws ProcessingFailureException {

        if (null == equipmentInventoryMgr) {
            logger.info("EquipmentInventoryMgr_I started...");

            Common_IHolder equipmentInventoryHolder = new Common_IHolder();
            emsSession.getManager("EquipmentInventory", equipmentInventoryHolder);
            Common_I eqCommon = equipmentInventoryHolder.value;
            equipmentInventoryMgr = EquipmentInventoryMgr_IHelper.narrow(eqCommon);

            logger.info("EquipmentInventoryMgr_I finished...");
        }
        return equipmentInventoryMgr;
    }

    public EquipmentOrHolder_T getEquipment(NameAndStringValue_T[] equipmentOrHolderName) throws ProcessingFailureException {
        EquipmentOrHolder_THolder equipmentOrHolder_tHolder = new EquipmentOrHolder_THolder();

        getEquipmentInventoryMgr().getEquipment(equipmentOrHolderName, equipmentOrHolder_tHolder);
        return equipmentOrHolder_tHolder.value;
    }

    public EquipmentOrHolder_T[] getAllEquipment(NameAndStringValue_T[] meOrHolderName) throws ProcessingFailureException {
        int how_many = 50000;
        EquipmentOrHolderList_THolder holderList_tHolder = new EquipmentOrHolderList_THolder();
        EquipmentOrHolderIterator_IHolder iterator_iHolder = new EquipmentOrHolderIterator_IHolder();

        getEquipmentInventoryMgr().getAllEquipment(meOrHolderName, how_many, holderList_tHolder, iterator_iHolder);
        return holderList_tHolder.value;
    }

    public EquipmentOrHolder_T[] getContainedEquipment(NameAndStringValue_T[] equipmentHolderName) throws ProcessingFailureException {
        EquipmentOrHolderList_THolder holderList_tHolder = new EquipmentOrHolderList_THolder();

        getEquipmentInventoryMgr().getContainedEquipment(equipmentHolderName, holderList_tHolder);
        return holderList_tHolder.value;
    }

    public TerminationPoint_T[] getAllSupportedPTPs(NameAndStringValue_T[] equipmentName) throws ProcessingFailureException {
        int how_many = 50000;
        TerminationPointList_THolder tpHolder = new TerminationPointList_THolder();
        TerminationPointIterator_IHolder iterator_iHolder = new TerminationPointIterator_IHolder();

        getEquipmentInventoryMgr().getAllSupportedPTPs(equipmentName, how_many, tpHolder, iterator_iHolder);
        return tpHolder.value;
    }

    public EquipmentOrHolder_T[] getAllSupportingEquipment(NameAndStringValue_T[] ptpName) throws ProcessingFailureException {
        EquipmentOrHolderList_THolder holderList_tHolder = new EquipmentOrHolderList_THolder();

        getEquipmentInventoryMgr().getAllSupportingEquipment(ptpName, holderList_tHolder);
        return holderList_tHolder.value;
    }

    public NameAndStringValue_T[][] getEquipmentStaticInfo(String[] typeList) throws ProcessingFailureException {
        int how_many = 50000;
        NamingAttributesList_THolder list_tHolder = new NamingAttributesList_THolder();
        NamingAttributesIterator_IHolder iterator_iHolder = new NamingAttributesIterator_IHolder();

        getEquipmentInventoryMgr().getEquipmentStaticInfo(typeList, how_many, list_tHolder, iterator_iHolder);
        return list_tHolder.value;
    }

    public PhysicalLocationInfo_T[] getPhysicalLocationInfo() throws ProcessingFailureException {
        PhysicalLocationInfoList_THolder physicalLocationInfoList_tHolder = new PhysicalLocationInfoList_THolder();

        getEquipmentInventoryMgr().getPhysicalLocationInfo(physicalLocationInfoList_tHolder);
        return physicalLocationInfoList_tHolder.value;
    }
}
