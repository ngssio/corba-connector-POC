package io.ngss.corbaprocessor.corba.ems;

import java.util.LinkedHashMap;

/**
 * Created by ngsscsalur on 8/5/2019.
 */
public class U2000 implements EMSCorbaInterface {

    private String host;
    private String port;
    private String username;
    private String password;

    public U2000(String host, String port, String username, String password) {
        this.host = host;
        this.port = port;
        this.username = username;
        this.password = password;
    }

    @Override
    public String host() {
        return host;
    }

    @Override
    public String port() {
        return port;
    }

    @Override
    public String username() {
        return username;
    }

    @Override
    public String password() {
        return password;
    }

    @Override
    public LinkedHashMap<String, String> nameComponents() {

        LinkedHashMap<String, String> compMap = new LinkedHashMap<>();
        compMap.put("Class", "TMF_MTNM");
        compMap.put("Vendor", "HUAWEI");
        compMap.put("EmsInstance", "Huawei/T2000");
        compMap.put("Version", "2.0");
        compMap.put("EmsSessionFactory_I", "Huawei/T2000");

        return compMap;
    }
}
