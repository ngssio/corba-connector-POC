package io.ngss.corbaprocessor.corba.metadata;

import globaldefs.NameAndStringValue_T;
import io.ngss.corbaprocessor.corba.interfaces.CSVCompatible;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * Created by ngsscsalur on 8/5/2019.
 */

@Getter
@Setter
@ToString
public class TopologicalLink implements Serializable, CSVCompatible {

    private String linkName;
    //TODO burası integer yerine enum yapilabilir, veya keyvalue pair obj
    private short Rate;
    private ManagedElement aEndManagedElement;
    private ManagedElement zEndManagedElement;
    private TerminationPoint aEndTerminationPoint;
    private TerminationPoint zEndTerminationPoint;
    private String linkType;
    private String rawMELinksName;
    private String ZEndRawMEName;
    private NameAndStringValue_T[] corbaName;
    private NameAndStringValue_T[] aEndTPCorbaName;
    private NameAndStringValue_T[] zEndTPCorbaName;

    @Override
    public String toCSVString() {
        //RateConverter rc = RateConverter.getInstance();
        return String.format("%s,%s,%s,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%s,%s", linkName, linkType, "rc.getRateName(this.getRate())"
                , this.aEndManagedElement.getId(), this.zEndManagedElement.getId()
                , this.aEndTerminationPoint.getRackNo(), this.aEndTerminationPoint.getShelfNo(), this.aEndTerminationPoint.getSlotNo(), this.aEndTerminationPoint.getPortNo()
                , this.zEndTerminationPoint.getRackNo(), this.zEndTerminationPoint.getShelfNo(), this.zEndTerminationPoint.getSlotNo(), this.zEndTerminationPoint.getPortNo()
                , this.aEndTerminationPoint.getNativeEmsName(), this.zEndTerminationPoint.getNativeEmsName());
    }

    @Override
    public String CSVHeaders() {
        return String.format("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s", "Link Name", "Link Type", "Link Rate",
                "A End ME Id", "Z End ME Id",
                "A End Rack No", "A End Shelf No", "A End Slot No", "A End Port No",
                "Z End Rack No", "Z End Shelf No", "Z End Slot No", "Z End Port No","A End TP NativeEmsName","Z End TP NativeEmsName");

    }
}
