package io.ngss.corbaprocessor.corba.interfaces;

/**
 * Created by ngsscsalur on 8/5/2019.
 */
public interface CSVCompatible {
    String toCSVString();
    String CSVHeaders();
}
