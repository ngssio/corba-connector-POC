package io.ngss.corbaprocessor.corba.util;

import lombok.*;

/**
 * Created by ngsscsalur on 9/4/2019.
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class XMLNode {
    private String nodeBName;
    private String port;
    private String slot;
    private String vlan;
}
