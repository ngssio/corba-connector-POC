package io.ngss.corbaprocessor.corba.manager;

import HW_vpnManager.*;
import HW_vpnManager.FDFrIterator_IHolder;
import HW_vpnManager.FlowDomainFragment_T;
import HW_vpnManager.MatrixFlowDomainFragmentList_THolder;
import HW_vpnManager.MatrixFlowDomainFragment_T;
import common.Common_I;
import common.Common_IHolder;
import emsSession.EmsSession_I;
import globaldefs.NameAndStringValue_T;
import globaldefs.NamingAttributesIterator_IHolder;
import globaldefs.NamingAttributesList_THolder;
import globaldefs.ProcessingFailureException;
import io.ngss.corbaprocessor.InternalDatabase;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by ngssrgunaydin on 8/15/2019.
 */
public class VPNManager {

    private static Logger logger = LogManager.getLogger(VPNManager.class);

    private EmsSession_I emsSession;
    private HW_VPNMgr_I vpnManager;

    public VPNManager(EmsSession_I emsSession) {
        this.emsSession = emsSession;
    }

    protected HW_VPNMgr_I getVPNManager() throws ProcessingFailureException {
        if (null == vpnManager) {
            logger.info("getVPNManager started...");

            Common_IHolder VPN_holder = new Common_IHolder();
            emsSession.getManager("CORBA_VPN", VPN_holder);
            Common_I mstpCommon = VPN_holder.value;
            vpnManager = HW_VPNMgr_IHelper.narrow(mstpCommon);

            logger.info("getVPNManager finished...");
        }

        return vpnManager;
    }

    public TrafficTrunk_T[] getAllTrafficTrunks(NameAndStringValue_T[] fdName, short layerRate) throws ProcessingFailureException {

        int how_many_me = 50000;
        short[] shorts = {layerRate};

        TrafficTrunkList_THolder trafficTrunkList_tHolder = new TrafficTrunkList_THolder();
        TrafficTrunkIterator_IHolder trafficTrunkIterator_iHolder = new TrafficTrunkIterator_IHolder();

        this.getVPNManager().getAllTrafficTrunks(fdName, shorts, how_many_me, trafficTrunkList_tHolder, trafficTrunkIterator_iHolder);

        return trafficTrunkList_tHolder.value;


    }

    public void getAllTrafficTrunksWithME(NameAndStringValue_T[] meName, short layerRate) throws ProcessingFailureException {
        int how_many_me = 50000;
        short[] shorts = {layerRate};

        TrafficTrunkList_THolder trafficTrunkList_tHolder = new TrafficTrunkList_THolder();
        TrafficTrunkIterator_IHolder trafficTrunkIterator_iHolder = new TrafficTrunkIterator_IHolder();

        this.getVPNManager().getAllTrafficTrunks(meName, shorts, how_many_me, trafficTrunkList_tHolder, trafficTrunkIterator_iHolder);

        for (TrafficTrunk_T value : trafficTrunkList_tHolder.value) {
            InternalDatabase.allTrafficTrunksWithME.add(value);
        }
    }

    public MatrixFlowDomainFragment_T[] getAllMFDFrs(NameAndStringValue_T[] meName) throws ProcessingFailureException {
        int how_many_me = 50000;
        short[] shorts = new short[0];

        MatrixFlowDomainFragmentList_THolder mfdfl_tHolder = new MatrixFlowDomainFragmentList_THolder();
        MFDFrIterator_IHolder mfdFrIterator_iHolder = new MFDFrIterator_IHolder();

        this.getVPNManager().getAllMFDFrs(meName, shorts, how_many_me, mfdfl_tHolder, mfdFrIterator_iHolder);
        return mfdfl_tHolder.value;

    }

    public List<FlowDomainFragment_T> getAllFDFrs(NameAndStringValue_T[] fdName, short layerRate) throws ProcessingFailureException {
        int how_many_me = 3000;
        int count = 0;
        short[] shorts = {layerRate};
        List<FlowDomainFragment_T> fdfrs = new ArrayList<>();

        FlowDomainFragmentList_THolder holder = new FlowDomainFragmentList_THolder();
        FDFrIterator_IHolder iterator = new FDFrIterator_IHolder();
        this.getVPNManager().getAllFDFrs(fdName, how_many_me, shorts, holder, iterator);
//
//        File file = new File("fdfr.txt");
//        if(!file.exists()) file.createNewFile();
//        FileWriter fr = new FileWriter(file,true);

//        for (FlowDomainFragment_T fdfr : holder.value) {
//            fr.write(InternalDatabase.getFDFrAsString(fdfr));
//        }



        fdfrs.addAll(Arrays.asList(holder.value));


        if (iterator.value != null) {
            try {
                boolean hasMoreData = true;
                while (hasMoreData) {
                    hasMoreData = iterator.value.next_n(how_many_me, holder);
//                    for (FlowDomainFragment_T fdfr : holder.value) {
//                        fr.write(InternalDatabase.getFDFrAsString(fdfr));
//                    }
                    fdfrs.addAll(Arrays.asList(holder.value));
                    count += how_many_me;
                    System.out.println("count: " + count);
                }
            } catch (Exception e) {
                System.out.println("error");
            }
        }


//        fr.close();

        return fdfrs;
    }

    private static void writeMFDFr(MatrixFlowDomainFragment_T[] mfdfrs) throws IOException {

        File file = new File("mfdfr.txt");
        if (file.exists() == false) file.createNewFile();
        FileWriter fr = new FileWriter(file, true);
        for (MatrixFlowDomainFragment_T m : mfdfrs) {
            fr.write(InternalDatabase.getMFDFRAsString(m));
        }
        fr.close();
    }


    public MatrixFlowDomainFragment_T[] getFDFrRoute(NameAndStringValue_T[] fdfrName) throws ProcessingFailureException, IOException {

        boolean includeHigherOrderCCs = true;
        FDFrRoute_THolder holder = new FDFrRoute_THolder();

        getVPNManager().getFDFrRoute(fdfrName, includeHigherOrderCCs, holder);

        this.writeMFDFr(holder.value);

        return holder.value;
    }


    public IPCrossConnection_T[] getAllIPCrossConnections(NameAndStringValue_T[] meName, short layerRate) throws ProcessingFailureException {
        int how_many = 5000;
        short[] shorts = {layerRate};
        IPCrossConnectionList_THolder holder = new IPCrossConnectionList_THolder();
        IPCrossConnectionIterator_IHolder iterator = new IPCrossConnectionIterator_IHolder();

        this.getVPNManager().getAllIPCrossConnections(meName, shorts, how_many, holder, iterator);
        return holder.value;
    }

    public NameAndStringValue_T[][] getAllIPCrossconnectionNames(NameAndStringValue_T[] meName, short layerRate) throws ProcessingFailureException {
        int how_many = 500;
        short[] shorts = {layerRate};
        NamingAttributesList_THolder holder = new NamingAttributesList_THolder();
        NamingAttributesIterator_IHolder iterator = new NamingAttributesIterator_IHolder();

        this.getVPNManager().getAllIPCrossConnectionNames(meName, shorts, how_many, holder, iterator);

        return holder.value;
    }

    public IPCrossConnection_T[] getIPRoutes(NameAndStringValue_T[] trafficTrunkName) throws ProcessingFailureException {

        IPCrossConnectionList_THolder holder = new IPCrossConnectionList_THolder();
        getVPNManager().getIPRoutes(trafficTrunkName, holder);

        return holder.value;
    }

    public IPRouteInfo_T[] getIPRoutesByTrafficTrunks(NameAndStringValue_T[][] trafficTrunkNames) throws ProcessingFailureException {

        IPRouteInfoList_THolder holder = new IPRouteInfoList_THolder();
        getVPNManager().getIPRoutesByTrafficTrunks(trafficTrunkNames, holder);

        return holder.value;
    }

    public FlowDomainFragment_T getFDFr(NameAndStringValue_T[] fdfrName) throws ProcessingFailureException {
        FlowDomainFragment_THolder holder = new FlowDomainFragment_THolder();
        getVPNManager().getFDFr(fdfrName, holder);
        return holder.value;
    }

    public NameAndStringValue_T[][] getFDFrServerTrail(NameAndStringValue_T[] fdfrName) throws ProcessingFailureException {
        int how_many = 100;
        NamingAttributesList_THolder holder = new NamingAttributesList_THolder();
        getVPNManager().getFDFrServerTrail(fdfrName, holder);
        return holder.value;
    }

    public TrafficTrunk_T getTrafficTrunk(NameAndStringValue_T[] trafficTrunkName) throws ProcessingFailureException {
        TrafficTrunk_THolder holder = new TrafficTrunk_THolder();
        getVPNManager().getTrafficTrunk(trafficTrunkName, holder);
        return holder.value;
    }


//    public MatrixFlowDomainFragment_T[] getFDFrRoute(NameAndStringValue_T[] meName) throws ProcessingFailureException {
//        boolean includeHigherOrderCCs = true;
//        FDFrRoute_THolder fdFrRoute_tHolder = new FDFrRoute_THolder();
//
//        this.getVPNManager().getFDFrRoute(meName, includeHigherOrderCCs, fdFrRoute_tHolder);
//        return fdFrRoute_tHolder.value;
//    }


}
