package io.ngss.corbaprocessor.corba.metadata;

import globaldefs.NameAndStringValue_T;
import io.ngss.corbaprocessor.corba.interfaces.CSVCompatible;
import lombok.*;

import java.io.Serializable;

/**
 * Created by ngssrgunaydin on 8/19/2019.
 */

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PhysicalTerminationPoint implements Serializable, CSVCompatible {

    private NameAndStringValue_T[] name;
    private String nativeEMSName;

    @Override
    public String toCSVString() {
        return String.format("%s, %s, %s, %s",
                name[0].value,name[1].value,name[2].value,nativeEMSName);
    }

    @Override
    public String CSVHeaders() {
        return "NameAndStringValue[0],NameAndStringValue[1],NameAndStringValue[2],nativeEMSName";
    }
}
