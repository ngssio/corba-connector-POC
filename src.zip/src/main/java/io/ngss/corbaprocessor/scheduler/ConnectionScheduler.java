package io.ngss.corbaprocessor.scheduler;

import io.ngss.corbaprocessor.manager.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Created by ngssrgunaydin on 8/7/2019.
 */
@Component
public class ConnectionScheduler {

    private CorbaConnectionManager corbaConnectionManager;
    private WDMLinkManager wdmLinkManager;
    private TestManager testManager;
    private DataManager dataManager;
    private DataManagerUpdated dataManagerUpdated;

    public ConnectionScheduler(@Autowired CorbaConnectionManager corbaConnectionManager,
                               @Autowired WDMLinkManager wdmLinkManager,
                               @Autowired TestManager testManager,
                               @Autowired DataManager dataManager,
                               @Autowired DataManagerUpdated dataManagerUpdated) {
        this.corbaConnectionManager = corbaConnectionManager;
        this.wdmLinkManager = wdmLinkManager;
        this.testManager = testManager;
        this.dataManager = dataManager;
        this.dataManagerUpdated = dataManagerUpdated;
    }

    @Scheduled(fixedRate = 100000000, initialDelay = 10000)
    public void connect() {
        this.corbaConnectionManager.createConnection();
        //this.wdmLinkManager.findAllLinks();
        //this.testManager.test();
        //this.dataManager.processRTN();
        this.dataManagerUpdated.process();
    }


}
